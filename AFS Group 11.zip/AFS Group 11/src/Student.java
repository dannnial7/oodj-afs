/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Muhammad Aamer Ali
 */
import java.util.ArrayList;
import java.util.Date;

public class Student extends User {
    public Student(String userID, String name, String email, String password) {
        super(userID, name, email, password, "Student");
    }
    
    @Override
    public boolean login(String id, String password) {
        return this.userID.equals(id) && this.password.equals(password);
    }
    
    @Override
    public void displayDashboard() {
        System.out.println("Welcome to Student Dashboard: " + name);
    }
    
    public boolean registerForCourse(Course course) {
        FileManager fm = FileManager.getInstance();
        
        // Check if already enrolled
        if (fm.isEnrolled(this.userID, course.getCourseCode())) {
            return false;
        }
        
        Enrollment enrollment = new Enrollment(this, course, new Date());
        fm.saveEnrollment(enrollment);
        fm.addNotification(this.userID, "Registered for " + course.getCourseCode());
        return true;
    }
    
    public boolean unregisterFromCourse(String courseCode) {
        FileManager fm = FileManager.getInstance();
        
        // Check if actually enrolled
        if (!fm.isEnrolled(this.userID, courseCode)) {
            System.out.println("DEBUG: Student " + this.userID + " is not enrolled in " + courseCode);
            return false;
        }
        
        // Remove enrollment
        boolean success = fm.removeEnrollment(this.userID, courseCode);
        
        if (success) {
            fm.addNotification(this.userID, "Unregistered from module: " + courseCode);
            System.out.println("DEBUG: Successfully unregistered " + this.userID + " from " + courseCode);
        } else {
            System.out.println("DEBUG: Failed to unregister " + this.userID + " from " + courseCode);
        }
        
        return success;
    }
    
    public ArrayList<Result> viewResults() {
        return FileManager.getInstance().loadResults(this.userID);
    }
    
    public boolean sendCommentToLecturer(String lecturerID, String courseCode, String message) {
        if (message == null || message.trim().isEmpty()) {
            return false;
        }
        
        Comment comment = new Comment(this.userID, lecturerID, courseCode, message, new Date());
        return FileManager.getInstance().saveComment(comment);
    }
    
    public ArrayList<String> getUnreadNotifications() {
        return FileManager.getInstance().getNotificationsForStudent(this.userID);
    }
    
    public void markNotificationAsRead(int index) {
        FileManager.getInstance().markNotificationAsRead(this.userID, index);
    }
}
