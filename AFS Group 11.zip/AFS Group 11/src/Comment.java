/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Muhammad Aamer Ali
 */
import java.text.SimpleDateFormat;
import java.util.Date;

public class Comment {
    private String studentID;
    private String lecturerID;
    private String courseCode;
    private String message;
    private Date timestamp;
    
    public Comment(String studentID, String lecturerID, String courseCode, 
                   String message, Date timestamp) {
        this.studentID = studentID;
        this.lecturerID = lecturerID;
        this.courseCode = courseCode;
        this.message = message;
        this.timestamp = timestamp;
    }
    
    // Getters
    public String getStudentID() { return studentID; }
    public String getLecturerID() { return lecturerID; }
    public String getCourseCode() { return courseCode; }
    public String getMessage() { return message; }
    public Date getTimestamp() { return timestamp; }

    public String toStorageLine() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return studentID + "," + lecturerID + "," + courseCode + ","
                + message.replace(",", ";") + "," + sdf.format(timestamp);
    }
    
    @Override
    public String toString() {
        return toStorageLine();
    }
}
