/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Muhammad Aamer Ali
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;

public class CommentFrame extends JFrame {
    private Student student;
    private JComboBox<String> courseCombo;
    private JComboBox<String> lecturerCombo;
    private JTextArea commentArea;
    private ArrayList<Course> enrolledCourses;
    
    public CommentFrame(Student student) {
        this.student = student;
        
        setTitle("Comment to Lecturer");
        setSize(500, 400);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        
        // Form Panel
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        // Student Info (read-only)
        gbc.gridx = 0; gbc.gridy = 0;
        formPanel.add(new JLabel("From:"), gbc);
        gbc.gridx = 1;
        JTextField studentField = new JTextField(student.getName() + " (" + student.getUserID() + ")");
        studentField.setEditable(false);
        studentField.setBackground(Color.LIGHT_GRAY);
        formPanel.add(studentField, gbc);
        
        // Module Selection
        gbc.gridx = 0; gbc.gridy = 1;
        formPanel.add(new JLabel("Select Module:"), gbc);
        gbc.gridx = 1;
        
        enrolledCourses = FileManager.getInstance().getEnrolledCourses(student.getUserID());
        courseCombo = new JComboBox<>();
        courseCombo.addItem("-- Select Module --");
        for (Course course : enrolledCourses) {
            courseCombo.addItem(course.getCourseCode() + " - " + course.getCourseName());
        }
        courseCombo.addActionListener(e -> updateLecturers());
        formPanel.add(courseCombo, gbc);
        
        // Lecturer Selection
        gbc.gridx = 0; gbc.gridy = 2;
        formPanel.add(new JLabel("To Lecturer:"), gbc);
        gbc.gridx = 1;
        lecturerCombo = new JComboBox<>();
        lecturerCombo.addItem("-- Select Module First --");
        formPanel.add(lecturerCombo, gbc);
        
        // Comment Area
        gbc.gridx = 0; gbc.gridy = 3;
        formPanel.add(new JLabel("Your Comment:"), gbc);
        gbc.gridx = 1; gbc.gridy = 3;
        gbc.gridwidth = 1;
        gbc.gridheight = 3;
        gbc.fill = GridBagConstraints.BOTH;
        
        commentArea = new JTextArea(5, 30);
        commentArea.setLineWrap(true);
        commentArea.setWrapStyleWord(true);
        commentArea.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        
        JScrollPane scrollPane = new JScrollPane(commentArea);
        formPanel.add(scrollPane, gbc);
        
        // Character counter
        gbc.gridx = 1; gbc.gridy = 6;
        gbc.gridheight = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        JLabel charCounter = new JLabel("Characters: 0/500");
        charCounter.setForeground(Color.GRAY);
        formPanel.add(charCounter, gbc);
        
        // Update character counter
        commentArea.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            public void changedUpdate(javax.swing.event.DocumentEvent e) { updateCount(); }
            public void removeUpdate(javax.swing.event.DocumentEvent e) { updateCount(); }
            public void insertUpdate(javax.swing.event.DocumentEvent e) { updateCount(); }
            
            private void updateCount() {
                int length = commentArea.getText().length();
                charCounter.setText("Characters: " + length + "/500");
                charCounter.setForeground(length > 500 ? Color.RED : Color.GRAY);
            }
        });
        
        // Button Panel
        JPanel buttonPanel = new JPanel();
        JButton sendButton = new JButton("Send Comment");
        sendButton.setBackground(new Color(156, 39, 176));
        sendButton.setForeground(Color.WHITE);
        
        JButton clearButton = new JButton("Clear");
        clearButton.setBackground(Color.ORANGE);
        
        JButton cancelButton = new JButton("Cancel");
        cancelButton.setBackground(Color.LIGHT_GRAY);
        
        buttonPanel.add(sendButton);
        buttonPanel.add(clearButton);
        buttonPanel.add(cancelButton);
        
        // Add panels to frame
        add(formPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
        
        // Action Listeners
        sendButton.addActionListener(e -> sendComment());
        clearButton.addActionListener(e -> clearForm());
        cancelButton.addActionListener(e -> this.dispose());
    }
    
    private void updateLecturers() {
        int selectedIndex = courseCombo.getSelectedIndex();
        if (selectedIndex > 0) { // Not the placeholder
            Course selectedCourse = enrolledCourses.get(selectedIndex - 1);
            String lecturerID = selectedCourse.getLecturerID();
            
            lecturerCombo.removeAllItems();
            lecturerCombo.addItem(lecturerID + " (Module Lecturer)");
        } else {
            lecturerCombo.removeAllItems();
            lecturerCombo.addItem("-- Select Module First --");
        }
    }
    
    private void sendComment() {
        int courseIndex = courseCombo.getSelectedIndex();
        int lecturerIndex = lecturerCombo.getSelectedIndex();
        String comment = commentArea.getText().trim();
        
        // Validation
        if (courseIndex <= 0) {
            JOptionPane.showMessageDialog(this, "Please select a module", 
                                         "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        if (lecturerIndex < 0) {
            JOptionPane.showMessageDialog(this, "Please select a lecturer", 
                                         "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        if (comment.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter your comment", 
                                         "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        if (comment.length() > 500) {
            JOptionPane.showMessageDialog(this, "Comment exceeds 500 characters", 
                                         "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Get selected course and lecturer
        Course selectedCourse = enrolledCourses.get(courseIndex - 1);
        String lecturerID = selectedCourse.getLecturerID();
        
        Comment newComment = new Comment(
            student.getUserID(),
            lecturerID,
            selectedCourse.getCourseCode(),
            comment,
            new Date()
        );
        boolean success = saveCommentToTextFile(newComment);
        
        if (success) {
            JOptionPane.showMessageDialog(this, 
                "Comment sent successfully to " + lecturerID + "\nfor module: " + selectedCourse.getCourseCode(),
                "Success", JOptionPane.INFORMATION_MESSAGE);
            
            // Clear form
            clearForm();
            
            // Add notification
            FileManager.getInstance().addNotification(student.getUserID(), 
                "Comment sent to " + lecturerID + " for module " + selectedCourse.getCourseCode());
        } else {
            JOptionPane.showMessageDialog(this, "Failed to send comment", 
                                         "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private boolean saveCommentToTextFile(Comment comment) {
        File file = new File("data_files/comments.txt");
        File parent = file.getParentFile();
        if (parent != null && !parent.exists()) {
            parent.mkdirs();
        }

        try (FileWriter writer = new FileWriter(file, true)) {
            writer.write(comment.toStorageLine());
            writer.write(System.lineSeparator());
            return true;
        } catch (IOException ex) {
            System.err.println("Error saving comment: " + ex.getMessage());
            return false;
        }
    }
    
    private void clearForm() {
        commentArea.setText("");
        courseCombo.setSelectedIndex(0);
        lecturerCombo.removeAllItems();
        lecturerCombo.addItem("-- Select Module First --");
    }
}
