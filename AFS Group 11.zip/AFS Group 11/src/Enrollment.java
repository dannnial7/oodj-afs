/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Muhammad Aamer Ali
 */
import java.text.SimpleDateFormat;
import java.util.Date;

public class Enrollment {
    private Student student;
    private Course course;
    private Date enrollmentDate;
    
    public Enrollment(Student student, Course course, Date enrollmentDate) {
        this.student = student;
        this.course = course;
        this.enrollmentDate = enrollmentDate;
    }
    
    // Getters
    public Student getStudent() { return student; }
    public Course getCourse() { return course; }
    public Date getEnrollmentDate() { return enrollmentDate; }
    
    @Override
    public String toString() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        return student.getUserID() + "," + course.getCourseCode() + "," + sdf.format(enrollmentDate);
    }
}