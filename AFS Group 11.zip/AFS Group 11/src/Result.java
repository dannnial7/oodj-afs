/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Muhammad Aamer Ali
 */
public class Result {
    private String studentID;
    private String courseCode;
    private String assessmentType;
    private double marks;
    private String grade;
    private String feedback;
    private String lecturerID;
    
    // Constructor with grade parameter (grade comes from file)
    public Result(String studentID, String courseCode, String assessmentType, 
                  double marks, String grade, String feedback, String lecturerID) {
        this.studentID = studentID;
        this.courseCode = courseCode;
        this.assessmentType = assessmentType;
        this.marks = marks;
        this.grade = grade;
        this.feedback = feedback;
        this.lecturerID = lecturerID;
    }
    
    // Getters
    public String getStudentID() { return studentID; }
    public String getCourseCode() { return courseCode; }
    public String getAssessmentType() { return assessmentType; }
    public double getMarks() { return marks; }
    public String getGrade() { return grade; }
    public String getFeedback() { return feedback; }
    public String getLecturerID() { return lecturerID; }
    
    @Override
    public String toString() {
        return studentID + "," + courseCode + "," + assessmentType + "," + 
               marks + "," + grade + "," + feedback + "," + lecturerID;
    }
}