/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Muhammad Aamer Ali
 */
public class Course {
    private String courseCode;
    private String courseName;
    private String lecturerID;
    
    public Course(String courseCode, String courseName, String lecturerID) {
        this.courseCode = courseCode;
        this.courseName = courseName;
        this.lecturerID = lecturerID;
    }
    
    // Getters and Setters
    public String getCourseCode() { return courseCode; }
    public void setCourseCode(String courseCode) { this.courseCode = courseCode; }
    
    public String getCourseName() { return courseName; }
    public void setCourseName(String courseName) { this.courseName = courseName; }
    
    public String getLecturerID() { return lecturerID; }
    public void setLecturerID(String lecturerID) { this.lecturerID = lecturerID; }
    
    @Override
    public String toString() {
        return courseCode + "," + courseName + "," + lecturerID;
    }
}
