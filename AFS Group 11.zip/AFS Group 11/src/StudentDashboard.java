/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Muhammad Aamer Ali
 */
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.ArrayList;

public class StudentDashboard extends JFrame {
    private Student student;
    private JLabel welcomeLabel;
    private JTable infoTable;
    private JTable resultsTable;
    private JTable coursesTable;
    private DefaultTableModel infoTableModel;
    private DefaultTableModel resultsTableModel;
    private DefaultTableModel coursesTableModel;
    private JButton refreshButton;
    private JButton notificationButton;
    private JLabel notificationBadge;
    
    // Statistics labels
    private JLabel cgpaLabel, totalAssessmentsLabel, avgScoreLabel, bestScoreLabel, gradeDistLabel, statusLabel;
    private JProgressBar cgpaProgressBar;
    
    // Courses tab components
    private JLabel coursesSummaryLabel;
    private JPanel coursesPanel;
    private JTabbedPane tabbedPane;
    
    public StudentDashboard(Student student) {
        this.student = student;
        
        setTitle("AFS - Student Dashboard - Asia Pacific University");
        setSize(1000, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        
        // ====== TOP PANEL WITH APU LOGO AND WELCOME ======
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBackground(new Color(0, 51, 102));
        topPanel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));

        // Left: Logo Panel
        JPanel logoPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        logoPanel.setBackground(new Color(0, 51, 102));

        JLabel apuLogo;

        // IMPROVED LOGO LOADING CODE - Try multiple locations
        ImageIcon originalIcon = null;
        String[] possiblePaths = {
            "logo_apu.jpg",                              // Current directory
            "src/logo_apu.jpg",                          // src folder
            "resources/logo_apu.jpg",                    // resources folder
            System.getProperty("user.dir") + "/logo_apu.jpg",  // Absolute path from current dir
            "/logo_apu.jpg",                             // Classpath root
            "C:/Users/Muhammad Aamer Ali/Documents/NetBeansProjects/Student/logo_apu.jpg"  // Your specific path
        };

        System.out.println("Current directory: " + System.getProperty("user.dir"));

        for (String path : possiblePaths) {
            try {
                File imgFile = new File(path);
                System.out.println("Checking: " + path + " -> exists: " + imgFile.exists());
                
                if (imgFile.exists()) {
                    originalIcon = new ImageIcon(path);
                    System.out.println("✓ Logo found at: " + path);
                    break;
                }
                
                // Also try as resource
                java.net.URL resourceUrl = getClass().getResource(path.startsWith("/") ? path : "/" + path);
                if (resourceUrl != null) {
                    originalIcon = new ImageIcon(resourceUrl);
                    System.out.println("✓ Logo found as resource: " + path);
                    break;
                }
            } catch (Exception e) {
                // Continue to next path
            }
        }

        if (originalIcon != null && originalIcon.getIconWidth() > 0) {
            // Resize logo
            Image resizedImage = originalIcon.getImage().getScaledInstance(40, 40, Image.SCALE_SMOOTH);
            apuLogo = new JLabel(new ImageIcon(resizedImage));
            System.out.println("✓ Logo loaded successfully. Size: " + 
                              originalIcon.getIconWidth() + "x" + originalIcon.getIconHeight());
        } else {
            // Fallback if logo not found
            System.err.println("✗ Could not load logo_apu.jpg. Using fallback text.");
            apuLogo = new JLabel("🎓 APU");
            apuLogo.setFont(new Font("Arial", Font.BOLD, 24));
            apuLogo.setForeground(Color.WHITE);
        }
        
        JLabel apuText = new JLabel("Asia Pacific University of Technology & Innovation");
        apuText.setFont(new Font("Arial", Font.PLAIN, 12));
        apuText.setForeground(new Color(200, 220, 255));

        logoPanel.add(apuLogo);
        logoPanel.add(Box.createHorizontalStrut(10));
        logoPanel.add(apuText);

        // Right: Welcome message and notification
        JPanel welcomePanel = new JPanel(new BorderLayout());
        welcomePanel.setBackground(new Color(0, 51, 102));

        JPanel welcomeTextPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        welcomeTextPanel.setBackground(new Color(0, 51, 102));

        welcomeLabel = new JLabel("Welcome, " + student.getName() + "!");
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 18));
        welcomeLabel.setForeground(Color.WHITE);

        JLabel idLabel = new JLabel("[" + student.getUserID() + "]");
        idLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        idLabel.setForeground(new Color(200, 220, 255));

        welcomeTextPanel.add(welcomeLabel);
        welcomeTextPanel.add(Box.createHorizontalStrut(10));
        welcomeTextPanel.add(idLabel);

        // Notification button with badge
        JPanel notificationPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        notificationPanel.setBackground(new Color(0, 51, 102));

        notificationButton = new JButton("🔔");
        notificationButton.setBackground(new Color(255, 193, 7));
        notificationButton.setForeground(Color.WHITE);
        notificationButton.setFont(new Font("Arial", Font.BOLD, 14));
        notificationButton.setFocusPainted(false);
        notificationButton.setBorder(BorderFactory.createEmptyBorder(8, 12, 8, 12));
        notificationButton.setCursor(new Cursor(Cursor.HAND_CURSOR));

        // Create badge for notification count
        notificationBadge = new JLabel("0");
        notificationBadge.setFont(new Font("Arial", Font.BOLD, 10));
        notificationBadge.setForeground(Color.WHITE);
        notificationBadge.setBackground(Color.RED);
        notificationBadge.setOpaque(true);
        notificationBadge.setBorder(BorderFactory.createEmptyBorder(2, 5, 2, 5));
        notificationBadge.setVisible(false);

        notificationButton.setLayout(new OverlayLayout(notificationButton));
        notificationBadge.setAlignmentX(1.0f);
        notificationBadge.setAlignmentY(0.0f);
        notificationButton.add(notificationBadge);

        notificationPanel.add(notificationButton);

        welcomePanel.add(welcomeTextPanel, BorderLayout.CENTER);
        welcomePanel.add(notificationPanel, BorderLayout.EAST);

        topPanel.add(logoPanel, BorderLayout.WEST);
        topPanel.add(welcomePanel, BorderLayout.EAST);
        
        // ====== MAIN CONTENT AREA ======
        tabbedPane = new JTabbedPane();
        tabbedPane.setFont(new Font("Arial", Font.BOLD, 12));
        
        // Tab 1: Student Information
        JPanel infoPanel = createInfoPanel();
        tabbedPane.addTab("📋 Student Information", infoPanel);
        
        // Tab 2: Enrolled Courses
        coursesPanel = createCoursesPanel();
        tabbedPane.addTab("📚 Enrolled Modules", coursesPanel);
        
        // Tab 3: Recent Results with Statistics
        JPanel resultsPanel = createResultsPanel();
        tabbedPane.addTab("📊 Academic Performance", resultsPanel);
        
        // ====== SIDEBAR MENU ======
        JPanel menuPanel = new JPanel(new GridLayout(6, 1, 10, 10));
        menuPanel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(0, 51, 102), 2), 
            "Navigation Menu"
        ));
        menuPanel.setBackground(new Color(240, 245, 250));
        
        JButton profileButton = createMenuButton("👤 Edit Profile", Color.decode("#4CAF50"));
        JButton registerButton = createMenuButton("📝 Register Modules", Color.decode("#2196F3"));
        JButton resultsButton = createMenuButton("📊 Detailed Results", Color.decode("#FF9800"));
        JButton commentsButton = createMenuButton("💬 Comment to Lecturer", Color.decode("#9C27B0"));
        JButton notificationsMenuButton = createMenuButton("🔔 Notifications", Color.decode("#FFC107"));
        JButton logoutButton = createMenuButton("🚪 Logout", Color.decode("#F44336"));
        
        menuPanel.add(profileButton);
        menuPanel.add(registerButton);
        menuPanel.add(resultsButton);
        menuPanel.add(commentsButton);
        menuPanel.add(notificationsMenuButton);
        menuPanel.add(logoutButton);
        
        // ====== FOOTER PANEL WITH REFRESH BUTTON ======
        JPanel footerPanel = new JPanel(new BorderLayout());
        footerPanel.setBackground(new Color(240, 240, 240));
        footerPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(1, 0, 0, 0, Color.GRAY),
            BorderFactory.createEmptyBorder(10, 20, 10, 20)
        ));
        
        JLabel statusLabel = new JLabel("🟢 System Status: Online | AFS Student Module v1.0");
        statusLabel.setFont(new Font("Arial", Font.PLAIN, 12));
        statusLabel.setForeground(Color.DARK_GRAY);
        
        JPanel refreshPanel = new JPanel();
        refreshButton = new JButton("🔄 Refresh Dashboard");
        refreshButton.setBackground(new Color(0, 102, 204));
        refreshButton.setForeground(Color.WHITE);
        refreshButton.setFont(new Font("Arial", Font.BOLD, 12));
        refreshButton.setFocusPainted(false);
        refreshButton.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(0, 51, 102), 1),
            BorderFactory.createEmptyBorder(8, 20, 8, 20)
        ));
        
        JLabel copyrightLabel = new JLabel("© 2025 Asia Pacific University - Assessment Feedback System");
        copyrightLabel.setFont(new Font("Arial", Font.PLAIN, 10));
        copyrightLabel.setForeground(Color.GRAY);
        
        refreshPanel.add(refreshButton);
        
        footerPanel.add(statusLabel, BorderLayout.WEST);
        footerPanel.add(refreshPanel, BorderLayout.CENTER);
        footerPanel.add(copyrightLabel, BorderLayout.EAST);
        
        // ====== ADD ALL PANELS TO FRAME ======
        add(topPanel, BorderLayout.NORTH);
        add(menuPanel, BorderLayout.WEST);
        add(tabbedPane, BorderLayout.CENTER);
        add(footerPanel, BorderLayout.SOUTH);
        
        // ====== ACTION LISTENERS ======
        refreshButton.addActionListener(e -> refreshDashboard());
        profileButton.addActionListener(e -> openEditProfile());
        registerButton.addActionListener(e -> openCourseRegistration());
        resultsButton.addActionListener(e -> openViewResults());
        commentsButton.addActionListener(e -> openCommentFrame());
        notificationsMenuButton.addActionListener(e -> openNotifications());
        notificationButton.addActionListener(e -> openNotifications());
        logoutButton.addActionListener(e -> logout());
        
        // Initial load
        refreshDashboard();
    }
    
    private JButton createMenuButton(String text, Color color) {
        JButton button = new JButton(text);
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createRaisedBevelBorder(),
            BorderFactory.createEmptyBorder(10, 15, 10, 15)
        ));
        button.setPreferredSize(new Dimension(180, 50));
        return button;
    }
    
    private JPanel createInfoPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        panel.setBackground(Color.WHITE);
        
        JLabel titleLabel = new JLabel("Student Information", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        titleLabel.setForeground(new Color(0, 51, 102));
        titleLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 15, 0));
        
        String[] columns = {"Field", "Value"};
        infoTableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        infoTable = new JTable(infoTableModel);
        infoTable.setRowHeight(35);
        infoTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 13));
        infoTable.setFont(new Font("Arial", Font.PLAIN, 13));
        infoTable.setGridColor(new Color(220, 220, 220));
        
        infoTable.getTableHeader().setBackground(new Color(0, 51, 102));
        infoTable.getTableHeader().setForeground(Color.WHITE);
        
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        infoTable.getColumnModel().getColumn(0).setCellRenderer(centerRenderer);
        infoTable.getColumnModel().getColumn(1).setCellRenderer(centerRenderer);
        
        infoTable.getColumnModel().getColumn(0).setPreferredWidth(150);
        infoTable.getColumnModel().getColumn(1).setPreferredWidth(250);
        
        JScrollPane scrollPane = new JScrollPane(infoTable);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200), 1));
        
        panel.add(titleLabel, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);
        
        return panel;
    }
    
    private JPanel createCoursesPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        panel.setBackground(Color.WHITE);
        
        JLabel titleLabel = new JLabel("📚 Enrolled Modules", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        titleLabel.setForeground(new Color(0, 51, 102));
        titleLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 15, 0));
        
        String[] columns = {"Module Code", "Module Name", "Lecturer", "Status"};
        coursesTableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        coursesTable = new JTable(coursesTableModel);
        coursesTable.setRowHeight(28);
        coursesTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 12));
        coursesTable.setFont(new Font("Arial", Font.PLAIN, 12));
        coursesTable.setGridColor(new Color(220, 220, 220));
        
        coursesTable.getTableHeader().setBackground(new Color(0, 51, 102));
        coursesTable.getTableHeader().setForeground(Color.WHITE);
        
        JPanel summaryPanel = new JPanel(new BorderLayout());
        summaryPanel.setBorder(BorderFactory.createEmptyBorder(10, 0, 15, 0));
        
        coursesSummaryLabel = new JLabel("📊 Total Enrolled Modules: 0");
        coursesSummaryLabel.setFont(new Font("Arial", Font.BOLD, 14));
        coursesSummaryLabel.setForeground(new Color(0, 51, 102));
        
        summaryPanel.add(coursesSummaryLabel, BorderLayout.WEST);
        
        panel.add(titleLabel, BorderLayout.NORTH);
        panel.add(summaryPanel, BorderLayout.SOUTH);
        panel.add(new JScrollPane(coursesTable), BorderLayout.CENTER);
        
        return panel;
    }
    
    // Method to refresh modules table data
    private void refreshCoursesTableData() {
        // Clear existing data
        coursesTableModel.setRowCount(0);
        
        // Get updated enrolled modules from FileManager
        ArrayList<Course> enrolledCourses = FileManager.getInstance().getEnrolledCourses(student.getUserID());
        
        // Add modules to table
        for (Course course : enrolledCourses) {
            coursesTableModel.addRow(new Object[]{
                course.getCourseCode(),
                course.getCourseName(),
                course.getLecturerID(),
                "✅ Enrolled"
            });
        }
        
        // Update summary label
        if (coursesSummaryLabel != null) {
            coursesSummaryLabel.setText("📊 Total Enrolled Modules: " + enrolledCourses.size());
        }
    }
    
    private JPanel createResultsPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        panel.setBackground(Color.WHITE);
        
        JLabel titleLabel = new JLabel("📊 Assessment Results & Academic Performance", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        titleLabel.setForeground(new Color(0, 51, 102));
        titleLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));
        
        String[] columns = {"Module", "Assessment", "Marks", "Grade", "Grade Points", "Feedback"};
        resultsTableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        resultsTable = new JTable(resultsTableModel);
        resultsTable.setRowHeight(30);
        resultsTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 13));
        resultsTable.setFont(new Font("Arial", Font.PLAIN, 13));
        resultsTable.setGridColor(new Color(220, 220, 220));
        
        resultsTable.getTableHeader().setBackground(new Color(0, 51, 102));
        resultsTable.getTableHeader().setForeground(Color.WHITE);
        
        resultsTable.getColumnModel().getColumn(0).setPreferredWidth(80);
        resultsTable.getColumnModel().getColumn(1).setPreferredWidth(120);
        resultsTable.getColumnModel().getColumn(2).setPreferredWidth(70);
        resultsTable.getColumnModel().getColumn(3).setPreferredWidth(60);
        resultsTable.getColumnModel().getColumn(4).setPreferredWidth(90);
        resultsTable.getColumnModel().getColumn(5).setPreferredWidth(200);
        
        JScrollPane tableScrollPane = new JScrollPane(resultsTable);
        tableScrollPane.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200), 1));
        
        JPanel statsPanel = createStatisticsPanel();
        
        panel.add(titleLabel, BorderLayout.NORTH);
        panel.add(tableScrollPane, BorderLayout.CENTER);
        panel.add(statsPanel, BorderLayout.SOUTH);
        
        return panel;
    }
    
    private JPanel createStatisticsPanel() {
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(new Color(0, 51, 102), 2),
                "📈 Academic Performance Statistics"
            ),
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        mainPanel.setBackground(new Color(245, 248, 252));
        
        JPanel gridPanel = new JPanel(new GridLayout(2, 3, 15, 15));
        gridPanel.setBackground(new Color(245, 248, 252));
        
        JPanel cgpaPanel = createSimpleStatCard("🎓 Cumulative GPA (CGPA)", 
            "Based on APU grading system", 
            new Color(41, 128, 185),
            "0.00");
        cgpaLabel = findCenterLabel(cgpaPanel);
        
        JPanel totalPanel = createSimpleStatCard("📋 Total Assessments", 
            "Number of completed assessments", 
            new Color(39, 174, 96),
            "0");
        totalAssessmentsLabel = findCenterLabel(totalPanel);
        
        JPanel avgPanel = createSimpleStatCard("📊 Average Score", 
            "Mean of all assessment marks", 
            new Color(241, 196, 15),
            "0.00");
        avgScoreLabel = findCenterLabel(avgPanel);
        
        JPanel bestPanel = createSimpleStatCard("⭐ Best Score", 
            "Highest marks achieved", 
            new Color(155, 89, 182),
            "0.00");
        bestScoreLabel = findCenterLabel(bestPanel);
        
        JPanel gradePanel = createSimpleStatCard("📈 Grade Distribution", 
            "APU Grading System: A(85-100), B(70-84), C(55-69), D(40-54), F(<40)", 
            new Color(231, 76, 60),
            "A:0");
        gradeDistLabel = findCenterLabel(gradePanel);
        
        JPanel statusPanel = createSimpleStatCard("📊 Performance Status", 
            "Based on CGPA and marks", 
            new Color(230, 126, 34),
            "Good");
        statusLabel = findCenterLabel(statusPanel);
        
        gridPanel.add(cgpaPanel);
        gridPanel.add(totalPanel);
        gridPanel.add(avgPanel);
        gridPanel.add(bestPanel);
        gridPanel.add(gradePanel);
        gridPanel.add(statusPanel);
        
        JPanel progressPanel = new JPanel(new BorderLayout());
        progressPanel.setBorder(BorderFactory.createEmptyBorder(15, 0, 0, 0));
        
        JLabel progressLabel = new JLabel("CGPA Progress (APU Grading Scale 0.00 - 4.00):");
        progressLabel.setFont(new Font("Arial", Font.BOLD, 12));
        progressLabel.setForeground(new Color(0, 51, 102));
        
        cgpaProgressBar = new JProgressBar(0, 400);
        cgpaProgressBar.setValue(0);
        cgpaProgressBar.setStringPainted(true);
        cgpaProgressBar.setFont(new Font("Arial", Font.BOLD, 12));
        cgpaProgressBar.setForeground(new Color(41, 128, 185));
        cgpaProgressBar.setBackground(new Color(230, 230, 230));
        cgpaProgressBar.setBorder(BorderFactory.createLineBorder(new Color(0, 51, 102), 1));
        cgpaProgressBar.setString("0.00 / 4.00");
        
        progressPanel.add(progressLabel, BorderLayout.NORTH);
        progressPanel.add(cgpaProgressBar, BorderLayout.CENTER);
        
        mainPanel.add(gridPanel, BorderLayout.CENTER);
        mainPanel.add(progressPanel, BorderLayout.SOUTH);
        
        return mainPanel;
    }
    
    private JLabel findCenterLabel(JPanel card) {
        for (Component comp : card.getComponents()) {
            if (comp instanceof JLabel) {
                JLabel label = (JLabel) comp;
                if (card.getLayout() instanceof BorderLayout) {
                    BorderLayout layout = (BorderLayout) card.getLayout();
                    if (layout.getLayoutComponent(BorderLayout.CENTER) == comp) {
                        return label;
                    }
                }
            }
        }
        return null;
    }
    
    private JPanel createSimpleStatCard(String title, String subtitle, Color color, String value) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(color, 1),
            BorderFactory.createEmptyBorder(10, 15, 10, 15)
        ));
        
        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 12));
        titleLabel.setForeground(color);
        
        JLabel subtitleLabel = new JLabel("<html><div style='width: 150px;'>" + subtitle + "</div></html>");
        subtitleLabel.setFont(new Font("Arial", Font.PLAIN, 9));
        subtitleLabel.setForeground(Color.DARK_GRAY);
        
        JLabel valueLabel = new JLabel(value, SwingConstants.CENTER);
        valueLabel.setFont(new Font("Arial", Font.BOLD, 20));
        valueLabel.setForeground(color);
        valueLabel.setBorder(BorderFactory.createEmptyBorder(5, 0, 5, 0));
        
        JPanel titlePanel = new JPanel(new BorderLayout());
        titlePanel.setBackground(Color.WHITE);
        titlePanel.add(titleLabel, BorderLayout.NORTH);
        titlePanel.add(subtitleLabel, BorderLayout.SOUTH);
        
        card.add(titlePanel, BorderLayout.NORTH);
        card.add(valueLabel, BorderLayout.CENTER);
        
        return card;
    }
    
    /**
     * Load results directly from results.txt file
     */
    private ArrayList<Result> loadResultsFromMarksFile() {
        ArrayList<Result> results = new ArrayList<>();
        String studentId = student.getUserID();
        
        File marksFile = new File("data_files/results.txt");
        
        if (!marksFile.exists()) {
            System.out.println("⚠ results.txt not found in: " + System.getProperty("user.dir"));
            System.out.println("Please ensure results.txt exists in the project root directory.");
            return results;
        }
        
        try (BufferedReader reader = new BufferedReader(new FileReader(marksFile))) {
            String line;
            boolean isFirstLine = true;
            int lineCount = 0;
            int matchCount = 0;
            
            System.out.println("📁 Reading results.txt for student ID: " + studentId);
            
            while ((line = reader.readLine()) != null) {
                lineCount++;
                line = line.trim();
                
                // Skip empty lines
                if (line.isEmpty()) {
                    continue;
                }
                
                // Skip header line if it exists
                if (isFirstLine) {
                    isFirstLine = false;
                    if (line.toLowerCase().contains("studentid") || 
                        line.toLowerCase().contains("student")) {
                        System.out.println("  Skipping header line: " + line);
                        continue;
                    }
                }
                
                // Parse the line - split by comma
                String[] parts = line.split(",");
                
                // Check if it's a valid line with all required fields
                if (parts.length >= 7) {
                    String fileStudentId = parts[0].trim().replace("\"", "").replace("'", "");
                    
                    // Only add results for this student
                    if (fileStudentId.equals(studentId)) {
                        matchCount++;
                        String assessmentId = parts[1].trim().replace("\"", "").replace("'", ""); // AssessmentID
                        String description = parts[2].trim().replace("\"", "").replace("'", ""); // Description (Module Code)
                        double marks;
                        try {
                            marks = Double.parseDouble(parts[3].trim().replace("\"", "").replace("'", ""));
                        } catch (NumberFormatException e) {
                            System.out.println("  ⚠ Error parsing marks: " + parts[3]);
                            marks = 0.0;
                        }
                        String grade = parts[4].trim().replace("\"", "").replace("'", ""); // Grade from file
                        String feedback = parts[5].trim().replace("\"", "").replace("'", ""); // Feedback
                        String lecturerId = parts[6].trim().replace("\"", "").replace("'", ""); // LecturerID
                        
                        // Create Result object using the 7-parameter constructor
                        Result result = new Result(
                            studentId,        // studentID
                            description,      // courseCode
                            assessmentId,     // assessmentType
                            marks,            // marks
                            grade,            // grade (from file)
                            feedback,         // feedback
                            lecturerId        // lecturerID
                        );
                        
                        results.add(result);
                        System.out.println("  ✓ Loaded: " + description + " - " + assessmentId + 
                                         ", Marks: " + marks + ", Grade: " + grade);
                    }
                }
            }
            
            System.out.println("📊 Loaded " + results.size() + " results for student " + studentId + 
                             " (matched " + matchCount + " lines)");
            
        } catch (FileNotFoundException e) {
            System.err.println("❌ results.txt not found: " + e.getMessage());
            JOptionPane.showMessageDialog(this,
                "results.txt file not found in: " + System.getProperty("user.dir") + 
                "\n\nPlease ensure the file exists in the project root directory.",
                "File Not Found",
                JOptionPane.WARNING_MESSAGE);
        } catch (IOException e) {
            System.err.println("❌ Error reading results.txt: " + e.getMessage());
            e.printStackTrace();
        }
        
        return results;
    }
    
    // Refresh dashboard with data from results.txt
    public void refreshDashboard() {
        System.out.println("\n========== REFRESHING DASHBOARD ==========");
        
        // Update welcome label
        welcomeLabel.setText("Welcome, " + student.getName() + "!");
        
        // Update notification badge
        updateNotificationBadge();
        
        // Refresh Student Information Table
        infoTableModel.setRowCount(0);
        infoTableModel.addRow(new Object[]{"Student ID", student.getUserID()});
        infoTableModel.addRow(new Object[]{"Full Name", student.getName()});
        infoTableModel.addRow(new Object[]{"Email Address", student.getEmail()});
        infoTableModel.addRow(new Object[]{"Account Type", student.getRole()});
        
        // Refresh Enrolled Courses Table
        refreshCoursesTableData();
        
        // Refresh Results Table - Read from results.txt directly
        resultsTableModel.setRowCount(0);
        ArrayList<Result> results = loadResultsFromMarksFile();
        
        // Calculate statistics
        double totalMarks = 0;
        double bestMarks = 0;
        double totalGradePoints = 0;
        int totalAssessments = results.size();
        int gradeA = 0, gradeB = 0, gradeC = 0, gradeD = 0, gradeF = 0;

        System.out.println("📈 Processing " + totalAssessments + " results for statistics...");
        
        if (totalAssessments == 0) {
            // Add a message row if no results
            resultsTableModel.addRow(new Object[]{
                "No results", "No assessments", "N/A", "N/A", "N/A", 
                "No feedback available"
            });
            System.out.println("  No results to display");
        } else {
            for (Result result : results) {
                String feedback = result.getFeedback();
                if (feedback != null && feedback.length() > 40) {
                    feedback = feedback.substring(0, 40) + "...";
                }
                
                double marks = result.getMarks();
                String grade = result.getGrade();
                
                double gradePoints = getGradePointsFromMarks(marks);
                
                resultsTableModel.addRow(new Object[]{
                    result.getCourseCode(),
                    result.getAssessmentType(),
                    String.format("%.1f", marks),
                    grade,
                    String.format("%.2f", gradePoints),
                    feedback
                });
                
                totalMarks += marks;
                totalGradePoints += gradePoints;
                
                if (marks > bestMarks) bestMarks = marks;
                
                if (marks >= 85) gradeA++;
                else if (marks >= 70) gradeB++;
                else if (marks >= 55) gradeC++;
                else if (marks >= 40) gradeD++;
                else gradeF++;
            }
        }

        double overallAvg = totalAssessments > 0 ? totalMarks / totalAssessments : 0;
        double cgpa = totalAssessments > 0 ? totalGradePoints / totalAssessments : 0;
        String performanceStatus = getPerformanceStatus(cgpa);
        
        System.out.println("📊 Statistics Calculated:");
        System.out.println("  • Total Assessments: " + totalAssessments);
        System.out.println("  • Average Score: " + String.format("%.2f", overallAvg));
        System.out.println("  • CGPA: " + String.format("%.2f", cgpa));
        System.out.println("  • Best Score: " + String.format("%.1f", bestMarks));
        System.out.println("  • Grade Distribution - A:" + gradeA + " B:" + gradeB + 
                          " C:" + gradeC + " D:" + gradeD + " F:" + gradeF);
        System.out.println("  • Performance Status: " + performanceStatus);
        
        updateStatistics(totalAssessments, overallAvg, cgpa, bestMarks,
                        gradeA, gradeB, gradeC, gradeD, gradeF, performanceStatus);
        
        // Get current enrolled courses count
        int enrolledCount = FileManager.getInstance().getEnrolledCourses(student.getUserID()).size();
        
        System.out.println("✅ Dashboard refresh complete!");
        System.out.println("========================================\n");
        
        if (totalAssessments > 0) {
            JOptionPane.showMessageDialog(this, 
                "✅ Dashboard has been refreshed!\n\n" +
                "🎓 CGPA: " + String.format("%.2f", cgpa) + "\n" +
                "📚 Enrolled Modules: " + enrolledCount + "\n" +
                "📊 Assessment Results: " + totalAssessments + "\n" +
                "📈 Average Score: " + String.format("%.2f", overallAvg), 
                "Refresh Complete", JOptionPane.INFORMATION_MESSAGE);
        }
    }
    
    private double getGradePointsFromMarks(double marks) {
        if (marks >= 85) return 4.00;
        else if (marks >= 80) return 3.70;
        else if (marks >= 75) return 3.30;
        else if (marks >= 70) return 3.00;
        else if (marks >= 65) return 2.70;
        else if (marks >= 60) return 2.30;
        else if (marks >= 55) return 2.00;
        else if (marks >= 50) return 1.70;
        else if (marks >= 45) return 1.30;
        else if (marks >= 40) return 1.00;
        else return 0.00;
    }
    
    private String getGradeFromMarks(double marks) {
        if (marks >= 85) return "A";
        else if (marks >= 80) return "A-";
        else if (marks >= 75) return "B+";
        else if (marks >= 70) return "B";
        else if (marks >= 65) return "B-";
        else if (marks >= 60) return "C+";
        else if (marks >= 55) return "C";
        else if (marks >= 50) return "C-";
        else if (marks >= 45) return "D+";
        else if (marks >= 40) return "D";
        else return "F";
    }
    
    private String getPerformanceStatus(double cgpa) {
        if (cgpa >= 3.50) return "Excellent";
        else if (cgpa >= 3.00) return "Very Good";
        else if (cgpa >= 2.50) return "Good";
        else if (cgpa >= 2.00) return "Satisfactory";
        else if (cgpa >= 1.00) return "Pass";
        else return "Fail";
    }
    
    private void updateStatistics(int totalAssessments, double overallAvg, double cgpa,
                                double bestMarks, int gradeA, int gradeB, int gradeC, 
                                int gradeD, int gradeF, String performanceStatus) {
        
        if (cgpaLabel != null) {
            cgpaLabel.setText(String.format("%.2f", cgpa));
        }
        
        if (totalAssessmentsLabel != null) {
            totalAssessmentsLabel.setText(String.valueOf(totalAssessments));
        }
        
        if (avgScoreLabel != null) {
            avgScoreLabel.setText(String.format("%.2f", overallAvg));
        }
        
        if (bestScoreLabel != null) {
            bestScoreLabel.setText(String.format("%.1f", bestMarks));
        }
        
        // Show full grade distribution with HTML for better formatting
        if (gradeDistLabel != null) {
            if (totalAssessments > 0) {
                gradeDistLabel.setText("<html><center>A:" + gradeA + " B:" + gradeB + 
                                      "<br>C:" + gradeC + " D:" + gradeD + " F:" + gradeF + "</center></html>");
            } else {
                gradeDistLabel.setText("No grades");
            }
        }
        
        if (statusLabel != null) {
            statusLabel.setText(performanceStatus);
        }
        
        if (cgpaProgressBar != null) {
            int cgpaValue = (int)(cgpa * 100);
            cgpaProgressBar.setValue(cgpaValue);
            cgpaProgressBar.setString(String.format("%.2f / 4.00", cgpa));
            
            if (cgpa >= 3.50) {
                cgpaProgressBar.setForeground(new Color(39, 174, 96)); // Green
            } else if (cgpa >= 3.00) {
                cgpaProgressBar.setForeground(new Color(52, 152, 219)); // Blue
            } else if (cgpa >= 2.50) {
                cgpaProgressBar.setForeground(new Color(241, 196, 15)); // Yellow
            } else if (cgpa >= 2.00) {
                cgpaProgressBar.setForeground(new Color(230, 126, 34)); // Orange
            } else {
                cgpaProgressBar.setForeground(new Color(231, 76, 60)); // Red
            }
        }
    }
    
    private void updateNotificationBadge() {
        ArrayList<String> notifications = student.getUnreadNotifications();
        int unreadCount = notifications.size();
        
        if (unreadCount > 0) {
            notificationBadge.setText(String.valueOf(unreadCount));
            notificationBadge.setVisible(true);
            notificationButton.setBackground(new Color(255, 87, 34));
            notificationButton.setText("🔔 ");
        } else {
            notificationBadge.setVisible(false);
            notificationButton.setBackground(new Color(255, 193, 7));
            notificationButton.setText("🔔");
        }
    }
    
    private void openEditProfile() {
        new EditProfileFrame(student).setVisible(true);
    }
    
    private void openCourseRegistration() {
        new CourseRegistrationFrame(student, this).setVisible(true);
    }
    
    private void openViewResults() {
        new ViewResultsFrame(student).setVisible(true);
    }
    
    private void openCommentFrame() {
        new CommentFrame(student).setVisible(true);
    }
    
    private void openNotifications() {
        new NotificationFrame(student).setVisible(true);
        updateNotificationBadge();
    }
    
    private void logout() {
        int confirm = JOptionPane.showConfirmDialog(this, 
            "Are you sure you want to logout?", 
            "Confirm Logout", JOptionPane.YES_NO_OPTION);
        
        if (confirm == JOptionPane.YES_OPTION) {
            this.dispose();
            new LoginFrame().setVisible(true);
        }
    }
}