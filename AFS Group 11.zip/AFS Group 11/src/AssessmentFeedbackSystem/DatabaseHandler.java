package AssessmentFeedbackSystem;

import java.io.*;
import java.util.*;

public class DatabaseHandler {
    private static final String SEPARATOR = ",";

    private static final String DATA_DIR = "data_files/";

    private static final String MODULES_FILE = DATA_DIR + "modules.txt";
    private static final String USERS_FILE = DATA_DIR + "users.txt";
    private static final String CLASSES_FILE = DATA_DIR + "classes.txt";
    private static final String ASSESSMENTS_FILE = DATA_DIR + "assessments.txt";
    private static final String RESULTS_FILE = DATA_DIR + "results.txt";
    private static final String LEADER_ASSIGNMENTS_FILE = DATA_DIR + "leader_assignments.txt";

    // ==========================================
    // MODULE METHODS (3 COLUMNS)
    // ==========================================

    // READ: Load all modules (Skips Header)
    public static List<Module> loadModules() {
        List<Module> modules = new ArrayList<>();
        File file = new File(MODULES_FILE);

        if (!file.exists())
            return modules;

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] data = line.split(SEPARATOR, -1); // Keep empty trailing strings
                if (data.length >= 3) {
                    if ("ModuleID".equalsIgnoreCase(data[0].trim())) {
                        continue;
                    }
                    String id = data[0].trim();
                    String name = data[1].trim();
                    String lecID = data[2].trim();

                    // Creates Module using the 6-argument constructor
                    // Note: Stats are now calculated dynamically, so we pass 0s here.
                    modules.add(new Module(id, name, lecID, 0, 0, 0.0));
                }
            }
        } catch (IOException | NumberFormatException e) {
            System.out.println("Error loading modules: " + e.getMessage());
        }
        return modules;
    }

    public static List<Module> getModulesForLeader(String leaderID) {
        List<Module> allModules = loadModules();
        List<String> assignedLecturers = getLecturersForLeader(leaderID);
        List<Module> filteredModules = new ArrayList<>();

        // Fallback: if no assignments exist yet for this leader, show all modules.
        if (assignedLecturers.isEmpty()) {
            return allModules;
        }

        for (Module m : allModules) {
            // Show if:
            // 1. Lecturer is assigned to this Leader
            // 2. OR Module is unassigned (LecturerID is empty or blank)
            // STRICT: Show IF AND ONLY IF Assigned Lecturer is in Leader's List
            if (assignedLecturers.contains(m.getLecturerID())) {
                filteredModules.add(m);
            }
        }
        return filteredModules;
    }

    // APPEND: Add a single new module to the end of the file
    public static void appendModule(Module m) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(MODULES_FILE, true))) {
            // Write Header if file is empty
            if (new File(MODULES_FILE).length() == 0) {
                bw.write("ModuleID,ModuleName,LecturerID");
                bw.newLine();
            }

            bw.write(m.getModuleID() + "," +
                    m.getModuleName() + "," +
                    m.getLecturerID());
            bw.newLine();
        } catch (IOException e) {
            System.out.println("Error appending module: " + e.getMessage());
        }
    }

    // SAFE UPDATE: Updates a specific module without losing others
    public static void updateModule(Module updatedModule) {
        List<Module> allModules = loadModules();
        boolean found = false;
        for (int i = 0; i < allModules.size(); i++) {
            if (allModules.get(i).getModuleID().equals(updatedModule.getModuleID())) {
                allModules.set(i, updatedModule);
                found = true;
                break;
            }
        }
        if (found) {
            rewriteModuleFile(allModules);
        }
    }

    // SAFE DELETE: Deletes a specific module without losing others
    public static void deleteModule(String moduleID) {
        List<Module> allModules = loadModules();
        boolean removed = allModules.removeIf(m -> m.getModuleID().equals(moduleID));
        if (removed) {
            rewriteModuleFile(allModules);
        }
    }

    // REWRITE: Overwrites file with provided list (Internal Use mostly)
    public static void rewriteModuleFile(List<Module> modules) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(MODULES_FILE, false))) {
            bw.write("ModuleID,ModuleName,LecturerID");
            bw.newLine();

            for (Module m : modules) {
                bw.write(m.getModuleID() + "," +
                        m.getModuleName() + "," +
                        m.getLecturerID());
                bw.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error rewriting modules file.");
        }
    }

    public static List<User> loadUsers() {
        List<User> users = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(USERS_FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] data = line.split(",");
                if (data.length >= 6) {
                    if ("UserID".equalsIgnoreCase(data[0].trim())) {
                        continue;
                    }
                    String id = data[0].trim();
                    String pass = data[1].trim();
                    String name = data[2].trim();
                    String email = data[3].trim();
                    String contact = data[4].trim();
                    String role = data[5].trim();

                    // FIX: Now loads BOTH Academic Leaders AND Lecturers
                    if (role.equalsIgnoreCase("Academic Leader")) {
                        users.add(new AcademicLeader(id, pass, name, email, contact));
                    } else if (role.equalsIgnoreCase("Lecturer")) {
                        users.add(new Lecturer(id, pass, name, email, contact));
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("Error loading users.");
        }
        return users;
    }

    // Helper Method required by GUI
    public static String getUserName(String userID) {
        List<User> users = loadUsers();
        for (User u : users) {
            if (u.getId().equalsIgnoreCase(userID)) {
                return u.getName();
            }
        }
        return userID; // Return ID if name not found
    }

    public static void saveUsers(List<User> users) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(USERS_FILE, false))) {
            bw.write("UserID,Password,Name,Email,ContactNum,Role");
            bw.newLine();
            for (User u : users) {
                bw.write(u.getId() + "," + u.getPassword() + "," + u.getName() + "," + u.getEmail() + ","
                        + u.getContactNum() + "," + u.getRole());
                bw.newLine();
            }
        } catch (IOException e) {
        }
    }

    public static User getUser(String userID) {
        List<User> users = loadUsers();
        for (User u : users) {
            if (u.getId().equalsIgnoreCase(userID)) {
                return u;
            }
        }
        return null; // Not found
    }

    public static List<String> getLecturersForLeader(String leaderID) {
        List<String> assignedLecturers = new ArrayList<>();
        File file = new File(LEADER_ASSIGNMENTS_FILE);
        if (!file.exists())
            return assignedLecturers;

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] data = line.split(SEPARATOR);
                if (data.length >= 2) {
                    if ("LeaderID".equalsIgnoreCase(data[0].trim())) {
                        continue;
                    }
                    if (data[0].trim().equalsIgnoreCase(leaderID)) {
                        assignedLecturers.add(data[1].trim());
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("Error loading leader assignments: " + e.getMessage());
        }
        return assignedLecturers;
    }

    // ==========================================
    // NEW METHODS FOR REPORTS
    // ==========================================

    public static int getClassCountForModule(String moduleID) {
        int count = 0;
        File file = new File(CLASSES_FILE);
        if (!file.exists())
            return 0;

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] data = line.split(SEPARATOR);
                if (data.length >= 2) {
                    if ("ClassID".equalsIgnoreCase(data[0].trim())) {
                        continue;
                    }
                    if (data[1].trim().equalsIgnoreCase(moduleID)) {
                        count++;
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("Error loading classes: " + e.getMessage());
        }
        return count;
    }

    private static final String TOTAL_STUDENTS_FILE = DATA_DIR + "total_students.txt";

    public static int getStudentCountForModule(String moduleID) {
        File file = new File(TOTAL_STUDENTS_FILE);
        if (!file.exists())
            return 0;

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] data = line.split(SEPARATOR);
                if (data.length >= 2) {
                    if ("ModuleID".equalsIgnoreCase(data[0].trim())) {
                        continue;
                    }
                    if (data[0].trim().equalsIgnoreCase(moduleID)) {
                        try {
                            return Integer.parseInt(data[1].trim());
                        } catch (NumberFormatException e) {
                            return 0;
                        }
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading total students file: " + e.getMessage());
        }
        return 0;
    }

    // ==========================================
    // FAIL RATE CALCULATION
    // ==========================================

    public static List<Assessment> loadAssessments() {
        List<Assessment> assessments = new ArrayList<>();
        File file = new File(ASSESSMENTS_FILE);
        if (!file.exists())
            return assessments;

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] data = line.split(SEPARATOR);
                if (data.length >= 6) {
                    if ("AssessmentID".equalsIgnoreCase(data[0].trim())) {
                        continue;
                    }
                    assessments.add(new Assessment(
                            data[0].trim(), data[1].trim(), data[2].trim(),
                            Double.parseDouble(data[3].trim()), data[4].trim(), data[5].trim()));
                }
            }
        } catch (IOException | NumberFormatException e) {
        }
        return assessments;
    }

    public static double calculateFailRate(String moduleID) {
        // 1. Get Enrollments (Denominator)
        int totalStudents = getStudentCountForModule(moduleID);
        if (totalStudents == 0)
            return 0.0;

        // 2. Get Assessments for Module
        List<Assessment> allAssessments = loadAssessments();
        List<String> moduleAssessmentIDs = new ArrayList<>();

        for (Assessment a : allAssessments) {
            if (a.getModuleID().equalsIgnoreCase(moduleID)) {
                moduleAssessmentIDs.add(a.getAssessmentID());
            }
        }

        if (moduleAssessmentIDs.isEmpty())
            return 0.0;

        // 3. Calculate Student Totals (Numerator)
        // We only care about students failing based on marks provided
        int failCount = 0;
        File resultsFile = new File(RESULTS_FILE);

        if (resultsFile.exists()) {
            Map<String, Double> studentMarks = new HashMap<>();

            try (BufferedReader br = new BufferedReader(new FileReader(resultsFile))) {
                String line;
                while ((line = br.readLine()) != null) {
                    String[] data = line.split(SEPARATOR);
                    if (data.length < 3) {
                        continue;
                    }
                    if ("AssessmentID".equalsIgnoreCase(data[0].trim())) {
                        continue;
                    }

                    // Support both formats:
                    // A) AssessmentID,StudentID,Marks,...
                    // B) StudentID,AssessmentID,...,Marks,...
                    String first = data[0].trim();
                    String second = data[1].trim();
                    String sID;
                    String aID;
                    double marks;

                    try {
                        if (first.toUpperCase().startsWith("ASS")) {
                            aID = first;
                            sID = second;
                            marks = Double.parseDouble(data[2].trim());
                        } else {
                            sID = first;
                            aID = second;
                            int marksIdx = data.length > 3 ? 3 : 2;
                            marks = Double.parseDouble(data[marksIdx].trim());
                        }
                    } catch (Exception ex) {
                        continue;
                    }

                    if (moduleAssessmentIDs.contains(aID) || moduleID.equalsIgnoreCase(aID)) {
                        studentMarks.put(sID, studentMarks.getOrDefault(sID, 0.0) + marks);
                    }
                }
            } catch (Exception e) {
                System.out.println("Error reading marks: " + e.getMessage());
            }

            // Count failures (Total < 40)
            for (Double total : studentMarks.values()) {
                if (total < 40.0) {
                    failCount++;
                }
            }

            // Adjust fail count if marks are missing for some students?
            // The prompt implies "students failed from results.txt".
            // If a student is enrolled but has NO marks, they theoretically failed (0
            // marks).
            // Logic:
            // Failures = (Failures in results.txt) + (Total Students - Students with Marks)
            // But usually results.txt contains 0 or incomplete entries if tracked properly.
            // I'll stick to counting EXPLICIT failures from results.txt first,
            // unless the calculated fail rate is unusually low.
            // Actually, if we use totalStudents from file as denominator, we should
            // consider
            // meaningful fail count.
            // Let's assume results.txt is comprehensive for active students.

            // However, strictly: "students failed from results.txt"
            // I will adhere to: count strictly solely based on results.txt content.
        }

        return (double) failCount / totalStudents * 100.0;
    }
}
