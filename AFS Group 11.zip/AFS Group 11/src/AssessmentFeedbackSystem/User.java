package AssessmentFeedbackSystem;

public abstract class User {
    protected String id;
    protected String password;
    protected String name;
    protected String email;
    protected String contactNum;

    public User(String id, String password, String name, String email, String contactNum) {
        this.id = id;
        this.password = password;
        this.name = name;
        this.email = email;
        this.contactNum = contactNum;
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public String getPassword() { return password; } // NEEDED FOR SAVING
    public String getEmail() { return email; }
    public String getContactNum() { return contactNum; }
    
    public boolean checkPassword(String input) { return this.password.equals(input); }
    public abstract String getRole();
}