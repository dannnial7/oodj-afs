package AssessmentFeedbackSystem;

public class Assessment {
    private String assessmentID;
    private String moduleID;
    private String description;
    private double maxMarks;
    private String dueDate;
    private String createdBy;

    public Assessment(String id, String modID, String desc, double marks, String due, String creator) {
        this.assessmentID = id;
        this.moduleID = modID;
        this.description = desc;
        this.maxMarks = marks;
        this.dueDate = due;
        this.createdBy = creator;
    }

    public String getModuleID() {
        return moduleID;
    }

    public String getAssessmentID() {
        return assessmentID;
    }

    public String getDescription() {
        return description;
    }
}
