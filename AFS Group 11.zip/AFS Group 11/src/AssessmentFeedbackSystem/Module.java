package AssessmentFeedbackSystem;

public class Module {
    private String moduleID;
    private String moduleName;
    private String lecturerID;
    // New Fields
    private int totalStudents;
    private int classCount;
    private double failRate;

    public Module(String moduleID, String moduleName, String lecturerID, int totalStudents, int classCount,
            double failRate) {
        this.moduleID = moduleID;
        this.moduleName = moduleName;
        this.lecturerID = lecturerID;
        this.totalStudents = totalStudents;
        this.classCount = classCount;
        this.failRate = failRate;
    }

    // Getters
    public String getModuleID() {
        return moduleID;
    }

    public String getModuleName() {
        return moduleName;
    }

    public String getLecturerID() {
        return lecturerID;
    }

    public int getTotalStudents() {
        return totalStudents;
    }

    public int getClassCount() {
        return classCount;
    }

    public double getFailRate() {
        return failRate;
    }

    // Setters
    public void setLecturerID(String lecturerID) {
        this.lecturerID = lecturerID;
    }

    public void setModuleName(String moduleName) {
        this.moduleName = moduleName;
    }

    @Override
    public String toString() {
        return moduleID + " - " + moduleName;
    }
}