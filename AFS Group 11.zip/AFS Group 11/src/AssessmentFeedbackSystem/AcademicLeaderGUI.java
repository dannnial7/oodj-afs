package AssessmentFeedbackSystem;

import afs.ui.LoginFrame;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumnModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.AffineTransform;
import java.util.List;
import java.util.ArrayList;
import java.io.File;
import javax.imageio.ImageIO;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.TableRowSorter;
import javax.swing.RowFilter;

public class AcademicLeaderGUI extends JFrame {
    private AcademicLeader currentUser;
    private List<Module> modules;

    // Components needed for refresh
    private DefaultTableModel moduleTableModel;
    private JTable moduleTable;
    private JComboBox<String> editModuleComboBox;
    private BarGraphPanel graphPanel;
    private DefaultTableModel reportModel;

    // Layout
    private CardLayout contentLayout;
    private JPanel contentPanel;

    private JPanel sidebarPanel;
    private final java.util.Map<String, JButton> navButtons = new java.util.HashMap<>();
    private String currentCard = "VIEW"; // Track active screen

    // Colors
    private final Color SIDEBAR_COLOR = new Color(44, 62, 80); // Dark Blue
    private final Color ACCENT_COLOR = new Color(52, 152, 219); // Peter River Blue
    private final Color TEXT_COLOR = Color.WHITE;
    private final Color HOVER_COLOR = new Color(52, 73, 94);

    public AcademicLeaderGUI(AcademicLeader user) {
        this.currentUser = user;
        // Load only modules relevant to this leader
        this.modules = DatabaseHandler.getModulesForLeader(user.getId());

        setTitle("AFS | Academic Leader (" + user.getName() + ")");
        setSize(1280, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // 1. SIDEBAR
        createSidebar();
        add(sidebarPanel, BorderLayout.WEST);

        // 2. CONTENT AREA (CardLayout)
        contentLayout = new CardLayout();
        contentPanel = new JPanel(contentLayout);
        contentPanel.setBackground(Color.WHITE);

        // Add Screens (Cards)
        contentPanel.add(createViewModulesPanel(), "VIEW");
        contentPanel.add(createAddModulePanel(), "ADD");
        contentPanel.add(createEditModulePanel(), "EDIT");
        contentPanel.add(createReportPanel(), "REPORTS");

        add(contentPanel, BorderLayout.CENTER);

        // Show default
        showCard("VIEW");
    }

    private void createSidebar() {
        sidebarPanel = new JPanel();
        sidebarPanel.setPreferredSize(new Dimension(250, getHeight()));
        sidebarPanel.setBackground(SIDEBAR_COLOR);
        sidebarPanel.setLayout(new BoxLayout(sidebarPanel, BoxLayout.Y_AXIS));

        // Profile Section
        JPanel profilePanel = new JPanel();
        profilePanel.setOpaque(false);
        profilePanel.setLayout(new BoxLayout(profilePanel, BoxLayout.Y_AXIS));
        profilePanel.setBorder(new EmptyBorder(30, 20, 30, 20));
        // Force left alignment for the panel contents
        profilePanel.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel titleLabel = new JLabel("Academic Leader");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 22));
        titleLabel.setForeground(ACCENT_COLOR);
        titleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel nameLabel = new JLabel(currentUser.getName());
        nameLabel.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        nameLabel.setForeground(TEXT_COLOR);
        nameLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Logo
        try {
            // Robust image loading strategy
            String logoPath = "C:\\Users\\mddan\\OneDrive\\Documents\\NetBeansProjects\\AFS Group 11\\assets\\logo.png";
            File imgFile = new File(logoPath);
            Image img = null;

            if (imgFile.exists()) {
                img = ImageIO.read(imgFile);
            } else {
                // Fallback: Try loading from classpath
                java.net.URL imgUrl = getClass().getResource("/assets/logo.png");
                if (imgUrl != null) {
                    img = ImageIO.read(imgUrl);
                }
            }

            // Fallback: Generate placeholder if image failed to load (e.g. unsupported
            // format like WebP)
            if (img == null) {
                System.err.println(
                        "Logo image could not be loaded (unsupported format or corrupted). Generating placeholder.");
                java.awt.image.BufferedImage placeholder = new java.awt.image.BufferedImage(180, 72,
                        java.awt.image.BufferedImage.TYPE_INT_ARGB);
                Graphics2D g2d = placeholder.createGraphics();
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2d.setColor(new Color(255, 255, 255)); // White background
                g2d.fillRect(0, 0, 180, 72);
                g2d.setColor(new Color(192, 57, 43)); // Red text (APU style)
                g2d.setFont(new Font("Serif", Font.BOLD, 40));
                FontMetrics fm = g2d.getFontMetrics();
                int textX = (180 - fm.stringWidth("APU")) / 2;
                int textY = (72 - fm.getHeight()) / 2 + fm.getAscent();
                g2d.drawString("APU", textX, textY);
                g2d.dispose();
                img = placeholder;
            }

            if (img != null) {
                Image newImg = img.getScaledInstance(180, 72, java.awt.Image.SCALE_SMOOTH);
                JLabel logoLabel = new JLabel(new ImageIcon(newImg));
                logoLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
                profilePanel.add(logoLabel);
                profilePanel.add(Box.createRigidArea(new Dimension(0, 20)));
            }
        } catch (Exception e) {
            System.err.println("Error loading logo: " + e.getMessage());
            e.printStackTrace();
        }

        profilePanel.add(titleLabel);
        profilePanel.add(Box.createRigidArea(new Dimension(0, 5)));
        profilePanel.add(nameLabel);

        sidebarPanel.add(profilePanel);
        sidebarPanel.add(Box.createRigidArea(new Dimension(0, 20)));

        // Navigation Buttons
        addSidebarButton("Dashboard", "VIEW");
        addSidebarButton("Add Module", "ADD");
        addSidebarButton("Reassign Lecturers", "EDIT");
        addSidebarButton("Analytics", "REPORTS");

        sidebarPanel.add(Box.createVerticalGlue());

        // Logout Button
        JButton btnLogout = createStyledButton("Logout");
        btnLogout.setBackground(new Color(192, 57, 43)); // Red
        btnLogout.addActionListener(e -> {
            this.dispose();
            new LoginFrame().setVisible(true);
        });

        JPanel logoutContainer = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        logoutContainer.setOpaque(false);
        logoutContainer.setAlignmentX(Component.LEFT_ALIGNMENT);
        logoutContainer.add(btnLogout);
        sidebarPanel.add(logoutContainer);
    }

    private void addSidebarButton(String text, String cardName) {
        JButton btn = createNavButton(text, cardName);
        btn.addActionListener(e -> showCard(cardName));
        navButtons.put(cardName, btn);

        JPanel container = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        container.setOpaque(false);
        container.setAlignmentX(Component.LEFT_ALIGNMENT);
        container.add(btn);
        sidebarPanel.add(container);
    }

    private JButton createNavButton(String text, String cardName) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btn.setForeground(TEXT_COLOR);
        btn.setBackground(SIDEBAR_COLOR);
        btn.setBorder(new EmptyBorder(10, 20, 10, 20));
        btn.setFocusPainted(false);
        btn.setContentAreaFilled(false);
        btn.setOpaque(true);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));

        btn.setPreferredSize(new Dimension(200, 45));
        btn.setHorizontalAlignment(SwingConstants.LEFT);

        btn.addMouseListener(new NavButtonMouseListener(btn, cardName));
        return btn;
    }

    private class NavButtonMouseListener extends MouseAdapter {
        private final JButton btn;
        private final String cardName;

        public NavButtonMouseListener(JButton btn, String cardName) {
            this.btn = btn;
            this.cardName = cardName;
        }

        @Override
        public void mouseEntered(MouseEvent e) {
            btn.setBackground(HOVER_COLOR);
        }

        @Override
        public void mouseExited(MouseEvent e) {
            if (currentCard.equals(cardName)) {
                btn.setBackground(ACCENT_COLOR);
            } else {
                btn.setBackground(SIDEBAR_COLOR);
            }
        }
    }

    private JButton createStyledButton(String text) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btn.setForeground(TEXT_COLOR);
        btn.setBackground(SIDEBAR_COLOR);
        btn.setBorder(new EmptyBorder(10, 20, 10, 20));
        btn.setFocusPainted(false);
        btn.setContentAreaFilled(false);
        btn.setOpaque(true);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));

        btn.setPreferredSize(new Dimension(200, 45));
        btn.setHorizontalAlignment(SwingConstants.LEFT);

        btn.addMouseListener(new SimpleButtonHoverListener(btn));
        return btn;
    }

    private class SimpleButtonHoverListener extends MouseAdapter {
        private final JButton btn;

        public SimpleButtonHoverListener(JButton btn) {
            this.btn = btn;
        }

        @Override
        public void mouseEntered(MouseEvent e) {
            btn.setBackground(HOVER_COLOR);
        }

        @Override
        public void mouseExited(MouseEvent e) {
            btn.setBackground(SIDEBAR_COLOR);
        }
    }

    private void showCard(String name) {
        currentCard = name;
        contentLayout.show(contentPanel, name);
        updateSidebarStyles();
    }

    private void updateSidebarStyles() {
        for (java.util.Map.Entry<String, JButton> entry : navButtons.entrySet()) {
            if (entry.getKey().equals(currentCard)) {
                entry.getValue().setBackground(ACCENT_COLOR);
                entry.getValue().setFont(new Font("Segoe UI", Font.BOLD, 15));
            } else {
                entry.getValue().setBackground(SIDEBAR_COLOR);
                entry.getValue().setFont(new Font("Segoe UI", Font.BOLD, 14));
            }
        }
    }

    // =================================================================================
    // CARD 1: VIEW MODULES
    // =================================================================================
    private JPanel createViewModulesPanel() {
        var panel = new JPanel(new BorderLayout());
        panel.setBackground(Color.WHITE);
        panel.setBorder(new EmptyBorder(20, 20, 20, 20));

        var headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(Color.WHITE);

        var title = new JLabel("Module Dashboard");
        title.setFont(new Font("Segoe UI", Font.BOLD, 28));
        title.setForeground(SIDEBAR_COLOR);
        headerPanel.add(title, BorderLayout.WEST);

        // Search Bar
        var searchPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        searchPanel.setBackground(Color.WHITE);
        var searchLabel = new JLabel("Search:");
        searchLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        var searchField = new JTextField(20);
        searchField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        searchPanel.add(searchLabel);
        searchPanel.add(searchField);
        headerPanel.add(searchPanel, BorderLayout.EAST);

        panel.add(headerPanel, BorderLayout.NORTH);

        var columns = new String[] { "No.", "Module ID", "Module Name", "Lecturer ID", "Lecturer Name", "Contact No.",
                "Email Address" };
        moduleTableModel = new DefaultTableModel(columns, 0);
        moduleTable = new JTable(moduleTableModel);

        // Add Sorter
        var sorter = new TableRowSorter<>(moduleTableModel);
        moduleTable.setRowSorter(sorter);

        // Search Logic
        // Search Logic
        searchField.getDocument().addDocumentListener((SimpleDocumentListener) e -> {
            var text = searchField.getText();
            if (text.trim().isEmpty()) {
                sorter.setRowFilter(null);
            } else {
                try {
                    sorter.setRowFilter(RowFilter.regexFilter("(?i)" + text));
                } catch (java.util.regex.PatternSyntaxException pse) {
                    System.err.println("Bad regex pattern");
                }
            }
        });
        moduleTable.setRowHeight(30);
        moduleTable.setFont(new Font("Segoe UI", Font.PLAIN, 14));

        // Header Styling
        var header = moduleTable.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 14));
        header.setBackground(new Color(236, 240, 241));
        header.setForeground(SIDEBAR_COLOR);

        // Formatting
        var colModel = moduleTable.getColumnModel();
        var centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);

        for (int i = 0; i < columns.length; i++) {
            colModel.getColumn(i).setCellRenderer(centerRenderer);
        }

        colModel.getColumn(0).setPreferredWidth(40); // "No." column
        colModel.getColumn(1).setPreferredWidth(70); // "Module ID" column
        colModel.getColumn(2).setPreferredWidth(200); // "Module Name" column

        refreshModuleTable();

        var scrollPane = new JScrollPane(moduleTable);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        panel.add(scrollPane, BorderLayout.CENTER);

        return panel;
    }

    // =================================================================================
    // CARD 2: ADD MODULE
    // =================================================================================
    private JPanel createAddModulePanel() {
        var panel = new JPanel(new GridBagLayout());
        panel.setBackground(Color.WHITE);

        var formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(new Color(245, 245, 245));
        formPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(230, 230, 230), 1),
                new EmptyBorder(40, 40, 40, 40)));

        var gbc = new GridBagConstraints();
        gbc.insets = new Insets(15, 15, 15, 15);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        var title = new JLabel("Create New Module");
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setForeground(SIDEBAR_COLOR);

        var idField = new JTextField(20);
        var nameField = new JTextField(20);
        idField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        nameField.setFont(new Font("Segoe UI", Font.PLAIN, 14));

        var lecComboBox = new JComboBox<String>();
        var assignedLecs = DatabaseHandler.getLecturersForLeader(currentUser.getId());
        for (var lec : assignedLecs) {
            lecComboBox.addItem(lec);
        }
        lecComboBox.setBackground(Color.WHITE);

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        formPanel.add(title, gbc);

        gbc.gridwidth = 1;
        gbc.gridx = 0;
        gbc.gridy = 1;
        formPanel.add(new JLabel("Module ID:"), gbc);
        gbc.gridx = 1;
        gbc.gridy = 1;
        formPanel.add(idField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        formPanel.add(new JLabel("Module Name:"), gbc);
        gbc.gridx = 1;
        gbc.gridy = 2;
        formPanel.add(nameField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        formPanel.add(new JLabel("Assign Lecturer:"), gbc);
        gbc.gridx = 1;
        gbc.gridy = 3;
        formPanel.add(lecComboBox, gbc);

        var addBtn = new JButton("Create Module");
        addBtn.setBackground(ACCENT_COLOR);
        addBtn.setForeground(Color.WHITE);
        addBtn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        addBtn.setFocusPainted(false);

        gbc.gridx = 1;
        gbc.gridy = 4;
        gbc.anchor = GridBagConstraints.EAST;
        formPanel.add(addBtn, gbc);

        addBtn.addActionListener(e -> {
            if (idField.getText().trim().isEmpty() || nameField.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Module ID and Name required.");
                return;
            }

            var selectedLec = (String) lecComboBox.getSelectedItem();
            if (selectedLec == null)
                selectedLec = "";

            var newMod = new Module(idField.getText().trim(),
                    nameField.getText().trim(),
                    selectedLec,
                    0, 0, 0.0);

            modules.add(newMod);
            DatabaseHandler.appendModule(newMod);
            refreshAllData();

            idField.setText("");
            nameField.setText("");
            JOptionPane.showMessageDialog(this, "Module Added Successfully!");
            showCard("VIEW"); // Auto-navigate back
        });

        panel.add(formPanel);
        return panel;
    }

    // =================================================================================
    // CARD 3: EDIT MODULE
    // =================================================================================
    private JPanel createEditModulePanel() {
        var panel = new JPanel(new GridBagLayout());
        panel.setBackground(Color.WHITE);

        var formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(new Color(245, 245, 245));
        formPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(230, 230, 230), 1),
                new EmptyBorder(40, 40, 40, 40)));

        var gbc = new GridBagConstraints();
        gbc.insets = new Insets(15, 15, 15, 15);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        var title = new JLabel("Edit / Assign Module");
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setForeground(SIDEBAR_COLOR);

        // Module Dropdown
        editModuleComboBox = new JComboBox<>();
        for (var m : modules) {
            editModuleComboBox.addItem(m.getModuleID() + " - " + m.getModuleName());
        }

        // New: Module Name Field
        var nameField = new JTextField(20);
        nameField.setFont(new Font("Segoe UI", Font.PLAIN, 14));

        // Lecturer Dropdown
        var lecComboBox = new JComboBox<String>();
        var assignedLecs = DatabaseHandler.getLecturersForLeader(currentUser.getId());
        for (var lec : assignedLecs) {
            lecComboBox.addItem(lec);
        }

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        formPanel.add(title, gbc);

        gbc.gridwidth = 1;
        gbc.gridx = 0;
        gbc.gridy = 1;
        formPanel.add(new JLabel("Select Module:"), gbc);
        gbc.gridx = 1;
        gbc.gridy = 1;
        formPanel.add(editModuleComboBox, gbc);

        // Added Name Field Row
        gbc.gridx = 0;
        gbc.gridy = 2;
        formPanel.add(new JLabel("Module Name:"), gbc);
        gbc.gridx = 1;
        gbc.gridy = 2;
        formPanel.add(nameField, gbc);

        // Moved Lecturer to Row 3
        gbc.gridx = 0;
        gbc.gridy = 3;
        formPanel.add(new JLabel("Re-Assign Lecturer:"), gbc);
        gbc.gridx = 1;
        gbc.gridy = 3;
        formPanel.add(lecComboBox, gbc);

        var btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        btnPanel.setOpaque(false);

        var assignBtn = new JButton("Update");
        assignBtn.setBackground(ACCENT_COLOR);
        assignBtn.setForeground(Color.WHITE);

        var deleteBtn = new JButton("Delete");
        deleteBtn.setBackground(new Color(231, 76, 60)); // Red
        deleteBtn.setForeground(Color.WHITE);

        btnPanel.add(assignBtn);
        btnPanel.add(deleteBtn);

        // Moved Buttons to Row 4
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        formPanel.add(btnPanel, gbc);

        // Listener to populate fields on selection
        editModuleComboBox.addActionListener(e -> {
            int idx = editModuleComboBox.getSelectedIndex();
            if (idx >= 0 && idx < modules.size()) {
                var m = modules.get(idx);
                nameField.setText(m.getModuleName());
                // Also update items in case of rename? No, just fields.
                // Pre-select current lecturer
                lecComboBox.setSelectedItem(m.getLecturerID());
            } else {
                nameField.setText("");
            }
        });

        // Trigger once to populate initial selection
        if (editModuleComboBox.getItemCount() > 0) {
            editModuleComboBox.setSelectedIndex(0);
        }

        assignBtn.addActionListener(e -> {
            int selectedIndex = editModuleComboBox.getSelectedIndex();
            if (selectedIndex >= 0) {
                var newName = nameField.getText().trim();
                if (newName.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Module Name cannot be empty.");
                    return;
                }

                var selectedLec = (String) lecComboBox.getSelectedItem();
                if (selectedLec != null) {
                    var m = modules.get(selectedIndex);
                    m.setLecturerID(selectedLec);
                    m.setModuleName(newName);

                    DatabaseHandler.updateModule(m);
                    refreshAllData();
                    JOptionPane.showMessageDialog(this, "Module Updated!");
                    showCard("VIEW");
                }
            }
        });

        deleteBtn.addActionListener(e -> {
            int selectedIndex = editModuleComboBox.getSelectedIndex();
            if (selectedIndex >= 0) {
                int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this module?",
                        "Confirm Delete", JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    // SAFE FIX: Use deleteModule to persist without data loss
                    DatabaseHandler.deleteModule(modules.get(selectedIndex).getModuleID());
                    modules.remove(selectedIndex);
                    refreshAllData();
                    JOptionPane.showMessageDialog(this, "Module Deleted!");
                    showCard("VIEW");
                }
            }
        });

        panel.add(formPanel);
        return panel;
    }

    private void refreshAllData() {
        refreshModuleTable();
        // Refresh Edit Tab Module Dropdown
        if (editModuleComboBox != null) {
            editModuleComboBox.removeAllItems();
            for (Module m : modules) {
                editModuleComboBox.addItem(m.getModuleID() + " - " + m.getModuleName());
            }
        }
        // Refresh Report Data
        if (reportModel != null) {
            // Accessing loadData runnable would be tricky here without structure change,
            // but we can trigger the refresh logic if we method-ize it properly.
            // For now, simple enough to just re-trigger graph repaint on tab switch or call
            // a method.
        }
    }

    // =================================================================================
    // CARD 4: REPORTS
    // =================================================================================
    private JPanel createReportPanel() {
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(Color.WHITE);

        // Header Panel with Refresh Button (West) and Search Bar (East)
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBackground(Color.WHITE);
        topPanel.setBorder(new EmptyBorder(10, 20, 10, 20));

        // West: Refresh Button
        JButton refreshBtn = new JButton("Refresh Analytics");
        refreshBtn.setBackground(ACCENT_COLOR);
        refreshBtn.setForeground(Color.WHITE);

        JPanel leftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        leftPanel.setBackground(Color.WHITE);
        leftPanel.add(refreshBtn);

        // East: Search Bar
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        searchPanel.setBackground(Color.WHITE);
        JLabel searchLabel = new JLabel("Search:");
        searchLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        JTextField searchField = new JTextField(20);
        searchField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        searchPanel.add(searchLabel);
        searchPanel.add(searchField);

        topPanel.add(leftPanel, BorderLayout.WEST);
        topPanel.add(searchPanel, BorderLayout.EAST);

        mainPanel.add(topPanel, BorderLayout.NORTH);

        JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
        splitPane.setDividerLocation(400); // More space for graph
        splitPane.setBorder(null);

        graphPanel = new BarGraphPanel();
        splitPane.setTopComponent(graphPanel);

        String[] columns = { "Module Code", "Module Name", "Lecturer ID", "Lecturer", "Total Students", "Classes",
                "Fail Rate" };
        reportModel = new DefaultTableModel(columns, 0);
        JTable reportTable = new JTable(reportModel);
        reportTable.setRowHeight(25);
        reportTable.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        reportTable.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));

        // Add Sorter for Search Functionality
        TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(reportModel);
        reportTable.setRowSorter(sorter);

        // Search Logic
        searchField.getDocument().addDocumentListener((SimpleDocumentListener) e -> {
            var text = searchField.getText();
            if (text.trim().isEmpty()) {
                sorter.setRowFilter(null);
            } else {
                try {
                    sorter.setRowFilter(RowFilter.regexFilter("(?i)" + text));
                } catch (java.util.regex.PatternSyntaxException pse) {
                    System.err.println("Bad regex pattern");
                }
            }
        });

        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        for (int i = 0; i < columns.length; i++) {
            reportTable.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
        }

        splitPane.setBottomComponent(new JScrollPane(reportTable));
        mainPanel.add(splitPane, BorderLayout.CENTER);

        Runnable loadData = () -> {
            reportModel.setRowCount(0);
            modules = DatabaseHandler.getModulesForLeader(currentUser.getId());

            List<String> labels = new ArrayList<>();
            List<Double> totalValues = new ArrayList<>();
            List<Double> failValues = new ArrayList<>();

            for (Module m : modules) {
                String lecName = DatabaseHandler.getUserName(m.getLecturerID());
                int realStudentCount = DatabaseHandler.getStudentCountForModule(m.getModuleID());
                int realClassCount = DatabaseHandler.getClassCountForModule(m.getModuleID());
                double calculatedFailRate = DatabaseHandler.calculateFailRate(m.getModuleID());

                reportModel.addRow(new Object[] {
                        m.getModuleID(), m.getModuleName(), m.getLecturerID(), lecName,
                        realStudentCount, realClassCount, String.format("%.2f", calculatedFailRate) + "%"
                });

                labels.add(m.getModuleID());
                totalValues.add((double) realStudentCount);
                failValues.add((calculatedFailRate / 100.0) * realStudentCount);
            }

            graphPanel.setData(labels, totalValues, failValues);
        };

        loadData.run();
        refreshBtn.addActionListener(e -> loadData.run());

        return mainPanel;
    }

    private void refreshModuleTable() {
        moduleTableModel.setRowCount(0);
        int count = 1;
        for (Module m : modules) {
            User lec = DatabaseHandler.getUser(m.getLecturerID());
            String name = (lec != null) ? lec.getName() : "Unknown";
            String contact = (lec != null) ? lec.getContactNum() : "-";
            String email = (lec != null) ? lec.getEmail() : "-";

            moduleTableModel.addRow(new Object[] {
                    count++,
                    m.getModuleID(), m.getModuleName(), m.getLecturerID(), name, contact, email
            });
        }
    }

    // =================================================================================
    // INNER CLASS: CLUSTERED BAR GRAPH
    // =================================================================================
    class BarGraphPanel extends JPanel {
        private List<String> labels = new ArrayList<>();
        private List<Double> totalValues = new ArrayList<>();
        private List<Double> failValues = new ArrayList<>();

        public BarGraphPanel() {
            setBackground(Color.WHITE);
        }

        public void setData(List<String> labels, List<Double> totalValues, List<Double> failValues) {
            this.labels = labels;
            this.totalValues = totalValues;
            this.failValues = failValues;
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            var g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            var w = getWidth();
            var h = getHeight();
            g2.setColor(Color.WHITE);
            g2.fillRect(0, 0, w, h);
            g2.setColor(SIDEBAR_COLOR);

            // 1. Chart Title
            g2.setFont(new Font("Segoe UI", Font.BOLD, 18));
            g2.drawString("Performance Overview", 40, 30);

            // 2. Legend
            var lx = w - 200;
            g2.setFont(new Font("Segoe UI", Font.PLAIN, 12));

            g2.setColor(ACCENT_COLOR);
            g2.fillRect(lx, 20, 15, 15);
            g2.setColor(Color.BLACK);
            g2.drawString("Total Students", lx + 25, 32);

            g2.setColor(new Color(231, 76, 60));
            g2.fillRect(lx, 40, 15, 15);
            g2.setColor(Color.BLACK);
            g2.drawString("At Risk / Failed", lx + 25, 52);

            if (totalValues.isEmpty())
                return;

            var maxVal = totalValues.stream().mapToDouble(v -> v).max().orElse(10);
            if (maxVal == 0)
                maxVal = 10;

            var barWidth = 25;
            var groupGap = 40;
            var startX = 80;
            var groundY = h - 50;

            // Y-Axis Line
            g2.setColor(Color.LIGHT_GRAY);
            g2.drawLine(50, 60, 50, groundY);
            // X-Axis Line
            g2.drawLine(50, groundY, w - 20, groundY);

            g2.setFont(new Font("Segoe UI", Font.PLAIN, 11));

            for (int i = 0; i < totalValues.size(); i++) {
                var groupX = startX + (i * (barWidth * 2 + groupGap));

                // Total Bar (Blue)
                var h1 = (int) ((totalValues.get(i) / maxVal) * (h - 150));
                var y1 = groundY - h1;
                g2.setColor(ACCENT_COLOR);
                g2.fillRoundRect(groupX, y1, barWidth, h1, 5, 5);
                g2.setColor(Color.BLACK);
                g2.drawString(String.valueOf(totalValues.get(i).intValue()), groupX + 5, y1 - 5);

                // Fail Bar (Red)
                var h2 = (int) ((failValues.get(i) / maxVal) * (h - 150));
                var y2 = groundY - h2;
                g2.setColor(new Color(231, 76, 60));
                g2.fillRoundRect(groupX + barWidth + 2, y2, barWidth, h2, 5, 5);

                if (h2 > 0)
                    g2.drawString(String.valueOf(failValues.get(i).intValue()), groupX + barWidth + 7, y2 - 5);

                // Label
                g2.setColor(SIDEBAR_COLOR);
                g2.drawString(labels.get(i), groupX + 5, groundY + 20);
            }
        }
    }

    @FunctionalInterface
    private interface SimpleDocumentListener extends DocumentListener {
        void update(DocumentEvent e);

        @Override
        default void insertUpdate(DocumentEvent e) {
            update(e);
        }

        @Override
        default void removeUpdate(DocumentEvent e) {
            update(e);
        }

        @Override
        default void changedUpdate(DocumentEvent e) {
            update(e);
        }
    }

}
