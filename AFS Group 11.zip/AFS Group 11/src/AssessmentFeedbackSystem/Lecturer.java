package AssessmentFeedbackSystem;

public class Lecturer extends User {
    public Lecturer(String id, String password, String name, String email, String contactNum) {
        super(id, password, name, email, contactNum);
    }

    @Override
    public String getRole() {
        return "Lecturer";
    }
}
