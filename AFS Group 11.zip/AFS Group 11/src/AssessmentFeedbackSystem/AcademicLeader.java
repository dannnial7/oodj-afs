package AssessmentFeedbackSystem;

public class AcademicLeader extends User {

    public AcademicLeader(String id, String password, String name, String email, String contactNum) {
        super(id, password, name, email, contactNum);
    }

    @Override
    public String getRole() { return "Academic Leader"; }

    public void updateProfile(String newName, String newEmail, String newContact) {
        this.name = newName;
        this.email = newEmail;
        this.contactNum = newContact;
    }
}