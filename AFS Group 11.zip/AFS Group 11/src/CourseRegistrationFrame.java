/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Muhammad Aamer Ali
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class CourseRegistrationFrame extends JFrame {
    private Student student;
    private DefaultListModel<String> courseListModel;
    private JList<String> courseList;
    private ArrayList<Course> allCourses;
    private ArrayList<Course> enrolledCourses;
    private StudentDashboard dashboard;
    
    public CourseRegistrationFrame(Student student) {
        this(student, null);
    }
    
    public CourseRegistrationFrame(Student student, StudentDashboard dashboard) {
        this.student = student;
        this.dashboard = dashboard;
        
        setTitle("Module Registration");
        setSize(650, 550);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        
        // Get enrolled courses
        refreshEnrolledCourses();
        
        // Get all available courses
        allCourses = FileManager.getInstance().getAllCourses();
        
        // Top Panel with info
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        topPanel.setBackground(new Color(0, 51, 102));
        
        JLabel titleLabel = new JLabel("📝 Module Registration");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        titleLabel.setForeground(Color.WHITE);
        
        JLabel infoLabel = new JLabel("Available Modules (Already enrolled: " + enrolledCourses.size() + ")");
        infoLabel.setFont(new Font("Arial", Font.PLAIN, 12));
        infoLabel.setForeground(new Color(200, 220, 255));
        
        JPanel titlePanel = new JPanel(new BorderLayout());
        titlePanel.setBackground(new Color(0, 51, 102));
        titlePanel.add(titleLabel, BorderLayout.NORTH);
        titlePanel.add(infoLabel, BorderLayout.SOUTH);
        
        topPanel.add(titlePanel, BorderLayout.WEST);
        
        // Course List Panel
        JPanel listPanel = new JPanel(new BorderLayout());
        listPanel.setBorder(BorderFactory.createTitledBorder("Select Modules"));
        
        courseListModel = new DefaultListModel<>();
        refreshCourseList();
        
        courseList = new JList<>(courseListModel);
        courseList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        courseList.setFont(new Font("Arial", Font.PLAIN, 12));
        
        JScrollPane scrollPane = new JScrollPane(courseList);
        listPanel.add(scrollPane, BorderLayout.CENTER);
        
        // Status Panel
        JPanel statusPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        statusPanel.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        
        JLabel statusLabel = new JLabel("🟢 ENROLLED | ⚪ AVAILABLE");
        statusLabel.setFont(new Font("Arial", Font.PLAIN, 10));
        statusLabel.setForeground(Color.DARK_GRAY);
        statusPanel.add(statusLabel);
        
        listPanel.add(statusPanel, BorderLayout.SOUTH);
        
        // Button Panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        buttonPanel.setBackground(Color.WHITE);
        
        JButton registerButton = new JButton("✅ Register Selected");
        registerButton.setBackground(new Color(33, 150, 243));
        registerButton.setForeground(Color.WHITE);
        registerButton.setFont(new Font("Arial", Font.BOLD, 12));
        registerButton.setBorder(BorderFactory.createEmptyBorder(8, 15, 8, 15));
        
        JButton unregisterButton = new JButton("🗑️ Unregister Selected");
        unregisterButton.setBackground(new Color(220, 53, 69));
        unregisterButton.setForeground(Color.WHITE);
        unregisterButton.setFont(new Font("Arial", Font.BOLD, 12));
        unregisterButton.setBorder(BorderFactory.createEmptyBorder(8, 15, 8, 15));
        
        JButton viewDetailsButton = new JButton("🔍 View Details");
        viewDetailsButton.setBackground(Color.ORANGE);
        viewDetailsButton.setForeground(Color.WHITE);
        
        JButton refreshButton = new JButton("🔄 Refresh");
        refreshButton.setBackground(Color.LIGHT_GRAY);
        
        JButton closeButton = new JButton("✖️ Close");
        closeButton.setBackground(Color.DARK_GRAY);
        closeButton.setForeground(Color.WHITE);
        
        buttonPanel.add(registerButton);
        buttonPanel.add(unregisterButton);
        buttonPanel.add(viewDetailsButton);
        buttonPanel.add(refreshButton);
        buttonPanel.add(closeButton);
        
        // Add panels to frame
        add(topPanel, BorderLayout.NORTH);
        add(listPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
        
        // Action Listeners
        registerButton.addActionListener(e -> registerCourses());
        unregisterButton.addActionListener(e -> unregisterCourses());
        viewDetailsButton.addActionListener(e -> showCourseDetails());
        refreshButton.addActionListener(e -> refreshAll());
        closeButton.addActionListener(e -> {
            if (dashboard != null) {
                dashboard.refreshDashboard();
            }
            this.dispose();
        });
    }
    
    private void refreshEnrolledCourses() {
        enrolledCourses = FileManager.getInstance().getEnrolledCourses(student.getUserID());
    }
    
    private void refreshCourseList() {
        courseListModel.clear();
        
        // Get enrolled course codes
        ArrayList<String> enrolledCourseCodes = new ArrayList<>();
        for (Course c : enrolledCourses) {
            enrolledCourseCodes.add(c.getCourseCode());
        }
        
        // Add all modules with enrollment status
        for (Course course : allCourses) {
            boolean isEnrolled = enrolledCourseCodes.contains(course.getCourseCode());
            String status = isEnrolled ? "🟢 ENROLLED" : "⚪ AVAILABLE";
            courseListModel.addElement(status + " " + course.getCourseCode() + " - " + course.getCourseName());
        }
    }
    
    private void refreshAll() {
        refreshEnrolledCourses();
        refreshCourseList();
        updateTitle();
        
        JOptionPane.showMessageDialog(this, 
            "Module list refreshed! Currently enrolled: " + enrolledCourses.size() + " modules",
            "Refresh Complete", JOptionPane.INFORMATION_MESSAGE);
    }
    
    private void updateTitle() {
        // Update the enrolled count in the title
        Component[] components = getContentPane().getComponents();
        for (Component comp : components) {
            if (comp instanceof JPanel) {
                JPanel panel = (JPanel) comp;
                // Check if this is the top panel
                if (panel.getBackground().equals(new Color(0, 51, 102))) {
                    Component[] subComps = panel.getComponents();
                    for (Component subComp : subComps) {
                        if (subComp instanceof JPanel) {
                            JPanel titlePanel = (JPanel) subComp;
                            Component[] titleComps = titlePanel.getComponents();
                            for (Component titleComp : titleComps) {
                                if (titleComp instanceof JLabel && titleComp.getFont().getSize() == 12) {
                                    JLabel infoLabel = (JLabel) titleComp;
                                    infoLabel.setText("Available Modules (Already enrolled: " + enrolledCourses.size() + ")");
                                    return;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
    private void registerCourses() {
        int[] selectedIndices = courseList.getSelectedIndices();
        
        if (selectedIndices.length == 0) {
            JOptionPane.showMessageDialog(this, "Please select at least one module", 
                                         "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        int successCount = 0;
        int alreadyEnrolledCount = 0;
        StringBuilder registeredCourses = new StringBuilder();
        StringBuilder alreadyEnrolledCourses = new StringBuilder();
        
        for (int index : selectedIndices) {
            Course course = allCourses.get(index);
            
            // Check if already enrolled
            boolean alreadyEnrolled = false;
            for (Course c : enrolledCourses) {
                if (c.getCourseCode().equals(course.getCourseCode())) {
                    alreadyEnrolled = true;
                    alreadyEnrolledCount++;
                    alreadyEnrolledCourses.append("• ").append(course.getCourseCode())
                                        .append(" - ").append(course.getCourseName()).append("\n");
                    break;
                }
            }
            
            if (!alreadyEnrolled) {
                if (student.registerForCourse(course)) {
                    successCount++;
                    registeredCourses.append("• ").append(course.getCourseCode())
                                   .append(" - ").append(course.getCourseName()).append("\n");
                }
            }
        }
        
        // Show result
        StringBuilder message = new StringBuilder();
        
        if (successCount > 0) {
            message.append("✅ Successfully registered for ").append(successCount).append(" module(s):\n\n");
            message.append(registeredCourses.toString()).append("\n");
            
            // Refresh local data
            refreshEnrolledCourses();
            refreshCourseList();
            updateTitle();
            
            // Refresh the dashboard
            if (dashboard != null) {
                dashboard.refreshDashboard();
            }
        }
        
        if (alreadyEnrolledCount > 0) {
            message.append("⚠️ Already enrolled in ").append(alreadyEnrolledCount).append(" module(s):\n\n");
            message.append(alreadyEnrolledCourses.toString());
        }
        
        if (successCount == 0 && alreadyEnrolledCount == 0) {
            JOptionPane.showMessageDialog(this, 
                "No modules were registered.",
                "Info", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, message.toString(),
                "Registration Result", JOptionPane.INFORMATION_MESSAGE);
        }
    }
    
    private void unregisterCourses() {
        int[] selectedIndices = courseList.getSelectedIndices();
        
        if (selectedIndices.length == 0) {
            JOptionPane.showMessageDialog(this, "Please select at least one module to unregister", 
                                         "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Filter to only get enrolled modules from selection
        ArrayList<Course> coursesToUnregister = new ArrayList<>();
        ArrayList<Course> nonEnrolledCourses = new ArrayList<>();
        
        for (int index : selectedIndices) {
            Course course = allCourses.get(index);
            
            // Check if enrolled
            boolean isEnrolled = false;
            for (Course c : enrolledCourses) {
                if (c.getCourseCode().equals(course.getCourseCode())) {
                    isEnrolled = true;
                    coursesToUnregister.add(course);
                    break;
                }
            }
            
            if (!isEnrolled) {
                nonEnrolledCourses.add(course);
            }
        }
        
        if (coursesToUnregister.isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "No enrolled modules selected. Please select modules marked as 'ENROLLED'.",
                "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Confirm unregistration
        StringBuilder confirmation = new StringBuilder();
        confirmation.append("⚠️ Are you sure you want to unregister from these ").append(coursesToUnregister.size()).append(" module(s)?\n\n");
        
        for (Course course : coursesToUnregister) {
            confirmation.append("• ").append(course.getCourseCode())
                       .append(" - ").append(course.getCourseName()).append("\n");
        }
        
        confirmation.append("\n⚠️ WARNING: This will remove you from the module and may affect your progress!");
        
        int result = JOptionPane.showConfirmDialog(this, confirmation.toString(), 
                                                  "Confirm Unregistration", 
                                                  JOptionPane.YES_NO_OPTION, 
                                                  JOptionPane.WARNING_MESSAGE);
        
        if (result == JOptionPane.YES_OPTION) {
            int successCount = 0;
            StringBuilder unregisteredCourses = new StringBuilder();
            
            for (Course course : coursesToUnregister) {
                if (student.unregisterFromCourse(course.getCourseCode())) {
                    successCount++;
                    unregisteredCourses.append("• ").append(course.getCourseCode())
                                    .append(" - ").append(course.getCourseName()).append("\n");
                }
            }
            
            if (successCount > 0) {
                StringBuilder resultMessage = new StringBuilder();
                resultMessage.append("✅ Successfully unregistered from ").append(successCount).append(" module(s):\n\n");
                resultMessage.append(unregisteredCourses.toString()).append("\n");
                
                if (!nonEnrolledCourses.isEmpty()) {
                    resultMessage.append("⚠️ Note: ").append(nonEnrolledCourses.size())
                                .append(" selected modules were not enrolled.\n");
                }
                
                JOptionPane.showMessageDialog(this, resultMessage.toString(),
                    "Unregistration Successful", JOptionPane.INFORMATION_MESSAGE);
                
                // Refresh local data
                refreshEnrolledCourses();
                refreshCourseList();
                updateTitle();
                
                // Refresh the dashboard
                if (dashboard != null) {
                    dashboard.refreshDashboard();
                }
            }
        }
    }
    
    private void showCourseDetails() {
        int selectedIndex = courseList.getSelectedIndex();
        if (selectedIndex == -1) {
            JOptionPane.showMessageDialog(this, "Please select a module first", 
                                         "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        Course course = allCourses.get(selectedIndex);
        
        // Check enrollment status
        boolean isEnrolled = false;
        for (Course c : enrolledCourses) {
            if (c.getCourseCode().equals(course.getCourseCode())) {
                isEnrolled = true;
                break;
            }
        }
        
        String details = "<html><div style='width: 300px;'>" +
                        "<h3>📚 Module Details</h3>" +
                        "<b>Code:</b> " + course.getCourseCode() + "<br>" +
                        "<b>Name:</b> " + course.getCourseName() + "<br>" +
                        "<b>Lecturer ID:</b> " + course.getLecturerID() + "<br>" +
                        "<br>" +
                        "<b>Status:</b> " + (isEnrolled ? 
                            "<span style='color: green;'>ENROLLED ✓</span>" : 
                            "<span style='color: blue;'>AVAILABLE</span>") +
                        "</div></html>";
        
        JOptionPane.showMessageDialog(this, details, "Module Details", JOptionPane.INFORMATION_MESSAGE);
    }
}
