/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Muhammad Aamer Ali
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class NotificationFrame extends JFrame {
    private Student student;
    private DefaultListModel<String> notificationModel;
    private JList<String> notificationList;
    
    public NotificationFrame(Student student) {
        this.student = student;
        
        setTitle("Notifications");
        setSize(500, 400);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        
        // Title Panel
        JPanel titlePanel = new JPanel(new BorderLayout());
        titlePanel.setBackground(new Color(70, 130, 180));
        titlePanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        JLabel titleLabel = new JLabel("🔔 Your Notifications");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        titleLabel.setForeground(Color.WHITE);
        
        JButton clearAllButton = new JButton("Mark All as Read");
        clearAllButton.setBackground(Color.WHITE);
        clearAllButton.setFocusPainted(false);
        
        titlePanel.add(titleLabel, BorderLayout.WEST);
        titlePanel.add(clearAllButton, BorderLayout.EAST);
        
        // Notification List
        JPanel listPanel = new JPanel(new BorderLayout());
        listPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        notificationModel = new DefaultListModel<>();
        loadNotifications();
        
        notificationList = new JList<>(notificationModel);
        notificationList.setFont(new Font("Arial", Font.PLAIN, 12));
        notificationList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        // Custom cell renderer for styling
        notificationList.setCellRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, 
                                                         int index, boolean isSelected, 
                                                         boolean cellHasFocus) {
                JLabel label = (JLabel) super.getListCellRendererComponent(list, value, 
                                                                          index, isSelected, cellHasFocus);
                
                // Style based on whether it's read
                if (value.toString().startsWith("✓ ")) {
                    label.setForeground(Color.GRAY);
                    label.setFont(new Font("Arial", Font.PLAIN, 12));
                } else {
                    label.setForeground(Color.BLACK);
                    label.setFont(new Font("Arial", Font.BOLD, 12));
                }
                
                return label;
            }
        });
        
        JScrollPane scrollPane = new JScrollPane(notificationList);
        listPanel.add(scrollPane, BorderLayout.CENTER);
        
        // Button Panel
        JPanel buttonPanel = new JPanel();
        JButton markReadButton = new JButton("Mark as Read");
        markReadButton.setBackground(new Color(76, 175, 80));
        markReadButton.setForeground(Color.WHITE);
        
        JButton deleteButton = new JButton("Delete Selected");
        deleteButton.setBackground(new Color(244, 67, 54));
        deleteButton.setForeground(Color.WHITE);
        
        JButton closeButton = new JButton("Close");
        closeButton.setBackground(Color.LIGHT_GRAY);
        
        buttonPanel.add(markReadButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(closeButton);
        
        // Add panels to frame
        add(titlePanel, BorderLayout.NORTH);
        add(listPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
        
        // Action Listeners
        markReadButton.addActionListener(e -> markAsRead());
        clearAllButton.addActionListener(e -> markAllAsRead());
        deleteButton.addActionListener(e -> deleteNotification());
        closeButton.addActionListener(e -> {
            this.dispose();
            // Refresh parent dashboard if needed
        });
        
        // Double-click to mark as read
        notificationList.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    markAsRead();
                }
            }
        });
    }
    
    private void loadNotifications() {
        notificationModel.clear();
        
        // Get unread notifications
        ArrayList<String> unreadNotifications = student.getUnreadNotifications();
        for (String notification : unreadNotifications) {
            notificationModel.addElement("● " + notification);
        }
        
        // Get read notifications (for demo, we'll show some)
        // In a real system, you'd load these from file
        notificationModel.addElement("✓ Welcome to AFS System (Read)");
        notificationModel.addElement("✓ Semester 2025-1 started (Read)");
        
        if (notificationModel.isEmpty()) {
            notificationModel.addElement("No notifications");
        }
    }
    
    private void markAsRead() {
        int selectedIndex = notificationList.getSelectedIndex();
        if (selectedIndex >= 0) {
            String item = notificationModel.get(selectedIndex);
            
            // Only mark unread items
            if (item.startsWith("● ")) {
                // Update in file
                student.markNotificationAsRead(selectedIndex);
                
                // Update in list
                notificationModel.set(selectedIndex, "✓ " + item.substring(2) + " (Read)");
                
                JOptionPane.showMessageDialog(this, "Notification marked as read", 
                                             "Success", JOptionPane.INFORMATION_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select a notification", 
                                         "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void markAllAsRead() {
        int unreadCount = 0;
        for (int i = 0; i < notificationModel.size(); i++) {
            String item = notificationModel.get(i);
            if (item.startsWith("● ")) {
                // Mark each unread notification
                student.markNotificationAsRead(unreadCount);
                notificationModel.set(i, "✓ " + item.substring(2) + " (Read)");
                unreadCount++;
            }
        }
        
        if (unreadCount > 0) {
            JOptionPane.showMessageDialog(this, "Marked " + unreadCount + " notifications as read", 
                                         "Success", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "No unread notifications", 
                                         "Info", JOptionPane.INFORMATION_MESSAGE);
        }
    }
    
    private void deleteNotification() {
        int selectedIndex = notificationList.getSelectedIndex();
        if (selectedIndex >= 0) {
            int confirm = JOptionPane.showConfirmDialog(this, 
                "Delete this notification?", 
                "Confirm Delete", JOptionPane.YES_NO_OPTION);
            
            if (confirm == JOptionPane.YES_OPTION) {
                notificationModel.remove(selectedIndex);
                JOptionPane.showMessageDialog(this, "Notification deleted", 
                                             "Success", JOptionPane.INFORMATION_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select a notification", 
                                         "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}