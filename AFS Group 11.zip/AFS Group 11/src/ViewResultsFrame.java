/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Muhammad Aamer Ali
 */
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;

public class ViewResultsFrame extends JFrame {
    private Student student;
    private JTable resultsTable;
    private DefaultTableModel tableModel;
    private ArrayList<Result> currentResults; // Store the loaded results
    
    public ViewResultsFrame(Student student) {
        this.student = student;
        this.currentResults = new ArrayList<>();
        
        setTitle("View Assessment Results");
        setSize(800, 500);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        
        // Title Panel
        JPanel titlePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        titlePanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        JLabel titleLabel = new JLabel("Your Assessment Results - " + student.getName());
        titleLabel.setFont(new Font("Arial", Font.BOLD, 14));
        titlePanel.add(titleLabel);
        
        // Table Panel
        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        // Create table model with columns
        String[] columns = {"Module Code", "Assessment Type", "Marks", "Grade", "Feedback", "Lecturer"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Make all cells non-editable
            }
        };
        
        resultsTable = new JTable(tableModel);
        resultsTable.setRowHeight(25);
        resultsTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 12));
        resultsTable.setFont(new Font("Arial", Font.PLAIN, 12));
        
        // Make the feedback column wider
        resultsTable.getColumnModel().getColumn(4).setPreferredWidth(200);
        
        JScrollPane scrollPane = new JScrollPane(resultsTable);
        tablePanel.add(scrollPane, BorderLayout.CENTER);
        
        // Statistics Panel
        JPanel statsPanel = new JPanel(new GridLayout(1, 4, 10, 10));
        statsPanel.setBorder(BorderFactory.createTitledBorder("Statistics"));
        statsPanel.setBackground(new Color(240, 240, 240));
        statsPanel.setPreferredSize(new Dimension(100, 60));
        
        JLabel totalLabel = new JLabel("Total: 0", SwingConstants.CENTER);
        JLabel avgLabel = new JLabel("Average: 0.00", SwingConstants.CENTER);
        JLabel bestLabel = new JLabel("Best: 0", SwingConstants.CENTER);
        JLabel worstLabel = new JLabel("Worst: 0", SwingConstants.CENTER);
        
        totalLabel.setFont(new Font("Arial", Font.BOLD, 12));
        avgLabel.setFont(new Font("Arial", Font.BOLD, 12));
        bestLabel.setFont(new Font("Arial", Font.BOLD, 12));
        worstLabel.setFont(new Font("Arial", Font.BOLD, 12));
        
        statsPanel.add(totalLabel);
        statsPanel.add(avgLabel);
        statsPanel.add(bestLabel);
        statsPanel.add(worstLabel);
        
        // Button Panel
        JPanel buttonPanel = new JPanel();
        
        JButton refreshButton = new JButton("Refresh Results");
        refreshButton.setBackground(new Color(255, 152, 0));
        refreshButton.setForeground(Color.WHITE);
        refreshButton.setFont(new Font("Arial", Font.BOLD, 12));
        
        JButton exportButton = new JButton("Export to Text");
        exportButton.setBackground(new Color(156, 39, 176));
        exportButton.setForeground(Color.WHITE);
        exportButton.setFont(new Font("Arial", Font.BOLD, 12));
        
        JButton closeButton = new JButton("Close");
        closeButton.setBackground(Color.LIGHT_GRAY);
        closeButton.setFont(new Font("Arial", Font.BOLD, 12));
        
        buttonPanel.add(refreshButton);
        buttonPanel.add(exportButton);
        buttonPanel.add(closeButton);
        
        // Add panels to frame
        add(titlePanel, BorderLayout.NORTH);
        add(tablePanel, BorderLayout.CENTER);
        add(statsPanel, BorderLayout.SOUTH);
        
        // Create a separate panel for buttons at the very bottom
        JPanel bottomButtonPanel = new JPanel();
        bottomButtonPanel.add(buttonPanel);
        add(bottomButtonPanel, BorderLayout.PAGE_END);
        
        // Action Listeners
        refreshButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                loadResults();
                updateStatistics(totalLabel, avgLabel, bestLabel, worstLabel);
            }
        });
        
        closeButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        
        exportButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                exportResults();
            }
        });
        
        // Double-click to view full feedback
        resultsTable.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    showFullFeedback();
                }
            }
        });
        
        // Load initial data
        loadResults();
        updateStatistics(totalLabel, avgLabel, bestLabel, worstLabel);
        
        // Make window visible
        setVisible(true);
    }
    
    private void loadResults() {
        // Clear existing rows
        tableModel.setRowCount(0);
        
        // Load results from results.txt file
        currentResults = loadResultsFromFile();
        
        if (currentResults.isEmpty()) {
            // Add a message if no results
            tableModel.addRow(new Object[]{
                "No results", "No assessments", "N/A", "N/A", 
                "No feedback available", "N/A"
            });
        } else {
            // Add each result to the table
            for (Result result : currentResults) {
                // Truncate long feedback for display
                String feedback = result.getFeedback();
                if (feedback != null && feedback.length() > 50) {
                    feedback = feedback.substring(0, 50) + "...";
                }
                
                tableModel.addRow(new Object[]{
                    result.getCourseCode(),      // Module Code (from Description column)
                    result.getAssessmentType(),   // Assessment Type (from AssessmentID column)
                    result.getMarks(),            // Marks
                    result.getGrade(),            // Grade (from file)
                    feedback,                    // Feedback (truncated)
                    result.getLecturerID()        // Lecturer
                });
            }
        }
    }
    
    private ArrayList<Result> loadResultsFromFile() {
        ArrayList<Result> results = new ArrayList<>();
        String studentId = student.getUserID(); // Get current student's ID
        
        File marksFile = new File("data_files/results.txt");
        
        // Check if file exists
        if (!marksFile.exists()) {
            System.out.println("results.txt not found. No results loaded.");
            JOptionPane.showMessageDialog(this,
                "results.txt file not found in: " + System.getProperty("user.dir") + 
                "\n\nPlease ensure the file exists in the correct location.",
                "File Not Found",
                JOptionPane.WARNING_MESSAGE);
            return results;
        }
        
        try (BufferedReader reader = new BufferedReader(new FileReader(marksFile))) {
            String line;
            boolean isFirstLine = true;
            int lineNumber = 0;
            
            while ((line = reader.readLine()) != null) {
                lineNumber++;
                line = line.trim();
                
                // Skip empty lines
                if (line.isEmpty()) {
                    continue;
                }
                
                // Skip header line if it exists
                if (isFirstLine) {
                    isFirstLine = false;
                    if (line.toLowerCase().contains("studentid") || 
                        line.toLowerCase().contains("student")) {
                        System.out.println("Skipping header line: " + line);
                        continue;
                    }
                }
                
                // Parse the line - split by comma
                String[] parts = line.split(",");
                
                // Check if it's a valid line with all required fields
                if (parts.length >= 7) {
                    String fileStudentId = parts[0].trim().replace("\"", "").replace("'", "");
                    
                    // Only add results for this student
                    if (fileStudentId.equals(studentId)) {
                        String assessmentId = parts[1].trim().replace("\"", "").replace("'", ""); // AssessmentID
                        String description = parts[2].trim().replace("\"", "").replace("'", ""); // Description (Module Code)
                        double marks;
                        try {
                            marks = Double.parseDouble(parts[3].trim().replace("\"", "").replace("'", ""));
                        } catch (NumberFormatException e) {
                            System.out.println("Error parsing marks on line " + lineNumber + ": " + parts[3]);
                            marks = 0.0;
                        }
                        String grade = parts[4].trim().replace("\"", "").replace("'", ""); // Grade from file
                        String feedback = parts[5].trim().replace("\"", "").replace("'", ""); // Feedback
                        String lecturerId = parts[6].trim().replace("\"", "").replace("'", ""); // LecturerID
                        
                        // Create Result object using the constructor with grade
                        Result result = new Result(
                            studentId,        // studentID (from current student)
                            description,      // courseCode (from Description column)
                            assessmentId,     // assessmentType (from AssessmentID column)
                            marks,            // marks
                            grade,            // grade (from file)
                            feedback,         // feedback
                            lecturerId        // lecturerID
                        );
                        
                        results.add(result);
                        System.out.println("✓ Loaded result for student " + studentId + 
                                         ": " + description + " - " + assessmentId + 
                                         ", Marks: " + marks + ", Grade: " + grade);
                    }
                } else {
                    System.out.println("Skipping line " + lineNumber + ": not enough fields (" + 
                                     parts.length + "/7) - " + line);
                }
            }
            
            System.out.println("Loaded " + results.size() + " results for student " + studentId);
            
            // Show message if no results were found
            if (results.isEmpty()) {
                JOptionPane.showMessageDialog(this,
                    "No results found for student ID: " + studentId + "\n\n" +
                    "Please check that:\n" +
                    "1. The StudentID in results.txt matches: " + studentId + "\n" +
                    "2. The file is properly formatted with commas\n" +
                    "3. There are no empty lines in the file",
                    "No Results",
                    JOptionPane.INFORMATION_MESSAGE);
            }
            
        } catch (FileNotFoundException e) {
            System.out.println("results.txt not found. No results loaded.");
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this,
                "Error reading results.txt file: " + e.getMessage(),
                "File Error",
                JOptionPane.ERROR_MESSAGE);
        }
        
        return results;
    }
    
    private void updateStatistics(JLabel totalLabel, JLabel avgLabel, 
                                 JLabel bestLabel, JLabel worstLabel) {
        if (currentResults.isEmpty()) {
            totalLabel.setText("Total: 0");
            avgLabel.setText("Average: 0.00");
            bestLabel.setText("Best: 0.00");
            worstLabel.setText("Worst: 0.00");
            return;
        }
        
        int total = currentResults.size();
        double sum = 0;
        double best = 0;
        double worst = 100; // Start with highest possible
        
        for (Result result : currentResults) {
            double marks = result.getMarks();
            sum += marks;
            
            if (marks > best) {
                best = marks;
            }
            
            if (marks < worst) {
                worst = marks;
            }
        }
        
        double average = sum / total;
        
        totalLabel.setText("Total: " + total);
        avgLabel.setText("Average: " + String.format("%.2f", average));
        bestLabel.setText("Best: " + String.format("%.1f", best));
        worstLabel.setText("Worst: " + String.format("%.1f", worst));
    }
    
    private void showFullFeedback() {
        int selectedRow = resultsTable.getSelectedRow();
        if (selectedRow >= 0) {
            // Check if "no results" message is displayed
            if (!currentResults.isEmpty() && selectedRow < currentResults.size()) {
                Result result = currentResults.get(selectedRow);
                
                JTextArea feedbackArea = new JTextArea();
                feedbackArea.setEditable(false);
                feedbackArea.setFont(new Font("Arial", Font.PLAIN, 12));
                feedbackArea.setLineWrap(true);
                feedbackArea.setWrapStyleWord(true);
                
                feedbackArea.setText(
                    "DETAILED ASSESSMENT FEEDBACK\n" +
                    "============================\n\n" +
                    "Module: " + result.getCourseCode() + "\n" +
                    "Assessment ID: " + result.getAssessmentType() + "\n" +
                    "Marks: " + result.getMarks() + "\n" +
                    "Grade: " + result.getGrade() + "\n" +
                    "Lecturer: " + result.getLecturerID() + "\n\n" +
                    "FEEDBACK:\n" +
                    result.getFeedback()
                );
                
                JScrollPane scrollPane = new JScrollPane(feedbackArea);
                scrollPane.setPreferredSize(new Dimension(500, 300));
                
                JOptionPane.showMessageDialog(this, scrollPane, 
                    "Detailed Feedback - " + result.getCourseCode(), 
                    JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this,
                    "No feedback available for this assessment.",
                    "Feedback Not Available",
                    JOptionPane.INFORMATION_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this,
                "Please select a row to view feedback.",
                "No Selection",
                JOptionPane.WARNING_MESSAGE);
        }
    }
    
    private void exportResults() {
        if (currentResults.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                "No results to export!",
                "Export Results",
                JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        
        StringBuilder exportText = new StringBuilder();
        exportText.append("ASSESSMENT RESULTS REPORT\n");
        exportText.append("=========================\n\n");
        exportText.append("Student: ").append(student.getName()).append("\n");
        exportText.append("Student ID: ").append(student.getUserID()).append("\n");
        exportText.append("Export Date: ").append(new java.util.Date()).append("\n\n");
        exportText.append("========================================\n\n");
        
        double totalMarks = 0;
        double highest = 0;
        double lowest = 100;
        
        for (Result result : currentResults) {
            exportText.append("MODULE: ").append(result.getCourseCode()).append("\n");
            exportText.append("ASSESSMENT ID: ").append(result.getAssessmentType()).append("\n");
            exportText.append("MARKS: ").append(result.getMarks()).append("\n");
            exportText.append("GRADE: ").append(result.getGrade()).append("\n");
            exportText.append("LECTURER: ").append(result.getLecturerID()).append("\n");
            exportText.append("FEEDBACK: ").append(result.getFeedback()).append("\n");
            exportText.append("----------------------------------------\n");
            
            double marks = result.getMarks();
            totalMarks += marks;
            if (marks > highest) highest = marks;
            if (marks < lowest) lowest = marks;
        }
        
        double average = totalMarks / currentResults.size();
        
        exportText.append("\nPERFORMANCE SUMMARY\n");
        exportText.append("===================\n");
        exportText.append("Total Assessments: ").append(currentResults.size()).append("\n");
        exportText.append("Average Marks: ").append(String.format("%.2f", average)).append("\n");
        exportText.append("Highest Score: ").append(highest).append("\n");
        exportText.append("Lowest Score: ").append(lowest).append("\n");
        
        // Display in a scrollable dialog
        JTextArea exportArea = new JTextArea(exportText.toString());
        exportArea.setEditable(false);
        exportArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        
        JScrollPane scrollPane = new JScrollPane(exportArea);
        scrollPane.setPreferredSize(new Dimension(600, 400));
        
        JOptionPane.showMessageDialog(this, scrollPane,
            "Exported Results - " + student.getName(),
            JOptionPane.INFORMATION_MESSAGE);
    }
}