public class LoginFrame extends afs.ui.LoginFrame {
    public LoginFrame() {
        super();
    }
}
