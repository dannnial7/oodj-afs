package afs.utils;

import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class ActivityLogger {
    
    /**
     * Logs an activity for a specific lecturer
     * @param lecturerId The ID of the lecturer performing the action
     * @param activity Description of the activity (e.g., "Designed assessment for CS101")
     */
    public static void logActivity(String lecturerId, String activity) {
        if (lecturerId == null || lecturerId.isEmpty()) {
            System.err.println("Error: Lecturer ID is null or empty");
            return;
        }
        
        String filename = "data_files/activities_" + lecturerId + ".txt";
        String timestamp = LocalDateTime.now()
                .format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename, true))) {
            writer.write(timestamp + " - " + activity);
            writer.newLine();
            System.out.println("✓ Activity logged for " + lecturerId + ": " + activity);
        } catch (IOException e) {
            System.err.println("Error logging activity: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * Alternative method that takes a Lecturer object
     * @param lecturer The lecturer object
     * @param activity Description of the activity
     */
    public static void logActivity(afs.model.Lecturer lecturer, String activity) {
        if (lecturer != null) {
            logActivity(lecturer.getUserId(), activity);
        }
    }
}