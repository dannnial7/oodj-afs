package afs.storage;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public final class AppPaths {
    private AppPaths() {}

    public static Path dataDir() {
        Path dir = Paths.get("data_files");
        if (!Files.exists(dir)) {
            try {
                Files.createDirectories(dir);
            } catch (Exception ignored) {
            }
        }
        return dir;
    }

    public static Path usersFile() {
        return dataDir().resolve("users.txt");
    }

    public static Path modulesFile() {
        return dataDir().resolve("modules.txt");
    }

    public static Path leaderAssignmentsFile() {
        return dataDir().resolve("leader_assignments.txt");
    }

    public static Path gradingFile() {
        return dataDir().resolve("grading.txt");
    }
}
