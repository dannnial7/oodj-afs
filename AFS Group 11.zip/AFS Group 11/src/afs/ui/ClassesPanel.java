package afs.ui;

import afs.model.ClassRecord;
import afs.repo.ClassRepository;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

public class ClassesPanel extends JPanel {
    private final ClassRepository repo = new ClassRepository();
    private final DefaultTableModel model;
    private final JTable table;
    private final TableRowSorter<DefaultTableModel> sorter;
    private final PromptTextField searchField;

    public ClassesPanel() {
        setLayout(new BorderLayout(10, 10));
        setOpaque(false);

        model = new DefaultTableModel(new Object[]{
                "ClassID", "ModuleID", "Class Name", "Intake"
        }, 0) {
            public boolean isCellEditable(int row, int column) { return false; }
        };
        table = new JTable(model);
        AdminTheme.styleTable(table);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        sorter = new TableRowSorter<>(model);
        table.setRowSorter(sorter);

        JPanel toolbar = new JPanel();
        toolbar.setOpaque(false);
        toolbar.setLayout(new BoxLayout(toolbar, BoxLayout.Y_AXIS));

        JPanel searchRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        searchRow.setOpaque(false);

        JPanel actionRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        actionRow.setOpaque(false);
        PillButton createBtn = new PillButton(
                "Create Class",
                new PlusIcon(Color.WHITE, 12),
                new Color(126, 94, 245),
                new Color(88, 58, 206)
        );
        PillButton enrollBtn = new PillButton(
                "Enroll Student",
                new PlusIcon(Color.WHITE, 12),
                new Color(88, 58, 206),
                new Color(126, 94, 245)
        );
        PillButton viewStudentsBtn = new PillButton(
                "View Students",
                null,
                new Color(126, 94, 245),
                new Color(88, 58, 206)
        );
        JButton editBtn = new JButton("Edit Class");
        JButton deleteBtn = new JButton("Delete Class");
        JButton refreshBtn = new JButton("Refresh");
        AdminTheme.styleSecondaryButton(editBtn);
        AdminTheme.styleSecondaryButton(deleteBtn);
        AdminTheme.styleSecondaryButton(refreshBtn);
        actionRow.add(createBtn);
        actionRow.add(enrollBtn);
        actionRow.add(viewStudentsBtn);
        actionRow.add(editBtn);
        actionRow.add(deleteBtn);
        actionRow.add(refreshBtn);
        searchField = new PromptTextField(22, "Search classes...");
        searchField.setPreferredSize(new Dimension(230, 40));
        AdminTheme.styleSearchField(searchField);
        searchField.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { applySearch(); }
            public void removeUpdate(DocumentEvent e) { applySearch(); }
            public void changedUpdate(DocumentEvent e) { applySearch(); }
        });
        searchRow.add(searchField);
        toolbar.add(searchRow);
        toolbar.add(Box.createVerticalStrut(8));
        toolbar.add(actionRow);

        JScrollPane tableScroll = new JScrollPane(table);
        tableScroll.setBorder(BorderFactory.createEmptyBorder());
        tableScroll.getViewport().setBackground(AdminTheme.cardBg());

        add(toolbar, BorderLayout.NORTH);
        add(tableScroll, BorderLayout.CENTER);

        refresh();

        createBtn.addActionListener(e -> createClass());
        enrollBtn.addActionListener(e -> enrollStudent());
        viewStudentsBtn.addActionListener(e -> viewStudents());
        editBtn.addActionListener(e -> editClass());
        deleteBtn.addActionListener(e -> deleteClass());
        refreshBtn.addActionListener(e -> refresh());
    }

    private void refresh() {
        model.setRowCount(0);
        for (ClassRecord c : repo.load()) {
            model.addRow(new Object[]{c.getClassId(), c.getModuleId(), c.getClassName(), c.getIntake()});
        }
        if (model.getRowCount() > 0 && table.getSelectedRow() < 0) {
            table.setRowSelectionInterval(0, 0);
        }
    }

    private void createClass() {
        ClassFormDialog dialog = new ClassFormDialog(SwingUtilities.getWindowAncestor(this), "Create Class", null);
        dialog.setVisible(true);
        ClassRecord c = dialog.getResult();
        if (c == null) return;

        List<ClassRecord> list = repo.load();
        for (ClassRecord existing : list) {
            if (existing.getClassId().equalsIgnoreCase(c.getClassId())) {
                JOptionPane.showMessageDialog(this, "ClassID already exists.");
                return;
            }
        }
        list.add(c);
        save(list);
    }

    private void enrollStudent() {
        EnrollStudentDialog dialog = new EnrollStudentDialog(SwingUtilities.getWindowAncestor(this));
        dialog.setVisible(true);
    }

    private void viewStudents() {
        String classId = selectedClassId();
        if (Validation.isBlank(classId)) {
            JOptionPane.showMessageDialog(this, "Select a class first.");
            return;
        }
        ClassEnrollmentsDialog dialog = new ClassEnrollmentsDialog(
                SwingUtilities.getWindowAncestor(this),
                classId
        );
        dialog.setVisible(true);
    }

    private void editClass() {
        int row = table.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Select a class to edit.");
            return;
        }
        ClassRecord current = new ClassRecord(
                model.getValueAt(row, 0).toString(),
                model.getValueAt(row, 1).toString(),
                model.getValueAt(row, 2).toString(),
                model.getValueAt(row, 3).toString()
        );
        ClassFormDialog dialog = new ClassFormDialog(SwingUtilities.getWindowAncestor(this), "Edit Class", current);
        dialog.setVisible(true);
        ClassRecord c = dialog.getResult();
        if (c == null) return;

        List<ClassRecord> list = repo.load();
        List<ClassRecord> updated = new ArrayList<>();
        boolean found = false;
        for (ClassRecord existing : list) {
            if (existing.getClassId().equalsIgnoreCase(c.getClassId())) {
                updated.add(c);
                found = true;
            } else {
                updated.add(existing);
            }
        }
        if (!found) {
            JOptionPane.showMessageDialog(this, "ClassID not found.");
            return;
        }
        save(updated);
    }

    private void deleteClass() {
        int row = table.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Select a class to delete.");
            return;
        }
        String classId = model.getValueAt(row, 0).toString();
        int confirm = JOptionPane.showConfirmDialog(this, "Delete class " + classId + "?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) return;

        List<ClassRecord> list = repo.load();
        List<ClassRecord> updated = new ArrayList<>();
        boolean removed = false;
        for (ClassRecord c : list) {
            if (c.getClassId().equalsIgnoreCase(classId)) {
                removed = true;
            } else {
                updated.add(c);
            }
        }
        if (!removed) {
            JOptionPane.showMessageDialog(this, "ClassID not found.");
            return;
        }
        save(updated);
    }

    private String selectedClassId() {
        int row = table.getSelectedRow();
        if (row < 0) return "";
        return model.getValueAt(row, 0).toString();
    }

    private void save(List<ClassRecord> list) {
        try {
            repo.save(list);
            refresh();
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Failed to save classes.");
        }
    }

    private void applySearch() {
        String q = searchField.getText() == null ? "" : searchField.getText().trim();
        if (q.isEmpty()) {
            sorter.setRowFilter(null);
            return;
        }
        sorter.setRowFilter(RowFilter.regexFilter("(?i)" + Pattern.quote(q)));
    }
}
