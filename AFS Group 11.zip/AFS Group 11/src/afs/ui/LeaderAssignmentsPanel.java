package afs.ui;

import afs.model.LeaderAssignment;
import afs.repo.LeaderAssignmentRepository;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

public class LeaderAssignmentsPanel extends JPanel {
    private final LeaderAssignmentRepository repo = new LeaderAssignmentRepository();
    private final DefaultTableModel model;
    private final JTable table;
    private final TableRowSorter<DefaultTableModel> sorter;
    private final PromptTextField searchField;

    public LeaderAssignmentsPanel() {
        setLayout(new BorderLayout(10, 10));
        setOpaque(false);

        model = new DefaultTableModel(new Object[]{
                "Academic Leader ID", "Lecturer ID"
        }, 0) {
            public boolean isCellEditable(int row, int column) { return false; }
        };
        table = new JTable(model);
        AdminTheme.styleTable(table);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        sorter = new TableRowSorter<>(model);
        table.setRowSorter(sorter);

        JPanel toolbar = new JPanel();
        toolbar.setOpaque(false);
        toolbar.setLayout(new BoxLayout(toolbar, BoxLayout.Y_AXIS));
        JPanel searchRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        searchRow.setOpaque(false);
        JPanel actionRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        actionRow.setOpaque(false);
        PillButton createBtn = new PillButton(
                "Assign Lecturer",
                new PlusIcon(Color.WHITE, 12),
                new Color(126, 94, 245),
                new Color(88, 58, 206)
        );
        JButton editBtn = new JButton("Edit Assignment");
        JButton deleteBtn = new JButton("Remove Assignment");
        JButton refreshBtn = new JButton("Refresh");
        AdminTheme.styleSecondaryButton(editBtn);
        AdminTheme.styleSecondaryButton(deleteBtn);
        AdminTheme.styleSecondaryButton(refreshBtn);
        actionRow.add(createBtn);
        actionRow.add(editBtn);
        actionRow.add(deleteBtn);
        actionRow.add(refreshBtn);
        searchField = new PromptTextField(22, "Search");
        searchField.setPreferredSize(new Dimension(230, 40));
        AdminTheme.styleSearchField(searchField);
        searchField.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { applySearch(); }
            public void removeUpdate(DocumentEvent e) { applySearch(); }
            public void changedUpdate(DocumentEvent e) { applySearch(); }
        });
        searchRow.add(searchField);
        toolbar.add(searchRow);
        toolbar.add(Box.createVerticalStrut(8));
        toolbar.add(actionRow);

        JScrollPane tableScroll = new JScrollPane(table);
        tableScroll.setBorder(BorderFactory.createEmptyBorder());
        tableScroll.getViewport().setBackground(AdminTheme.cardBg());

        add(toolbar, BorderLayout.NORTH);
        add(tableScroll, BorderLayout.CENTER);

        refresh();

        createBtn.addActionListener(e -> createAssignment());
        editBtn.addActionListener(e -> editAssignment());
        deleteBtn.addActionListener(e -> deleteAssignment());
        refreshBtn.addActionListener(e -> refresh());
    }

    private void refresh() {
        model.setRowCount(0);
        for (LeaderAssignment la : repo.load()) {
            model.addRow(new Object[]{la.leaderId, la.lecturerId});
        }
    }

    private void createAssignment() {
        LeaderAssignDialog dialog = new LeaderAssignDialog(SwingUtilities.getWindowAncestor(this), "Assign Lecturer", null);
        dialog.setVisible(true);
        LeaderAssignment la = dialog.getResult();
        if (la == null) return;

        List<LeaderAssignment> items = repo.load();
        for (LeaderAssignment existing : items) {
            if (existing.leaderId.equalsIgnoreCase(la.leaderId) && existing.lecturerId.equalsIgnoreCase(la.lecturerId)) {
                JOptionPane.showMessageDialog(this, "Assignment already exists.");
                return;
            }
        }
        items.add(la);
        save(items);
    }

    private void editAssignment() {
        int row = table.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Select an assignment to edit.");
            return;
        }
        LeaderAssignment current = new LeaderAssignment(
                model.getValueAt(row, 0).toString(),
                model.getValueAt(row, 1).toString()
        );
        LeaderAssignDialog dialog = new LeaderAssignDialog(SwingUtilities.getWindowAncestor(this), "Edit Assignment", current);
        dialog.setVisible(true);
        LeaderAssignment la = dialog.getResult();
        if (la == null) return;

        List<LeaderAssignment> items = repo.load();
        List<LeaderAssignment> updated = new ArrayList<>();
        boolean found = false;
        for (LeaderAssignment existing : items) {
            if (existing.leaderId.equalsIgnoreCase(current.leaderId) && existing.lecturerId.equalsIgnoreCase(current.lecturerId)) {
                updated.add(la);
                found = true;
            } else {
                updated.add(existing);
            }
        }
        if (!found) {
            JOptionPane.showMessageDialog(this, "Assignment not found.");
            return;
        }
        save(updated);
    }

    private void deleteAssignment() {
        int row = table.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Select an assignment to remove.");
            return;
        }
        String leaderId = model.getValueAt(row, 0).toString();
        String lecturerId = model.getValueAt(row, 1).toString();
        int confirm = JOptionPane.showConfirmDialog(this, "Remove assignment?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) return;

        List<LeaderAssignment> items = repo.load();
        List<LeaderAssignment> updated = new ArrayList<>();
        boolean removed = false;
        for (LeaderAssignment la : items) {
            if (la.leaderId.equalsIgnoreCase(leaderId) && la.lecturerId.equalsIgnoreCase(lecturerId)) {
                removed = true;
            } else {
                updated.add(la);
            }
        }
        if (!removed) {
            JOptionPane.showMessageDialog(this, "Assignment not found.");
            return;
        }
        save(updated);
    }

    private void save(List<LeaderAssignment> items) {
        try {
            repo.save(items);
            refresh();
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Failed to save assignments.");
        }
    }

    private void applySearch() {
        String q = searchField.getText() == null ? "" : searchField.getText().trim();
        if (q.isEmpty()) {
            sorter.setRowFilter(null);
            return;
        }
        sorter.setRowFilter(RowFilter.regexFilter("(?i)" + Pattern.quote(q)));
    }
}
