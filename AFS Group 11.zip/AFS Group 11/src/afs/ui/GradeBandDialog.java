package afs.ui;

import afs.model.GradeBand;

import javax.swing.*;
import java.awt.*;

public class GradeBandDialog extends JDialog {
    private GradeBand result;

    private final JTextField gradeField = new JTextField(10);
    private final JTextField minField = new JTextField(6);
    private final JTextField maxField = new JTextField(6);

    public GradeBandDialog(Window owner, String title, GradeBand existing) {
        super(owner, title, ModalityType.APPLICATION_MODAL);
        setSize(520, 260);
        setLocationRelativeTo(owner);
        setLayout(new BorderLayout(12, 12));

        JPanel form = new JPanel(new GridLayout(3, 2, 10, 10));
        form.setBorder(UiTheme.pad(16, 16));
        form.add(label("Grade"));
        form.add(fieldWrap(gradeField));
        form.add(label("Min Mark"));
        form.add(fieldWrap(minField));
        form.add(label("Max Mark"));
        form.add(fieldWrap(maxField));

        if (existing != null) {
            gradeField.setText(existing.grade);
            gradeField.setEnabled(false);
            minField.setText(String.valueOf(existing.min));
            maxField.setText(String.valueOf(existing.max));
        }

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        JButton cancel = new JButton("Cancel");
        PillButton save = new PillButton(
                existing == null ? "Create" : "Save Changes",
                null,
                new Color(126, 94, 245),
                new Color(88, 58, 206)
        );
        UiTheme.styleSecondaryButton(cancel);
        actions.setBorder(UiTheme.pad(0, 16));
        actions.add(cancel);
        actions.add(save);

        add(form, BorderLayout.CENTER);
        add(actions, BorderLayout.SOUTH);

        cancel.addActionListener(e -> { result = null; dispose(); });
        save.addActionListener(e -> {
            GradeBand g = buildBand();
            if (g != null) {
                result = g;
                dispose();
            }
        });
    }

    public GradeBand getResult() { return result; }

    private JLabel label(String text) {
        JLabel l = new JLabel(text);
        l.setForeground(UiTheme.MUTED);
        l.setFont(UiTheme.SMALL);
        return l;
    }

    private JComponent fieldWrap(JComponent c) {
        c.setFont(UiTheme.BODY);
        c.setBackground(Color.WHITE);
        c.setBorder(UiTheme.pad(8, 10));
        return c;
    }

    private GradeBand buildBand() {
        String grade = gradeField.getText().trim();
        String minStr = minField.getText().trim();
        String maxStr = maxField.getText().trim();
        if (Validation.isBlank(grade) || Validation.isBlank(minStr) || Validation.isBlank(maxStr)) {
            JOptionPane.showMessageDialog(this, "All fields are required.");
            return null;
        }
        int min, max;
        try {
            min = Integer.parseInt(minStr);
            max = Integer.parseInt(maxStr);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Min and Max must be numbers.");
            return null;
        }
        if (min < 0 || max > 100 || min > max) {
            JOptionPane.showMessageDialog(this, "Invalid range. Use 0-100 and min <= max.");
            return null;
        }
        return new GradeBand(grade, min, max);
    }
}
