package afs.ui;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import java.awt.*;

public final class AdminTheme {
    private AdminTheme() {}

    private static boolean darkMode = false;

    public static boolean isDarkMode() {
        return darkMode;
    }

    public static void toggle() {
        darkMode = !darkMode;
    }

    public static Color pageBg() {
        return darkMode ? new Color(20, 22, 31) : UiTheme.BG;
    }

    public static Color pageBgAlt() {
        return darkMode ? new Color(27, 30, 40) : new Color(240, 242, 252);
    }

    public static Color cardBg() {
        return darkMode ? new Color(31, 34, 46) : UiTheme.CARD;
    }

    public static Color text() {
        return darkMode ? new Color(236, 239, 248) : UiTheme.TEXT;
    }

    public static Color muted() {
        return darkMode ? new Color(154, 161, 181) : UiTheme.MUTED;
    }

    public static Color border() {
        return darkMode ? new Color(66, 72, 92) : UiTheme.BORDER;
    }

    public static Color sidebarButton() {
        return darkMode ? new Color(82, 62, 176) : new Color(92, 64, 184);
    }

    public static Color sidebarButtonSelected() {
        return darkMode ? new Color(146, 122, 246) : new Color(132, 104, 240);
    }

    public static Color sidebarFooterButton() {
        return darkMode ? new Color(100, 74, 198) : new Color(92, 64, 184);
    }

    public static Color sidebarGradientStart() {
        return darkMode ? new Color(43, 29, 108) : new Color(78, 52, 180);
    }

    public static Color sidebarGradientEnd() {
        return darkMode ? new Color(27, 16, 74) : new Color(58, 36, 140);
    }

    public static Color heroGradientStart() {
        return darkMode ? new Color(59, 42, 137) : UiTheme.PRIMARY;
    }

    public static Color heroGradientEnd() {
        return darkMode ? new Color(31, 20, 86) : UiTheme.PRIMARY_DARK;
    }

    public static void styleSecondaryButton(JButton b) {
        if (!darkMode) {
            UiTheme.styleSecondaryButton(b);
            return;
        }
        b.setBackground(new Color(47, 52, 68));
        b.setForeground(text());
        b.setFocusPainted(false);
        b.setBorder(UiTheme.pad(8, 14));
        b.setFont(UiTheme.SMALL.deriveFont(Font.BOLD, 12f));
    }

    public static void styleTable(JTable table) {
        UiTheme.styleTable(table);
        if (!darkMode) {
            return;
        }
        table.setBackground(cardBg());
        table.setForeground(text());
        table.setGridColor(border());
        table.setSelectionBackground(new Color(77, 86, 120));
        table.setSelectionForeground(Color.WHITE);
        table.setShowGrid(true);
        JTableHeader header = table.getTableHeader();
        header.setBackground(new Color(45, 50, 66));
        header.setForeground(text());
        header.setBorder(BorderFactory.createLineBorder(border()));
        DefaultTableCellRenderer renderer = (DefaultTableCellRenderer) table.getDefaultRenderer(Object.class);
        renderer.setBackground(cardBg());
        renderer.setForeground(text());
    }

    public static void styleSearchField(PromptTextField field) {
        if (darkMode) {
            field.setBackground(new Color(34, 37, 50));
            field.setForeground(text());
            field.setCaretColor(text());
            field.setStrokeColor(border());
            field.setPromptColor(new Color(140, 147, 168));
        } else {
            field.setBackground(Color.WHITE);
            field.setForeground(UiTheme.TEXT);
            field.setCaretColor(UiTheme.TEXT);
            field.setStrokeColor(new Color(220, 223, 230));
            field.setPromptColor(new Color(160, 160, 175));
        }
    }
}
