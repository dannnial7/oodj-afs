package afs.ui;

import javax.swing.*;
import java.awt.*;

public class QuickActionCard extends JPanel {
    private final Color c1;
    private final Color c2;
    private final String label;
    private final Icon icon;

    public QuickActionCard(String label, Icon icon, Color c1, Color c2) {
        this.label = label;
        this.icon = icon;
        this.c1 = c1;
        this.c2 = c2;
        setOpaque(false);
        setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        setPreferredSize(new Dimension(210, 120));
        setLayout(new BorderLayout());

        JPanel inner = new JPanel(new BorderLayout());
        inner.setOpaque(false);
        inner.setBorder(UiTheme.pad(18, 16));

        JPanel iconRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 0));
        iconRow.setOpaque(false);
        iconRow.setPreferredSize(new Dimension(10, 56));
        CircleBadge badge = new CircleBadge(icon, 44);
        iconRow.add(badge);

        JLabel text = new JLabel(label, SwingConstants.CENTER);
        text.setForeground(Color.WHITE);
        text.setFont(UiTheme.SMALL.deriveFont(Font.BOLD, 12f));

        inner.add(iconRow, BorderLayout.NORTH);
        inner.add(text, BorderLayout.CENTER);
        add(inner, BorderLayout.CENTER);
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        int w = getWidth();
        int h = getHeight();
        GradientPaint gp = new GradientPaint(0, 0, c1, w, h, c2);
        g2.setPaint(gp);
        g2.fillRoundRect(0, 0, w, h, 18, 18);
        g2.dispose();
        super.paintComponent(g);
    }

    private static class CircleBadge extends JComponent {
        private final Icon icon;
        private final int size;

        CircleBadge(Icon icon, int size) {
            this.icon = icon;
            this.size = size;
            setPreferredSize(new Dimension(size, size));
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(Color.WHITE);
            g2.fillOval(0, 0, getWidth(), getHeight());
            int ix = (getWidth() - icon.getIconWidth()) / 2;
            int iy = (getHeight() - icon.getIconHeight()) / 2;
            icon.paintIcon(this, g2, ix, iy);
            g2.dispose();
        }
    }
}
