package afs.ui;

import afs.model.ClassEnrollment;
import afs.model.ClassRecord;
import afs.model.EnrollmentRecord;
import afs.model.User;
import afs.repo.ClassEnrollmentRepository;
import afs.repo.ClassRepository;
import afs.repo.EnrollmentRepository;
import afs.repo.UserRepository;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class EnrollStudentDialog extends JDialog {
    private boolean saved = false;

    private final JComboBox<String> classBox = new JComboBox<>();
    private final JComboBox<String> studentBox = new JComboBox<>();

    public EnrollStudentDialog(Window owner) {
        super(owner, "Enroll Student", ModalityType.APPLICATION_MODAL);
        setSize(520, 240);
        setLocationRelativeTo(owner);
        setLayout(new BorderLayout(12, 12));

        JPanel form = new JPanel(new GridLayout(2, 2, 10, 10));
        form.setBorder(UiTheme.pad(16, 16));
        form.add(label("Class"));
        form.add(fieldWrap(classBox));
        form.add(label("Student"));
        form.add(fieldWrap(studentBox));

        loadClasses();
        classBox.addActionListener(e -> refreshStudents());
        refreshStudents();

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        JButton cancel = new JButton("Cancel");
        PillButton save = new PillButton(
                "Enroll",
                null,
                new Color(126, 94, 245),
                new Color(88, 58, 206)
        );
        UiTheme.styleSecondaryButton(cancel);
        actions.setBorder(UiTheme.pad(0, 16));
        actions.add(cancel);
        actions.add(save);

        add(form, BorderLayout.CENTER);
        add(actions, BorderLayout.SOUTH);

        cancel.addActionListener(e -> { saved = false; dispose(); });
        save.addActionListener(e -> enroll());
    }

    public boolean isSaved() { return saved; }

    private void loadClasses() {
        classBox.removeAllItems();
        for (ClassRecord c : new ClassRepository().load()) {
            classBox.addItem(c.getClassId());
        }
    }

    private void refreshStudents() {
        studentBox.removeAllItems();
        String classId = classBox.getSelectedItem() == null ? "" : classBox.getSelectedItem().toString();
        if (Validation.isBlank(classId)) return;

        ClassRecord selected = null;
        for (ClassRecord c : new ClassRepository().load()) {
            if (c.getClassId().equalsIgnoreCase(classId)) {
                selected = c;
                break;
            }
        }
        if (selected == null) return;

        String moduleId = selected.getModuleId();

        Set<String> enrolledInModule = new HashSet<>();
        for (EnrollmentRecord er : new EnrollmentRepository().load()) {
            if (moduleId.equalsIgnoreCase(er.getModuleId())) {
                enrolledInModule.add(er.getStudentId());
            }
        }

        List<String> students = new ArrayList<>();
        for (User u : new UserRepository().load()) {
            if ("Student".equalsIgnoreCase(u.getRole()) && enrolledInModule.contains(u.getUserId())) {
                students.add(u.getUserId());
            }
        }

        for (String s : students) {
            studentBox.addItem(s);
        }
    }

    private void enroll() {
        String classId = classBox.getSelectedItem() == null ? "" : classBox.getSelectedItem().toString();
        String studentId = studentBox.getSelectedItem() == null ? "" : studentBox.getSelectedItem().toString();
        if (Validation.isBlank(classId) || Validation.isBlank(studentId)) {
            JOptionPane.showMessageDialog(this, "Select class and student.");
            return;
        }

        ClassEnrollmentRepository repo = new ClassEnrollmentRepository();
        List<ClassEnrollment> list = repo.load();
        for (ClassEnrollment ce : list) {
            if (ce.getClassId().equalsIgnoreCase(classId) && ce.getStudentId().equalsIgnoreCase(studentId)) {
                JOptionPane.showMessageDialog(this, "Student already enrolled in this class.");
                return;
            }
        }

        list.add(new ClassEnrollment(classId, studentId, LocalDate.now().toString()));
        try {
            repo.save(list);
            saved = true;
            dispose();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Failed to enroll student.");
        }
    }

    private JLabel label(String text) {
        JLabel l = new JLabel(text);
        l.setForeground(UiTheme.MUTED);
        l.setFont(UiTheme.SMALL);
        return l;
    }

    private JComponent fieldWrap(JComponent c) {
        c.setFont(UiTheme.BODY);
        c.setBackground(Color.WHITE);
        c.setBorder(UiTheme.pad(8, 10));
        return c;
    }
}
