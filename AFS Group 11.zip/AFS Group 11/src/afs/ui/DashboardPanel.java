package afs.ui;

import javax.swing.*;
import java.awt.*;

public class DashboardPanel extends JPanel {
    public interface NavigationHandler {
        void show(String key);
    }

    private final NavigationHandler nav;

    public DashboardPanel(NavigationHandler nav) {
        this.nav = nav;
        setBackground(AdminTheme.pageBg());
        setLayout(new BorderLayout(12, 12));

        JPanel heroWrap = new GradientPanel(AdminTheme.heroGradientStart(), AdminTheme.heroGradientEnd());
        heroWrap.setLayout(new BorderLayout(12, 12));
        heroWrap.setBorder(UiTheme.pad(18, 22));

        JPanel heroLeft = new JPanel(new BorderLayout(0, 8));
        heroLeft.setOpaque(false);

        ImagePanel avatar = new ImagePanel("assets/profile.png");
        avatar.setPreferredSize(new Dimension(72, 72));
        avatar.setMaximumSize(new Dimension(72, 72));
        JPanel avatarWrap = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        avatarWrap.setOpaque(false);
        avatarWrap.add(avatar);

        JPanel heroText = new JPanel(new GridLayout(3, 1, 0, 6));
        heroText.setOpaque(false);
        JLabel title = new JLabel("Welcome, Admin Staff");
        title.setFont(UiTheme.H1);
        title.setForeground(Color.WHITE);
        JLabel subtitle = new JLabel("Manage users, classes, assignments and grading with ease.");
        subtitle.setFont(UiTheme.BODY);
        subtitle.setForeground(new Color(230, 230, 245));
        heroText.add(title);
        heroText.add(subtitle);
        heroText.add(new JLabel(""));

        heroLeft.add(avatarWrap, BorderLayout.NORTH);
        heroLeft.add(heroText, BorderLayout.CENTER);

        JPanel heroRight = new JPanel(new BorderLayout());
        heroRight.setOpaque(false);
        ImagePanel heroImage = new ImagePanel("assets/hero.png");
        heroImage.setPreferredSize(new Dimension(360, 200));
        heroImage.setAlignBottom(true);
        heroRight.add(heroImage, BorderLayout.CENTER);

        heroWrap.add(heroLeft, BorderLayout.WEST);
        heroWrap.add(heroRight, BorderLayout.EAST);

        add(heroWrap, BorderLayout.NORTH);

        JPanel center = new JPanel(new BorderLayout(10, 10));
        center.setOpaque(false);

        JPanel actions = new JPanel(new GridLayout(1, 4, 14, 14));
        actions.setOpaque(false);
        actions.add(quickAction("Manage Users", VectorIcons.icon(VectorIcons.Type.USERS, new Color(73, 63, 168)), new Color(74, 48, 168), new Color(123, 99, 224), "Users"));
        actions.add(quickAction("Manage Classes", VectorIcons.icon(VectorIcons.Type.MODULES, new Color(40, 120, 120)), new Color(26, 126, 150), new Color(116, 214, 235), "Classes"));
        actions.add(quickAction("Assign Lecturer", VectorIcons.icon(VectorIcons.Type.ASSIGN, new Color(20, 60, 160)), new Color(40, 60, 160), new Color(114, 144, 235), "Assign Lecturer"));
        actions.add(quickAction("Define Grades", VectorIcons.icon(VectorIcons.Type.GRADING, new Color(40, 120, 70)), new Color(52, 135, 92), new Color(146, 224, 120), "Grading"));

        JPanel quickWrap = new JPanel(new BorderLayout(0, 8));
        quickWrap.setOpaque(false);
        JLabel quickTitle = new JLabel("Quick Actions");
        quickTitle.setFont(UiTheme.H2);
        quickTitle.setForeground(AdminTheme.text());
        quickWrap.add(quickTitle, BorderLayout.NORTH);
        quickWrap.add(actions, BorderLayout.CENTER);

        center.add(quickWrap, BorderLayout.NORTH);

        add(center, BorderLayout.CENTER);
    }

    private JPanel quickAction(String label, Icon icon, Color c1, Color c2, String target) {
        QuickActionCard card = new QuickActionCard(label, icon, c1, c2);
        card.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent e) {
                if (nav != null) nav.show(target);
            }
        });
        return card;
    }

}
