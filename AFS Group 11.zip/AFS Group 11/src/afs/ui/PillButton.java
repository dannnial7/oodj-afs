package afs.ui;

import javax.swing.*;
import java.awt.*;

public class PillButton extends JButton {
    private final Color c1;
    private final Color c2;

    public PillButton(String text, Icon icon, Color c1, Color c2) {
        super(text, icon);
        this.c1 = c1;
        this.c2 = c2;
        setFocusPainted(false);
        setContentAreaFilled(false);
        setBorder(UiTheme.pad(8, 16));
        setForeground(Color.WHITE);
        setFont(UiTheme.SMALL.deriveFont(Font.BOLD, 12f));
        setIconTextGap(8);
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        int w = getWidth();
        int h = getHeight();
        GradientPaint gp = new GradientPaint(0, 0, c1, w, h, c2);
        g2.setPaint(gp);
        g2.fillRoundRect(0, 0, w, h, h, h);
        g2.dispose();
        super.paintComponent(g);
    }
}
