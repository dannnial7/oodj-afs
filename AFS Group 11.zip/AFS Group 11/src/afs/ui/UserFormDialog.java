package afs.ui;

import afs.model.GeneralUser;
import afs.model.User;

import javax.swing.*;
import java.awt.*;

public class UserFormDialog extends JDialog {
    private User result;

    private final JTextField userIdField = new JTextField(14);
    private final JPasswordField passwordField = new JPasswordField(14);
    private final JTextField nameField = new JTextField(14);
    private final JTextField emailField = new JTextField(14);
    private final JTextField contactField = new JTextField(14);
    private final JComboBox<String> roleBox = new JComboBox<>(new String[]{
            "Admin Staff", "Academic Leader", "Lecturer", "Student"
    });

    public UserFormDialog(Window owner, String title, User existing) {
        super(owner, title, ModalityType.APPLICATION_MODAL);
        setSize(520, 360);
        setLocationRelativeTo(owner);
        setLayout(new BorderLayout(12, 12));

        JPanel form = new JPanel(new GridLayout(6, 2, 10, 10));
        form.setBorder(UiTheme.pad(16, 16));
        form.add(label("User ID"));
        form.add(fieldWrap(userIdField));
        form.add(label("Password"));
        form.add(fieldWrap(passwordField));
        form.add(label("Full Name"));
        form.add(fieldWrap(nameField));
        form.add(label("Email"));
        form.add(fieldWrap(emailField));
        form.add(label("Contact"));
        form.add(fieldWrap(contactField));
        form.add(label("Role"));
        form.add(fieldWrap(roleBox));

        if (existing != null) {
            userIdField.setText(existing.getUserId());
            userIdField.setEnabled(false);
            passwordField.setText(existing.getPassword());
            nameField.setText(existing.getName());
            emailField.setText(existing.getEmail());
            contactField.setText(existing.getContactNum());
            roleBox.setSelectedItem(existing.getRole());
        }

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        JButton cancel = new JButton("Cancel");
        PillButton save = new PillButton(
                existing == null ? "Create" : "Save Changes",
                null,
                new Color(126, 94, 245),
                new Color(88, 58, 206)
        );
        UiTheme.styleSecondaryButton(cancel);
        actions.setBorder(UiTheme.pad(0, 16));
        actions.add(cancel);
        actions.add(save);

        add(form, BorderLayout.CENTER);
        add(actions, BorderLayout.SOUTH);

        cancel.addActionListener(e -> {
            result = null;
            dispose();
        });

        save.addActionListener(e -> {
            User u = buildUserFromForm();
            if (u != null) {
                result = u;
                dispose();
            }
        });
    }

    public User getResult() {
        return result;
    }

    private JLabel label(String text) {
        JLabel l = new JLabel(text);
        l.setForeground(UiTheme.MUTED);
        l.setFont(UiTheme.SMALL);
        return l;
    }

    private JComponent fieldWrap(JComponent c) {
        c.setFont(UiTheme.BODY);
        c.setBackground(Color.WHITE);
        c.setBorder(UiTheme.pad(8, 10));
        return c;
    }

    private User buildUserFromForm() {
        String userId = userIdField.getText().trim();
        String password = new String(passwordField.getPassword()).trim();
        String name = nameField.getText().trim();
        String email = emailField.getText().trim();
        String contact = contactField.getText().trim();
        String role = roleBox.getSelectedItem().toString();

        if (Validation.isBlank(userId) || Validation.isBlank(password) || Validation.isBlank(name)) {
            JOptionPane.showMessageDialog(this, "UserID, Password, and Name are required.");
            return null;
        }
        if (!Validation.isEmail(email)) {
            JOptionPane.showMessageDialog(this, "Invalid email.");
            return null;
        }
        if (!Validation.isNumeric(contact)) {
            JOptionPane.showMessageDialog(this, "Contact must be numeric.");
            return null;
        }
        return new GeneralUser(userId, password, name, email, contact, role);
    }
}
