package afs.ui;

import afs.model.ClassEnrollment;
import afs.model.ClassRecord;
import afs.model.EnrollmentRecord;
import afs.model.User;
import afs.repo.ClassEnrollmentRepository;
import afs.repo.ClassRepository;
import afs.repo.EnrollmentRepository;
import afs.repo.UserRepository;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class EditEnrollmentDialog extends JDialog {
    private boolean saved = false;

    private final String classId;
    private final String originalStudentId;
    private final JComboBox<String> studentBox = new JComboBox<>();
    private final JTextField dateField = new JTextField(14);

    public EditEnrollmentDialog(Window owner, String classId, String studentId, String date) {
        super(owner, "Edit Enrollment", ModalityType.APPLICATION_MODAL);
        this.classId = classId;
        this.originalStudentId = studentId;
        setSize(520, 260);
        setLocationRelativeTo(owner);
        setLayout(new BorderLayout(12, 12));

        JPanel form = new JPanel(new GridLayout(3, 2, 10, 10));
        form.setBorder(UiTheme.pad(16, 16));
        form.add(label("Class"));
        JTextField classField = new JTextField(classId);
        classField.setEnabled(false);
        form.add(fieldWrap(classField));
        form.add(label("Student"));
        form.add(fieldWrap(studentBox));
        form.add(label("Enrollment Date"));
        dateField.setText(date);
        form.add(fieldWrap(dateField));

        loadStudents();
        studentBox.setSelectedItem(studentId);

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        JButton cancel = new JButton("Cancel");
        PillButton save = new PillButton(
                "Save",
                null,
                new Color(126, 94, 245),
                new Color(88, 58, 206)
        );
        UiTheme.styleSecondaryButton(cancel);
        actions.setBorder(UiTheme.pad(0, 16));
        actions.add(cancel);
        actions.add(save);

        add(form, BorderLayout.CENTER);
        add(actions, BorderLayout.SOUTH);

        cancel.addActionListener(e -> { saved = false; dispose(); });
        save.addActionListener(e -> onSave());
    }

    public boolean isSaved() { return saved; }

    private void loadStudents() {
        studentBox.removeAllItems();
        ClassRecord selected = null;
        for (ClassRecord c : new ClassRepository().load()) {
            if (c.getClassId().equalsIgnoreCase(classId)) {
                selected = c;
                break;
            }
        }
        if (selected == null) return;

        String moduleId = selected.getModuleId();
        Set<String> enrolledInModule = new HashSet<>();
        for (EnrollmentRecord er : new EnrollmentRepository().load()) {
            if (moduleId.equalsIgnoreCase(er.getModuleId())) {
                enrolledInModule.add(er.getStudentId());
            }
        }

        List<String> students = new ArrayList<>();
        for (User u : new UserRepository().load()) {
            if ("Student".equalsIgnoreCase(u.getRole()) && enrolledInModule.contains(u.getUserId())) {
                students.add(u.getUserId());
            }
        }
        for (String s : students) {
            studentBox.addItem(s);
        }
    }

    private void onSave() {
        String studentId = studentBox.getSelectedItem() == null ? "" : studentBox.getSelectedItem().toString();
        String date = dateField.getText().trim();
        if (Validation.isBlank(studentId) || Validation.isBlank(date)) {
            JOptionPane.showMessageDialog(this, "Student and date are required.");
            return;
        }

        ClassEnrollmentRepository repo = new ClassEnrollmentRepository();
        List<ClassEnrollment> list = repo.load();
        List<ClassEnrollment> updated = new ArrayList<>();
        boolean found = false;
        for (ClassEnrollment ce : list) {
            if (ce.getClassId().equalsIgnoreCase(classId)
                    && ce.getStudentId().equalsIgnoreCase(studentId)
                    && !ce.getStudentId().equalsIgnoreCase(originalStudentId)) {
                JOptionPane.showMessageDialog(this, "Student already enrolled in this class.");
                return;
            }
        }
        for (ClassEnrollment ce : list) {
            if (ce.getClassId().equalsIgnoreCase(classId) && ce.getStudentId().equalsIgnoreCase(originalStudentId)) {
                updated.add(new ClassEnrollment(classId, studentId, date));
                found = true;
            } else {
                updated.add(ce);
            }
        }
        if (!found) {
            updated.add(new ClassEnrollment(classId, studentId, date));
        }

        try {
            repo.save(updated);
            saved = true;
            dispose();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Failed to save enrollment.");
        }
    }

    private JLabel label(String text) {
        JLabel l = new JLabel(text);
        l.setForeground(UiTheme.MUTED);
        l.setFont(UiTheme.SMALL);
        return l;
    }

    private JComponent fieldWrap(JComponent c) {
        c.setFont(UiTheme.BODY);
        c.setBackground(Color.WHITE);
        c.setBorder(UiTheme.pad(8, 10));
        return c;
    }
}
