package afs.ui;

import javax.swing.*;
import java.awt.*;

public class GradientPanel extends JPanel {
    private final Color c1;
    private final Color c2;

    public GradientPanel(Color c1, Color c2) {
        this.c1 = c1;
        this.c2 = c2;
        setOpaque(false);
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        int w = getWidth();
        int h = getHeight();
        g2.setPaint(new GradientPaint(0, 0, c1, w, h, c2));
        g2.fillRoundRect(0, 0, w, h, 24, 24);
        g2.dispose();
        super.paintComponent(g);
    }
}
