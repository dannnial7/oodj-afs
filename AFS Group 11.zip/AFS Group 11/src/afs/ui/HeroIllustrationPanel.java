package afs.ui;

import javax.swing.*;
import java.awt.*;

public class HeroIllustrationPanel extends JPanel {
    public HeroIllustrationPanel() {
        setOpaque(false);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int w = getWidth();
        int h = getHeight();

        g2.setColor(new Color(255, 255, 255, 30));
        g2.fillOval(w - 180, -40, 220, 220);
        g2.fillOval(w - 120, h - 140, 200, 200);

        g2.setColor(new Color(255, 255, 255, 70));
        g2.fillRoundRect(20, h / 2 - 30, 140, 90, 16, 16);

        g2.setColor(new Color(255, 255, 255, 200));
        g2.fillRect(30, h / 2 + 30, 20, 20);
        g2.fillRect(60, h / 2 + 10, 20, 40);
        g2.fillRect(90, h / 2 - 5, 20, 55);

        g2.dispose();
    }
}
