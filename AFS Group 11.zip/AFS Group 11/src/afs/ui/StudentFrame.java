package afs.ui;

import javax.swing.*;
import java.awt.*;

public class StudentFrame extends JFrame {
    public StudentFrame() {
        UiTheme.applyBase();
        setTitle("AFS - Student");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(900, 600);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new BorderLayout());
        JLabel label = new JLabel("Student dashboard coming soon", SwingConstants.CENTER);
        label.setFont(UiTheme.H2);
        panel.add(label, BorderLayout.CENTER);
        setContentPane(panel);
    }
}
