package afs.ui;

import javax.swing.*;
import java.awt.*;

public class CardPanel extends JPanel {
    private final int radius = 18;
    private final int shadow = 10;

    public CardPanel() {
        setOpaque(false);
        setBorder(UiTheme.pad(16, 16));
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int w = getWidth();
        int h = getHeight();

        g2.setColor(new Color(20, 20, 40, 20));
        g2.fillRoundRect(6, 6, w - 12, h - 12, radius, radius);

        g2.setColor(AdminTheme.cardBg());
        g2.fillRoundRect(0, 0, w - 12, h - 12, radius, radius);

        g2.dispose();
        super.paintComponent(g);
    }

    @Override
    public Insets getInsets() {
        return new Insets(16, 16, 20, 20);
    }
}
