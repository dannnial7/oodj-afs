package afs.ui;

import javax.swing.*;
import java.awt.*;

public class SidebarButton extends JButton {
    private boolean selected;

    public SidebarButton(String text, Icon icon) {
        super(text, icon);
        setHorizontalAlignment(SwingConstants.LEFT);
        setIconTextGap(10);
        setFocusPainted(false);
        setBorder(UiTheme.pad(10, 18));
        setForeground(Color.WHITE);
        setBackground(AdminTheme.sidebarButton());
        setFont(UiTheme.SMALL.deriveFont(Font.BOLD, 12.5f));
        setContentAreaFilled(true);
        setPreferredSize(new Dimension(190, 42));
        setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
    }

    public void setSelectedState(boolean value) {
        this.selected = value;
        if (selected) {
            setBackground(AdminTheme.sidebarButtonSelected());
        } else {
            setBackground(AdminTheme.sidebarButton());
        }
    }
}
