package afs.ui;

import javax.swing.*;
import java.awt.*;

public final class VectorIcons {
    private VectorIcons() {}

    public enum Type { DASHBOARD, USERS, MODULES, ASSIGN, GRADING, MOON }

    public static Icon icon(Type type, Color color) {
        return new SimpleIcon(type, color, 16, 16);
    }

    private static final class SimpleIcon implements Icon {
        private final Type type;
        private final Color color;
        private final int w;
        private final int h;

        SimpleIcon(Type type, Color color, int w, int h) {
            this.type = type;
            this.color = color;
            this.w = w;
            this.h = h;
        }

        public int getIconWidth() { return w; }
        public int getIconHeight() { return h; }

        public void paintIcon(Component c, Graphics g, int x, int y) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(color);
            int cx = x + 1;
            int cy = y + 1;
            int ww = w - 2;
            int hh = h - 2;

            switch (type) {
                case DASHBOARD:
                    // Home icon
                    int[] xPoints = {cx + 2, cx + ww / 2, cx + ww - 2};
                    int[] yPoints = {cy + hh / 2, cy + 2, cy + hh / 2};
                    g2.drawPolygon(xPoints, yPoints, 3);
                    g2.drawRoundRect(cx + 4, cy + hh / 2, ww - 8, hh / 2, 3, 3);
                    g2.drawLine(cx + ww / 2, cy + hh / 2 + 2, cx + ww / 2, cy + hh - 4);
                    break;
                case USERS:
                    g2.drawOval(cx + 4, cy + 2, 6, 6);
                    g2.drawRoundRect(cx + 2, cy + 8, ww - 4, hh - 10, 6, 6);
                    break;
                case MODULES:
                    g2.drawRoundRect(cx, cy, ww, hh, 4, 4);
                    g2.drawLine(cx + 3, cy + 4, cx + ww - 3, cy + 4);
                    g2.drawLine(cx + 3, cy + 8, cx + ww - 3, cy + 8);
                    break;
                case ASSIGN:
                    g2.drawOval(cx + 1, cy + 4, 6, 6);
                    g2.drawOval(cx + 8, cy + 4, 6, 6);
                    g2.drawLine(cx + 7, cy + 7, cx + 9, cy + 7);
                    break;
                case GRADING:
                    g2.drawRoundRect(cx + 1, cy + 1, ww - 2, hh - 2, 4, 4);
                    g2.drawLine(cx + 3, cy + 5, cx + ww - 3, cy + 5);
                    g2.drawLine(cx + 3, cy + 9, cx + ww - 6, cy + 9);
                    g2.drawLine(cx + 3, cy + 12, cx + ww - 8, cy + 12);
                    break;
                case MOON:
                    g2.setStroke(new BasicStroke(1.8f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                    g2.drawArc(cx + 3, cy + 2, ww - 7, hh - 4, 55, 250);
                    g2.drawArc(cx + 6, cy + 2, ww - 8, hh - 4, 120, 210);
                    break;
                default:
                    break;
            }
            g2.dispose();
        }
    }
}
