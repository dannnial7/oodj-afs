package afs.ui;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;

public class ImagePanel extends JPanel {
    private BufferedImage image;

    public ImagePanel(String path) {
        setOpaque(false);
        try {
            image = ImageIO.read(new File(path));
        } catch (Exception ignored) {
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (image == null) return;
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
        int w = getWidth();
        int h = getHeight();
        int iw = image.getWidth();
        int ih = image.getHeight();
        double scale = Math.min((double) w / iw, (double) h / ih);
        int nw = (int) (iw * scale);
        int nh = (int) (ih * scale);
        int x = (w - nw) / 2;
        int y = (h - nh) / 2;
        if (alignBottom) {
            y = h - nh;
        }
        g2.drawImage(image, x, y, nw, nh, null);
        g2.dispose();
    }

    private boolean alignBottom = false;

    public void setAlignBottom(boolean alignBottom) {
        this.alignBottom = alignBottom;
        repaint();
    }
}
