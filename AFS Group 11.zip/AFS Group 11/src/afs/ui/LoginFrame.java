package afs.ui;

import afs.gui.LecturerDashboard;
import afs.model.Lecturer;
import afs.model.User;
import afs.repo.UserRepository;

import javax.swing.*;
import java.awt.*;
import java.lang.reflect.Constructor;

public class LoginFrame extends JFrame {
    private final PromptTextField userField = new PromptTextField(18, "your.email@apu.edu.my");
    private final PromptPasswordField passField = new PromptPasswordField(18, "Enter your password");

    public LoginFrame() {
        UiTheme.applyBase();
        setTitle("AFS - Login");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1100, 650);
        setLocationRelativeTo(null);

        Color pageBg = new Color(0xF9, 0xF9, 0xFB);

        JPanel root = new JPanel(new GridLayout(1, 2));
        root.setBackground(pageBg);

        ImagePanel leftImage = new ImagePanel("assets/login.png");
        leftImage.setBackground(pageBg);
        leftImage.setAlignBottom(true);
        JPanel left = new JPanel(new BorderLayout());
        left.setBackground(pageBg);
        left.add(leftImage, BorderLayout.CENTER);

        JPanel right = new JPanel(new BorderLayout());
        right.setBackground(pageBg);

        JPanel centerWrap = new JPanel(new GridBagLayout());
        centerWrap.setBackground(pageBg);

        int columnWidth = 380;

        Box box = Box.createVerticalBox();
        box.setOpaque(false);
        box.setMaximumSize(new Dimension(columnWidth, 520));

        ImagePanel logo = new ImagePanel("assets/login_logo.png");
        logo.setPreferredSize(new Dimension(280, 100));
        logo.setMaximumSize(new Dimension(300, 110));
        JPanel logoWrap = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        logoWrap.setOpaque(false);
        logoWrap.add(logo);
        logoWrap.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel title = new JLabel("Welcome back");
        title.setFont(new Font("SansSerif", Font.BOLD, 24));
        title.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel subtitle = new JLabel("Sign in to access your portal");
        subtitle.setForeground(new Color(120, 120, 135));
        subtitle.setFont(UiTheme.SMALL);
        subtitle.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel userLabel = new JLabel("Email or Username");
        userLabel.setFont(UiTheme.SMALL.deriveFont(Font.BOLD, 12f));
        userLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel passLabel = new JLabel("Password");
        passLabel.setFont(UiTheme.SMALL.deriveFont(Font.BOLD, 12f));

        JPanel passRow = new JPanel(new BorderLayout());
        passRow.setOpaque(false);
        passRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        passRow.setMaximumSize(new Dimension(columnWidth, 20));
        passRow.add(passLabel, BorderLayout.WEST);

        Dimension fieldSize = new Dimension(columnWidth, 42);
        userField.setMaximumSize(fieldSize);
        userField.setAlignmentX(Component.LEFT_ALIGNMENT);
        passField.setMaximumSize(fieldSize);
        passField.setAlignmentX(Component.LEFT_ALIGNMENT);

        PillButton loginBtn = new PillButton(
                "Sign In",
                null,
                new Color(126, 94, 245),
                new Color(88, 58, 206)
        );
        loginBtn.setPreferredSize(new Dimension(columnWidth, 46));
        loginBtn.setMaximumSize(new Dimension(columnWidth, 46));
        loginBtn.setAlignmentX(Component.LEFT_ALIGNMENT);

        box.add(logoWrap);
        box.add(Box.createVerticalStrut(12));
        box.add(title);
        box.add(Box.createVerticalStrut(6));
        box.add(subtitle);
        box.add(Box.createVerticalStrut(24));
        box.add(userLabel);
        box.add(Box.createVerticalStrut(6));
        box.add(userField);
        box.add(Box.createVerticalStrut(16));
        box.add(passRow);
        box.add(Box.createVerticalStrut(6));
        box.add(passField);
        box.add(Box.createVerticalStrut(22));
        box.add(loginBtn);

        centerWrap.add(box);

        JLabel footer = new JLabel("Internal APU Network \u2022 Secure Local System  Version 2.4.1");
        footer.setForeground(new Color(150, 150, 160));
        footer.setFont(UiTheme.SMALL);
        JPanel footerWrap = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 6));
        footerWrap.setBackground(pageBg);
        footerWrap.add(footer);

        right.add(centerWrap, BorderLayout.CENTER);
        right.add(footerWrap, BorderLayout.SOUTH);

        root.add(left);
        root.add(right);
        setContentPane(root);

        loginBtn.addActionListener(e -> login());
    }

    private void login() {
        String input = userField.getText().trim();
        String pass = new String(passField.getPassword()).trim();
        if (Validation.isBlank(input) || Validation.isBlank(pass)) {
            JOptionPane.showMessageDialog(this, "Enter Email/Username and Password.");
            return;
        }
        UserRepository repo = new UserRepository();
        User found = null;
        for (User u : repo.load()) {
            boolean idMatch = u.getUserId().equalsIgnoreCase(input);
            boolean emailMatch = u.getEmail() != null && u.getEmail().equalsIgnoreCase(input);
            if ((idMatch || emailMatch) && u.getPassword().equals(pass)) {
                found = u;
                break;
            }
        }
        if (found == null) {
            JOptionPane.showMessageDialog(this, "Invalid credentials.");
            return;
        }
        openByRole(found);
    }

    private void openByRole(User user) {
        String role = user.getRole();
        if ("Admin Staff".equalsIgnoreCase(role)) {
            new AdminStaffFrame().setVisible(true);
        } else if ("Academic Leader".equalsIgnoreCase(role)) {
            AssessmentFeedbackSystem.AcademicLeader leader =
                    new AssessmentFeedbackSystem.AcademicLeader(
                            user.getUserId(),
                            user.getPassword(),
                            user.getName(),
                            user.getEmail(),
                            user.getContactNum()
                    );
            new AssessmentFeedbackSystem.AcademicLeaderGUI(leader).setVisible(true);
        } else if ("Lecturer".equalsIgnoreCase(role) && user instanceof Lecturer) {
            new LecturerDashboard((Lecturer) user).setVisible(true);
        } else if ("Student".equalsIgnoreCase(role)) {
            if (!openStudentDashboard(user)) {
                return;
            }
        } else {
            new StudentFrame().setVisible(true);
        }
        dispose();
    }

    private boolean openStudentDashboard(User user) {
        try {
            Class<?> studentClass = Class.forName("Student");
            Constructor<?> studentCtor = studentClass.getConstructor(String.class, String.class, String.class, String.class);
            Object studentObj = studentCtor.newInstance(
                    user.getUserId(),
                    user.getName(),
                    user.getEmail(),
                    user.getPassword()
            );

            Class<?> dashboardClass = Class.forName("StudentDashboard");
            Constructor<?> dashboardCtor = dashboardClass.getConstructor(studentClass);
            JFrame dashboard = (JFrame) dashboardCtor.newInstance(studentObj);
            dashboard.setVisible(true);
            return true;
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Student module not available.");
            return false;
        }
    }
}
