package afs.ui;

import javax.swing.*;
import java.awt.*;

public class LecturerFrame extends JFrame {
    public LecturerFrame() {
        UiTheme.applyBase();
        setTitle("AFS - Lecturer");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(900, 600);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new BorderLayout());
        JLabel label = new JLabel("Lecturer dashboard coming soon", SwingConstants.CENTER);
        label.setFont(UiTheme.H2);
        panel.add(label, BorderLayout.CENTER);
        setContentPane(panel);
    }
}
