package afs.ui;

public final class Validation {
    private Validation() {}

    public static boolean isBlank(String s) {
        return s == null || s.trim().isEmpty();
    }

    public static boolean isEmail(String s) {
        return s != null && s.contains("@");
    }

    public static boolean isNumeric(String s) {
        if (s == null || s.isEmpty()) return false;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (Character.isDigit(c)) continue;
            if (c == '+' || c == '-' || c == ' ' || c == '(' || c == ')') continue;
            return false;
        }
        return true;
    }
}
