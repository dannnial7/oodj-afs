package afs.ui;

import afs.model.ClassEnrollment;
import afs.repo.ClassEnrollmentRepository;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ClassEnrollmentsDialog extends JDialog {
    private final String classId;
    private final DefaultTableModel model;
    private final JTable table;
    private final ClassEnrollmentRepository repo = new ClassEnrollmentRepository();
    private boolean changed = false;

    public ClassEnrollmentsDialog(Window owner, String classId) {
        super(owner, "Class Enrollments - " + classId, ModalityType.APPLICATION_MODAL);
        this.classId = classId;
        setSize(640, 420);
        setLocationRelativeTo(owner);
        setLayout(new BorderLayout(10, 10));

        model = new DefaultTableModel(new Object[]{"StudentID", "Enrollment Date"}, 0) {
            public boolean isCellEditable(int row, int column) { return false; }
        };
        table = new JTable(model);
        UiTheme.styleTable(table);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JScrollPane scroll = new JScrollPane(table);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        scroll.getViewport().setBackground(UiTheme.CARD);

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        JButton edit = new JButton("Edit Enrollment");
        JButton remove = new JButton("Remove Student");
        JButton close = new JButton("Close");
        UiTheme.styleSecondaryButton(edit);
        UiTheme.styleSecondaryButton(remove);
        UiTheme.styleSecondaryButton(close);
        actions.setBorder(UiTheme.pad(0, 12));
        actions.add(edit);
        actions.add(remove);
        actions.add(close);

        add(scroll, BorderLayout.CENTER);
        add(actions, BorderLayout.SOUTH);

        refresh();

        edit.addActionListener(e -> editEnrollment());
        remove.addActionListener(e -> removeEnrollment());
        close.addActionListener(e -> dispose());
    }

    public boolean isChanged() { return changed; }

    private void refresh() {
        model.setRowCount(0);
        for (ClassEnrollment ce : repo.load()) {
            if (ce.getClassId().equalsIgnoreCase(classId)) {
                model.addRow(new Object[]{ce.getStudentId(), ce.getEnrollmentDate()});
            }
        }
    }

    private void editEnrollment() {
        int row = table.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Select a student to edit.");
            return;
        }
        String studentId = model.getValueAt(row, 0).toString();
        String date = model.getValueAt(row, 1).toString();
        EditEnrollmentDialog dialog = new EditEnrollmentDialog(this, classId, studentId, date);
        dialog.setVisible(true);
        if (dialog.isSaved()) {
            changed = true;
            refresh();
        }
    }

    private void removeEnrollment() {
        int row = table.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Select a student to remove.");
            return;
        }
        String studentId = model.getValueAt(row, 0).toString();
        int confirm = JOptionPane.showConfirmDialog(this, "Remove student " + studentId + " from class " + classId + "?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) return;

        List<ClassEnrollment> list = repo.load();
        List<ClassEnrollment> updated = new ArrayList<>();
        boolean removed = false;
        for (ClassEnrollment ce : list) {
            if (ce.getClassId().equalsIgnoreCase(classId) && ce.getStudentId().equalsIgnoreCase(studentId)) {
                removed = true;
            } else {
                updated.add(ce);
            }
        }
        if (!removed) {
            JOptionPane.showMessageDialog(this, "Enrollment not found.");
            return;
        }
        try {
            repo.save(updated);
            changed = true;
            refresh();
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Failed to remove enrollment.");
        }
    }
}
