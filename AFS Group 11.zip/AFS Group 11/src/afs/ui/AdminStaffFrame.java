package afs.ui;

import javax.swing.*;
import java.awt.*;

public class AdminStaffFrame extends JFrame {
    public AdminStaffFrame() {
        UiTheme.applyBase();
        setTitle("AFS - Admin Staff");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1100, 720);
        setLocationRelativeTo(null);
        setMinimumSize(new Dimension(1000, 650));
        setContentPane(new MainShell());
    }
}
