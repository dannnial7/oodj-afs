package afs.ui;

import afs.model.ClassRecord;
import afs.model.Module;
import afs.repo.ModuleRepository;

import javax.swing.*;
import java.awt.*;

public class ClassFormDialog extends JDialog {
    private ClassRecord result;

    private final JTextField classIdField = new JTextField(14);
    private final JComboBox<String> moduleBox = new JComboBox<>();
    private final JTextField classNameField = new JTextField(14);
    private final JTextField intakeField = new JTextField(14);

    public ClassFormDialog(Window owner, String title, ClassRecord existing) {
        super(owner, title, ModalityType.APPLICATION_MODAL);
        setSize(560, 300);
        setLocationRelativeTo(owner);
        setLayout(new BorderLayout(12, 12));

        JPanel form = new JPanel(new GridLayout(4, 2, 10, 10));
        form.setBorder(UiTheme.pad(16, 16));
        form.add(label("Class ID"));
        form.add(fieldWrap(classIdField));
        form.add(label("Module"));
        form.add(fieldWrap(moduleBox));
        form.add(label("Class Name"));
        form.add(fieldWrap(classNameField));
        form.add(label("Intake"));
        form.add(fieldWrap(intakeField));

        for (Module m : new ModuleRepository().load()) {
            moduleBox.addItem(m.getModuleId());
        }

        if (existing != null) {
            classIdField.setText(existing.getClassId());
            classIdField.setEnabled(false);
            moduleBox.setSelectedItem(existing.getModuleId());
            classNameField.setText(existing.getClassName());
            intakeField.setText(existing.getIntake());
        }

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        JButton cancel = new JButton("Cancel");
        PillButton save = new PillButton(
                existing == null ? "Create" : "Save Changes",
                null,
                new Color(126, 94, 245),
                new Color(88, 58, 206)
        );
        UiTheme.styleSecondaryButton(cancel);
        actions.setBorder(UiTheme.pad(0, 16));
        actions.add(cancel);
        actions.add(save);

        add(form, BorderLayout.CENTER);
        add(actions, BorderLayout.SOUTH);

        cancel.addActionListener(e -> { result = null; dispose(); });
        save.addActionListener(e -> {
            ClassRecord c = build();
            if (c != null) {
                result = c;
                dispose();
            }
        });
    }

    public ClassRecord getResult() { return result; }

    private JLabel label(String text) {
        JLabel l = new JLabel(text);
        l.setForeground(UiTheme.MUTED);
        l.setFont(UiTheme.SMALL);
        return l;
    }

    private JComponent fieldWrap(JComponent c) {
        c.setFont(UiTheme.BODY);
        c.setBackground(Color.WHITE);
        c.setBorder(UiTheme.pad(8, 10));
        return c;
    }

    private ClassRecord build() {
        String classId = classIdField.getText().trim();
        Object moduleObj = moduleBox.getSelectedItem();
        String moduleId = moduleObj == null ? "" : moduleObj.toString();
        String className = classNameField.getText().trim();
        String intake = intakeField.getText().trim();

        if (Validation.isBlank(classId) || Validation.isBlank(moduleId) || Validation.isBlank(className)) {
            JOptionPane.showMessageDialog(this, "Class ID, Module, and Class Name are required.");
            return null;
        }
        return new ClassRecord(classId, moduleId, className, intake);
    }
}
