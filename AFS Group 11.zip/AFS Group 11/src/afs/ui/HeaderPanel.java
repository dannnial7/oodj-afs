package afs.ui;

import javax.swing.*;
import java.awt.*;

public class HeaderPanel extends JPanel {
    public HeaderPanel() {
        setBackground(AdminTheme.pageBg());
        setLayout(new BorderLayout(10, 0));

        JLabel title = new JLabel("Admin Staff");
        title.setFont(UiTheme.H2);
        title.setForeground(AdminTheme.text());

        JLabel subtitle = new JLabel("Assessment Feedback System");
        subtitle.setFont(UiTheme.SMALL);
        subtitle.setForeground(AdminTheme.muted());

        JPanel left = new JPanel(new GridLayout(2, 1, 0, 2));
        left.setOpaque(false);
        left.add(title);
        left.add(subtitle);

        add(left, BorderLayout.WEST);
    }
}
