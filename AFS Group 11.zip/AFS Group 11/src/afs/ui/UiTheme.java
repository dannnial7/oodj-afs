package afs.ui;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import java.awt.*;

public final class UiTheme {
    private UiTheme() {}

    public static final Color BG = new Color(244, 246, 252);
    public static final Color CARD = new Color(255, 255, 255);
    public static final Color PRIMARY = new Color(91, 66, 193);
    public static final Color PRIMARY_DARK = new Color(64, 42, 150);
    public static final Color ACCENT = new Color(125, 102, 245);
    public static final Color TEXT = new Color(33, 33, 44);
    public static final Color MUTED = new Color(117, 117, 135);
    public static final Color BORDER = new Color(226, 229, 239);

    private static Font base(int style, int size) {
        String[] candidates = {"Poppins", "Manrope", "SF Pro Display", "Segoe UI", "SansSerif"};
        for (String name : candidates) {
            Font f = new Font(name, style, size);
            if (f.getFamily().equalsIgnoreCase(name) || name.equals("SansSerif")) {
                return f;
            }
        }
        return new Font("SansSerif", style, size);
    }

    public static final Font H1 = base(Font.BOLD, 22);
    public static final Font H2 = base(Font.BOLD, 16);
    public static final Font BODY = base(Font.PLAIN, 13);
    public static final Font SMALL = base(Font.PLAIN, 12);

    public static void applyBase() {
        UIManager.put("Panel.background", BG);
        UIManager.put("Label.foreground", TEXT);
        UIManager.put("Label.font", BODY);
        UIManager.put("Button.font", base(Font.BOLD, 12));
        UIManager.put("TextField.font", BODY);
        UIManager.put("PasswordField.font", BODY);
        UIManager.put("ComboBox.font", BODY);
        UIManager.put("Table.font", BODY);
        UIManager.put("Table.background", CARD);
        UIManager.put("Table.foreground", TEXT);
        UIManager.put("Table.gridColor", BORDER);
        UIManager.put("Table.selectionBackground", new Color(232, 227, 252));
        UIManager.put("Table.selectionForeground", TEXT);
        UIManager.put("TableHeader.font", base(Font.BOLD, 12));
        UIManager.put("TableHeader.background", new Color(250, 251, 254));
        UIManager.put("TableHeader.foreground", TEXT);
    }

    public static void stylePrimaryButton(JButton b) {
        b.setBackground(PRIMARY);
        b.setForeground(Color.WHITE);
        b.setFocusPainted(false);
        b.setBorder(pad(8, 14));
        b.setFont(base(Font.BOLD, 12));
    }

    public static void styleSecondaryButton(JButton b) {
        b.setBackground(new Color(240, 242, 248));
        b.setForeground(TEXT);
        b.setFocusPainted(false);
        b.setBorder(pad(8, 14));
        b.setFont(base(Font.BOLD, 12));
    }

    public static void styleTable(JTable table) {
        table.setRowHeight(28);
        JTableHeader header = table.getTableHeader();
        header.setReorderingAllowed(false);
        DefaultTableCellRenderer r = new DefaultTableCellRenderer();
        r.setBorder(BorderFactory.createEmptyBorder(0, 8, 0, 8));
        table.setDefaultRenderer(Object.class, r);
    }

    public static Border pad(int v, int h) {
        return BorderFactory.createEmptyBorder(v, h, v, h);
    }
}
