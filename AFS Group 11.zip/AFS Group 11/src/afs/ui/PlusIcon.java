package afs.ui;

import javax.swing.*;
import java.awt.*;

public class PlusIcon implements Icon {
    private final Color color;
    private final int size;

    public PlusIcon(Color color, int size) {
        this.color = color;
        this.size = size;
    }

    public int getIconWidth() { return size; }
    public int getIconHeight() { return size; }

    public void paintIcon(Component c, Graphics g, int x, int y) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setColor(color);
        int s = size;
        int mid = s / 2;
        g2.setStroke(new BasicStroke(2f));
        g2.drawLine(x + 2, y + mid, x + s - 3, y + mid);
        g2.drawLine(x + mid, y + 2, x + mid, y + s - 3);
        g2.dispose();
    }
}
