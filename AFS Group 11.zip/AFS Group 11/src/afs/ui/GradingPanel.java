package afs.ui;

import afs.model.GradeBand;
import afs.repo.GradingRepository;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class GradingPanel extends JPanel {
    private final GradingRepository repo = new GradingRepository();
    private final DefaultTableModel model;
    private final JTable table;

    public GradingPanel() {
        setLayout(new BorderLayout(10, 10));
        setOpaque(false);

        model = new DefaultTableModel(new Object[]{
                "Grade", "Min", "Max"
        }, 0) {
            public boolean isCellEditable(int row, int column) { return false; }
        };
        table = new JTable(model);
        AdminTheme.styleTable(table);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JPanel toolbar = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        toolbar.setOpaque(false);
        PillButton createBtn = new PillButton(
                "Add Grade Band",
                new PlusIcon(Color.WHITE, 12),
                new Color(126, 94, 245),
                new Color(88, 58, 206)
        );
        JButton editBtn = new JButton("Edit Grade");
        JButton deleteBtn = new JButton("Delete Grade");
        JButton refreshBtn = new JButton("Refresh");
        AdminTheme.styleSecondaryButton(editBtn);
        AdminTheme.styleSecondaryButton(deleteBtn);
        AdminTheme.styleSecondaryButton(refreshBtn);
        toolbar.add(createBtn);
        toolbar.add(editBtn);
        toolbar.add(deleteBtn);
        toolbar.add(refreshBtn);

        JScrollPane tableScroll = new JScrollPane(table);
        tableScroll.setBorder(BorderFactory.createEmptyBorder());
        tableScroll.getViewport().setBackground(AdminTheme.cardBg());

        add(toolbar, BorderLayout.NORTH);
        add(tableScroll, BorderLayout.CENTER);

        refresh();

        createBtn.addActionListener(e -> createGrade());
        editBtn.addActionListener(e -> editGrade());
        deleteBtn.addActionListener(e -> deleteGrade());
        refreshBtn.addActionListener(e -> refresh());
    }

    private void refresh() {
        model.setRowCount(0);
        for (GradeBand g : repo.load()) {
            model.addRow(new Object[]{g.grade, g.min, g.max});
        }
    }

    private void createGrade() {
        GradeBandDialog dialog = new GradeBandDialog(SwingUtilities.getWindowAncestor(this), "Add Grade Band", null);
        dialog.setVisible(true);
        GradeBand g = dialog.getResult();
        if (g == null) return;

        List<GradeBand> items = repo.load();
        for (GradeBand existing : items) {
            if (existing.grade.equalsIgnoreCase(g.grade)) {
                JOptionPane.showMessageDialog(this, "Grade already exists.");
                return;
            }
        }
        items.add(g);
        save(items);
    }

    private void editGrade() {
        int row = table.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Select a grade to edit.");
            return;
        }
        GradeBand current = new GradeBand(
                model.getValueAt(row, 0).toString(),
                Integer.parseInt(model.getValueAt(row, 1).toString()),
                Integer.parseInt(model.getValueAt(row, 2).toString())
        );
        GradeBandDialog dialog = new GradeBandDialog(SwingUtilities.getWindowAncestor(this), "Edit Grade", current);
        dialog.setVisible(true);
        GradeBand g = dialog.getResult();
        if (g == null) return;

        List<GradeBand> items = repo.load();
        List<GradeBand> updated = new ArrayList<>();
        boolean found = false;
        for (GradeBand existing : items) {
            if (existing.grade.equalsIgnoreCase(current.grade)) {
                updated.add(g);
                found = true;
            } else {
                updated.add(existing);
            }
        }
        if (!found) {
            JOptionPane.showMessageDialog(this, "Grade not found.");
            return;
        }
        save(updated);
    }

    private void deleteGrade() {
        int row = table.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Select a grade to delete.");
            return;
        }
        String grade = model.getValueAt(row, 0).toString();
        int confirm = JOptionPane.showConfirmDialog(this, "Delete grade " + grade + "?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) return;

        List<GradeBand> items = repo.load();
        List<GradeBand> updated = new ArrayList<>();
        boolean removed = false;
        for (GradeBand g : items) {
            if (g.grade.equalsIgnoreCase(grade)) {
                removed = true;
            } else {
                updated.add(g);
            }
        }
        if (!removed) {
            JOptionPane.showMessageDialog(this, "Grade not found.");
            return;
        }
        save(updated);
    }

    private void save(List<GradeBand> items) {
        try {
            repo.save(items);
            refresh();
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Failed to save grading system.");
        }
    }
}
