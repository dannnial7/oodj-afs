package afs.ui;

import afs.model.User;
import afs.repo.UserRepository;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

public class UsersPanel extends JPanel {
    private final UserRepository repo = new UserRepository();
    private final DefaultTableModel model;
    private final JTable table;
    private final TableRowSorter<DefaultTableModel> sorter;
    private final PromptTextField searchField;

    public UsersPanel() {
        setLayout(new BorderLayout(10, 10));
        setOpaque(false);

        model = new DefaultTableModel(new Object[]{
                "UserID", "Password", "Name", "Email", "Contact", "Role"
        }, 0) {
            public boolean isCellEditable(int row, int column) { return false; }
        };
        table = new JTable(model);
        AdminTheme.styleTable(table);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        sorter = new TableRowSorter<>(model);
        table.setRowSorter(sorter);

        JPanel toolbar = new JPanel();
        toolbar.setOpaque(false);
        toolbar.setLayout(new BoxLayout(toolbar, BoxLayout.Y_AXIS));
        JPanel searchRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        searchRow.setOpaque(false);
        JPanel actionRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        actionRow.setOpaque(false);
        PillButton createBtn = new PillButton(
                "Create User",
                new PlusIcon(Color.WHITE, 12),
                new Color(126, 94, 245),
                new Color(88, 58, 206)
        );
        JButton editBtn = new JButton("Edit User");
        JButton deleteBtn = new JButton("Delete User");
        JButton refreshBtn = new JButton("Refresh");
        AdminTheme.styleSecondaryButton(editBtn);
        AdminTheme.styleSecondaryButton(deleteBtn);
        AdminTheme.styleSecondaryButton(refreshBtn);
        actionRow.add(createBtn);
        actionRow.add(editBtn);
        actionRow.add(deleteBtn);
        actionRow.add(refreshBtn);
        searchField = new PromptTextField(22, "Search users...");
        searchField.setPreferredSize(new Dimension(230, 40));
        AdminTheme.styleSearchField(searchField);
        searchField.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { applySearch(); }
            public void removeUpdate(DocumentEvent e) { applySearch(); }
            public void changedUpdate(DocumentEvent e) { applySearch(); }
        });
        searchRow.add(searchField);
        toolbar.add(searchRow);
        toolbar.add(Box.createVerticalStrut(8));
        toolbar.add(actionRow);

        JScrollPane tableScroll = new JScrollPane(table);
        tableScroll.setBorder(BorderFactory.createEmptyBorder());
        tableScroll.getViewport().setBackground(AdminTheme.cardBg());

        add(toolbar, BorderLayout.NORTH);
        add(tableScroll, BorderLayout.CENTER);

        refresh();

        createBtn.addActionListener(e -> createUser());
        editBtn.addActionListener(e -> editUser());
        deleteBtn.addActionListener(e -> deleteUser());
        refreshBtn.addActionListener(e -> refresh());
    }

    private void refresh() {
        model.setRowCount(0);
        for (User u : repo.load()) {
            model.addRow(new Object[]{u.getUserId(), u.getPassword(), u.getName(), u.getEmail(), u.getContactNum(), u.getRole()});
        }
    }

    private void createUser() {
        UserFormDialog dialog = new UserFormDialog(SwingUtilities.getWindowAncestor(this), "Create New User", null);
        dialog.setVisible(true);
        User u = dialog.getResult();
        if (u == null) return;

        List<User> users = repo.load();
        for (User existing : users) {
            if (existing.getUserId().equalsIgnoreCase(u.getUserId())) {
                JOptionPane.showMessageDialog(this, "UserID already exists.");
                return;
            }
        }
        users.add(u);
        save(users);
    }

    private void editUser() {
        int row = table.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Select a user to edit.");
            return;
        }
        User current = new afs.model.GeneralUser(
                model.getValueAt(row, 0).toString(),
                model.getValueAt(row, 1).toString(),
                model.getValueAt(row, 2).toString(),
                model.getValueAt(row, 3).toString(),
                model.getValueAt(row, 4).toString(),
                model.getValueAt(row, 5).toString()
        );

        UserFormDialog dialog = new UserFormDialog(SwingUtilities.getWindowAncestor(this), "Edit User", current);
        dialog.setVisible(true);
        User u = dialog.getResult();
        if (u == null) return;

        List<User> users = repo.load();
        List<User> updated = new ArrayList<>();
        boolean found = false;
        for (User existing : users) {
            if (existing.getUserId().equalsIgnoreCase(u.getUserId())) {
                updated.add(u);
                found = true;
            } else {
                updated.add(existing);
            }
        }
        if (!found) {
            JOptionPane.showMessageDialog(this, "UserID not found.");
            return;
        }
        save(updated);
    }

    private void deleteUser() {
        int row = table.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Select a user to delete.");
            return;
        }
        String userId = model.getValueAt(row, 0).toString();
        int confirm = JOptionPane.showConfirmDialog(this, "Delete user " + userId + "?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) return;

        List<User> users = repo.load();
        List<User> updated = new ArrayList<>();
        boolean removed = false;
        for (User u : users) {
            if (u.getUserId().equalsIgnoreCase(userId)) {
                removed = true;
            } else {
                updated.add(u);
            }
        }
        if (!removed) {
            JOptionPane.showMessageDialog(this, "UserID not found.");
            return;
        }
        save(updated);
    }

    private void save(List<User> users) {
        try {
            repo.save(users);
            refresh();
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Failed to save users.");
        }
    }

    private void applySearch() {
        String q = searchField.getText() == null ? "" : searchField.getText().trim();
        if (q.isEmpty()) {
            sorter.setRowFilter(null);
            return;
        }
        sorter.setRowFilter(RowFilter.regexFilter("(?i)" + Pattern.quote(q)));
    }
}
