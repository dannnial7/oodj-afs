package afs.ui;

import javax.swing.*;
import java.awt.*;

public class ContentShell extends JPanel {
    public ContentShell(String title, JComponent content) {
        setBackground(AdminTheme.pageBg());
        setLayout(new BorderLayout(10, 10));

        JLabel heading = new JLabel(title);
        heading.setFont(UiTheme.H2);
        heading.setForeground(AdminTheme.text());

        CardPanel card = new CardPanel();
        card.setLayout(new BorderLayout(8, 8));
        card.add(content, BorderLayout.CENTER);

        add(heading, BorderLayout.NORTH);
        add(card, BorderLayout.CENTER);
    }
}
