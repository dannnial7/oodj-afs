package afs.ui;

import afs.model.Module;
import afs.repo.ModuleRepository;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ModulesPanel extends JPanel {
    private final ModuleRepository repo = new ModuleRepository();
    private final DefaultTableModel model;
    private final JTable table;

    public ModulesPanel() {
        setLayout(new BorderLayout(10, 10));
        setOpaque(false);

        model = new DefaultTableModel(new Object[]{
                "ModuleID", "Module Name", "LecturerID"
        }, 0) {
            public boolean isCellEditable(int row, int column) { return false; }
        };
        table = new JTable(model);
        UiTheme.styleTable(table);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JPanel toolbar = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        toolbar.setOpaque(false);
        PillButton createBtn = new PillButton(
                "Create Module",
                new PlusIcon(Color.WHITE, 12),
                new Color(126, 94, 245),
                new Color(88, 58, 206)
        );
        JButton editBtn = new JButton("Edit Module");
        JButton deleteBtn = new JButton("Delete Module");
        JButton refreshBtn = new JButton("Refresh");
        UiTheme.styleSecondaryButton(editBtn);
        UiTheme.styleSecondaryButton(deleteBtn);
        UiTheme.styleSecondaryButton(refreshBtn);
        toolbar.add(createBtn);
        toolbar.add(editBtn);
        toolbar.add(deleteBtn);
        toolbar.add(refreshBtn);

        JScrollPane tableScroll = new JScrollPane(table);
        tableScroll.setBorder(BorderFactory.createEmptyBorder());
        tableScroll.getViewport().setBackground(UiTheme.CARD);

        add(toolbar, BorderLayout.NORTH);
        add(tableScroll, BorderLayout.CENTER);

        refresh();

        createBtn.addActionListener(e -> createModule());
        editBtn.addActionListener(e -> editModule());
        deleteBtn.addActionListener(e -> deleteModule());
        refreshBtn.addActionListener(e -> refresh());
    }

    private void refresh() {
        model.setRowCount(0);
        for (Module m : repo.load()) {
            model.addRow(new Object[]{m.getModuleId(), m.getModuleName(), m.getLecturerId()});
        }
    }

    private void createModule() {
        ModuleFormDialog dialog = new ModuleFormDialog(SwingUtilities.getWindowAncestor(this), "Create Module", null);
        dialog.setVisible(true);
        Module m = dialog.getResult();
        if (m == null) return;

        List<Module> modules = repo.load();
        for (Module existing : modules) {
            if (existing.getModuleId().equalsIgnoreCase(m.getModuleId())) {
                JOptionPane.showMessageDialog(this, "ModuleID already exists.");
                return;
            }
        }
        modules.add(m);
        save(modules);
    }

    private void editModule() {
        int row = table.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Select a module to edit.");
            return;
        }
        Module current = new Module(
                model.getValueAt(row, 0).toString(),
                model.getValueAt(row, 1).toString(),
                model.getValueAt(row, 2).toString()
        );
        ModuleFormDialog dialog = new ModuleFormDialog(SwingUtilities.getWindowAncestor(this), "Edit Module", current);
        dialog.setVisible(true);
        Module m = dialog.getResult();
        if (m == null) return;

        List<Module> modules = repo.load();
        List<Module> updated = new ArrayList<>();
        boolean found = false;
        for (Module existing : modules) {
            if (existing.getModuleId().equalsIgnoreCase(m.getModuleId())) {
                updated.add(m);
                found = true;
            } else {
                updated.add(existing);
            }
        }
        if (!found) {
            JOptionPane.showMessageDialog(this, "ModuleID not found.");
            return;
        }
        save(updated);
    }

    private void deleteModule() {
        int row = table.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Select a module to delete.");
            return;
        }
        String moduleId = model.getValueAt(row, 0).toString();
        int confirm = JOptionPane.showConfirmDialog(this, "Delete module " + moduleId + "?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) return;

        List<Module> modules = repo.load();
        List<Module> updated = new ArrayList<>();
        boolean removed = false;
        for (Module m : modules) {
            if (m.getModuleId().equalsIgnoreCase(moduleId)) {
                removed = true;
            } else {
                updated.add(m);
            }
        }
        if (!removed) {
            JOptionPane.showMessageDialog(this, "ModuleID not found.");
            return;
        }
        save(updated);
    }

    private void save(List<Module> modules) {
        try {
            repo.save(modules);
            refresh();
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Failed to save modules.");
        }
    }
}
