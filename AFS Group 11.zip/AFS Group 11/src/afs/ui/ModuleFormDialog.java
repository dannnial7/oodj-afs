package afs.ui;

import afs.model.Module;
import afs.model.User;
import afs.repo.UserRepository;

import javax.swing.*;
import java.awt.*;

public class ModuleFormDialog extends JDialog {
    private Module result;

    private final JTextField moduleIdField = new JTextField(14);
    private final JTextField moduleNameField = new JTextField(14);
    private final JComboBox<String> lecturerBox = new JComboBox<>();

    public ModuleFormDialog(Window owner, String title, Module existing) {
        super(owner, title, ModalityType.APPLICATION_MODAL);
        setSize(520, 300);
        setLocationRelativeTo(owner);
        setLayout(new BorderLayout(12, 12));

        JPanel form = new JPanel(new GridLayout(3, 2, 10, 10));
        form.setBorder(UiTheme.pad(16, 16));
        form.add(label("Module ID"));
        form.add(fieldWrap(moduleIdField));
        form.add(label("Module Name"));
        form.add(fieldWrap(moduleNameField));
        form.add(label("Lecturer"));
        form.add(fieldWrap(lecturerBox));

        for (User u : new UserRepository().load()) {
            if ("Lecturer".equalsIgnoreCase(u.getRole())) {
                lecturerBox.addItem(u.getUserId());
            }
        }

        if (existing != null) {
            moduleIdField.setText(existing.getModuleId());
            moduleIdField.setEnabled(false);
            moduleNameField.setText(existing.getModuleName());
            lecturerBox.setSelectedItem(existing.getLecturerId());
        }

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        JButton cancel = new JButton("Cancel");
        PillButton save = new PillButton(
                existing == null ? "Create" : "Save Changes",
                null,
                new Color(126, 94, 245),
                new Color(88, 58, 206)
        );
        UiTheme.styleSecondaryButton(cancel);
        actions.setBorder(UiTheme.pad(0, 16));
        actions.add(cancel);
        actions.add(save);

        add(form, BorderLayout.CENTER);
        add(actions, BorderLayout.SOUTH);

        cancel.addActionListener(e -> {
            result = null;
            dispose();
        });
        save.addActionListener(e -> {
            Module m = buildModule();
            if (m != null) {
                result = m;
                dispose();
            }
        });
    }

    public Module getResult() { return result; }

    private JLabel label(String text) {
        JLabel l = new JLabel(text);
        l.setForeground(UiTheme.MUTED);
        l.setFont(UiTheme.SMALL);
        return l;
    }

    private JComponent fieldWrap(JComponent c) {
        c.setFont(UiTheme.BODY);
        c.setBackground(Color.WHITE);
        c.setBorder(UiTheme.pad(8, 10));
        return c;
    }

    private Module buildModule() {
        String moduleId = moduleIdField.getText().trim();
        String moduleName = moduleNameField.getText().trim();
        Object lecturerObj = lecturerBox.getSelectedItem();
        String lecturerId = lecturerObj == null ? "" : lecturerObj.toString();

        if (Validation.isBlank(moduleId) || Validation.isBlank(moduleName)) {
            JOptionPane.showMessageDialog(this, "Module ID and Module Name are required.");
            return null;
        }
        if (Validation.isBlank(lecturerId)) {
            JOptionPane.showMessageDialog(this, "Select a lecturer.");
            return null;
        }
        return new Module(moduleId, moduleName, lecturerId);
    }
}
