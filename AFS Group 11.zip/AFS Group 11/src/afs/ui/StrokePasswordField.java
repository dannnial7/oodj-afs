package afs.ui;

import javax.swing.*;
import javax.swing.border.AbstractBorder;
import java.awt.*;

public class StrokePasswordField extends JPasswordField {
    public StrokePasswordField(int columns) {
        super(columns);
        setBorder(new RoundedBorder());
        setBackground(Color.WHITE);
        setFont(UiTheme.BODY);
    }

    private static class RoundedBorder extends AbstractBorder {
        @Override
        public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(new Color(220, 223, 230));
            g2.setStroke(new BasicStroke(1f));
            g2.drawRoundRect(x, y, width - 1, height - 1, 14, 14);
            g2.dispose();
        }

        @Override
        public Insets getBorderInsets(Component c) {
            return new Insets(10, 12, 10, 12);
        }

        @Override
        public Insets getBorderInsets(Component c, Insets insets) {
            insets.left = 12;
            insets.right = 12;
            insets.top = 10;
            insets.bottom = 10;
            return insets;
        }
    }
}
