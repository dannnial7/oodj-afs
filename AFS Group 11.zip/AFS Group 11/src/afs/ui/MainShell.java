package afs.ui;

import javax.swing.*;
import java.awt.*;
import java.util.LinkedHashMap;
import java.util.Map;

public class MainShell extends JPanel {
    private final CardLayout cards = new CardLayout();
    private final JPanel content = new JPanel(cards);

    public MainShell() {
        this("Dashboard");
    }

    public MainShell(String initialView) {
        setLayout(new BorderLayout());
        setBackground(AdminTheme.pageBg());

        GradientPanel sidebar = new GradientPanel(AdminTheme.sidebarGradientStart(), AdminTheme.sidebarGradientEnd());
        sidebar.setLayout(new BorderLayout());
        sidebar.setPreferredSize(new Dimension(230, 600));

        JPanel brandWrap = new JPanel(new BorderLayout(0, 8));
        brandWrap.setOpaque(false);
        brandWrap.setBorder(UiTheme.pad(16, 16));

        ImagePanel logo = new ImagePanel("assets/logo.png");
        logo.setPreferredSize(new Dimension(180, 90));
        logo.setMaximumSize(new Dimension(200, 100));

        JLabel brand = new JLabel("APU Assessment Feedback System", SwingConstants.CENTER);
        brand.setForeground(Color.WHITE);
        brand.setFont(UiTheme.SMALL.deriveFont(Font.BOLD, 12f));

        JPanel logoCol = new JPanel(new BorderLayout());
        logoCol.setOpaque(false);
        logoCol.add(logo, BorderLayout.NORTH);
        logoCol.add(brand, BorderLayout.CENTER);

        brandWrap.add(logoCol, BorderLayout.CENTER);

        JPanel nav = new JPanel();
        nav.setOpaque(false);
        nav.setLayout(new BoxLayout(nav, BoxLayout.Y_AXIS));
        nav.setBorder(UiTheme.pad(8, 10));

        Map<String, JComponent> views = new LinkedHashMap<>();
        Map<String, SidebarButton> buttons = new LinkedHashMap<>();

        final String[] currentView = new String[]{initialView};
        java.util.function.Consumer<String> showView = key -> {
            currentView[0] = key;
            cards.show(content, key);
            for (SidebarButton b : buttons.values()) {
                b.setSelectedState(false);
            }
            SidebarButton selected = buttons.get(key);
            if (selected != null) selected.setSelectedState(true);
        };

        views.put("Dashboard", new DashboardPanel(showView::accept));
        views.put("Users", new ContentShell("Manage Users", new UsersPanel()));
        views.put("Classes", new ContentShell("Manage Classes", new ClassesPanel()));
        views.put("Assign Lecturer", new ContentShell("Assign Lecturers", new LeaderAssignmentsPanel()));
        views.put("Grading", new ContentShell("Grading System", new GradingPanel()));

        buttons.put("Dashboard", new SidebarButton("Dashboard", VectorIcons.icon(VectorIcons.Type.DASHBOARD, Color.WHITE)));
        buttons.put("Users", new SidebarButton("Users", VectorIcons.icon(VectorIcons.Type.USERS, Color.WHITE)));
        buttons.put("Classes", new SidebarButton("Classes", VectorIcons.icon(VectorIcons.Type.MODULES, Color.WHITE)));
        buttons.put("Assign Lecturer", new SidebarButton("Assign Lecturer", VectorIcons.icon(VectorIcons.Type.ASSIGN, Color.WHITE)));
        buttons.put("Grading", new SidebarButton("Grading", VectorIcons.icon(VectorIcons.Type.GRADING, Color.WHITE)));

        for (Map.Entry<String, SidebarButton> entry : buttons.entrySet()) {
            String key = entry.getKey();
            SidebarButton btn = entry.getValue();
            btn.addActionListener(e -> showView.accept(key));
            btn.setAlignmentX(Component.LEFT_ALIGNMENT);
            nav.add(btn);
            nav.add(Box.createVerticalStrut(8));
        }
        nav.add(Box.createVerticalGlue());

        SidebarButton darkModeBtn = new SidebarButton(
                AdminTheme.isDarkMode() ? "Light Mode" : "Dark Mode",
                VectorIcons.icon(VectorIcons.Type.MOON, Color.WHITE)
        );
        darkModeBtn.addActionListener(e -> {
            AdminTheme.toggle();
            Window w = SwingUtilities.getWindowAncestor(MainShell.this);
            if (w instanceof JFrame) {
                JFrame frame = (JFrame) w;
                frame.setContentPane(new MainShell(currentView[0]));
                frame.revalidate();
                frame.repaint();
            }
        });
        darkModeBtn.setAlignmentX(Component.LEFT_ALIGNMENT);
        nav.add(darkModeBtn);
        nav.add(Box.createVerticalStrut(8));

        for (Map.Entry<String, JComponent> entry : views.entrySet()) {
            content.add(entry.getValue(), entry.getKey());
        }

        if (views.containsKey(initialView)) {
            showView.accept(initialView);
        } else {
            showView.accept("Dashboard");
        }

        JPanel footer = new JPanel(new BorderLayout());
        footer.setOpaque(false);
        footer.setBorder(UiTheme.pad(10, 16));

        JButton logout = new JButton("Logout");
        logout.setForeground(Color.WHITE);
        logout.setBackground(AdminTheme.sidebarFooterButton());
        logout.setFocusPainted(false);
        logout.setBorder(UiTheme.pad(10, 18));
        logout.setFont(UiTheme.SMALL.deriveFont(Font.BOLD, 12.5f));
        logout.addActionListener(e -> {
            Window w = SwingUtilities.getWindowAncestor(MainShell.this);
            if (w != null) w.dispose();
            new LoginFrame().setVisible(true);
        });
        footer.add(logout, BorderLayout.CENTER);

        BackgroundPanel mainBg = new BackgroundPanel();
        mainBg.setLayout(new BorderLayout(10, 10));
        mainBg.setBorder(UiTheme.pad(10, 10));

        JPanel top = new JPanel(new BorderLayout());
        top.setOpaque(false);
        top.setBorder(UiTheme.pad(6, 6));
        top.add(new HeaderPanel(), BorderLayout.CENTER);

        content.setOpaque(false);
        mainBg.add(top, BorderLayout.NORTH);
        mainBg.add(content, BorderLayout.CENTER);

        sidebar.add(brandWrap, BorderLayout.NORTH);
        sidebar.add(nav, BorderLayout.CENTER);
        sidebar.add(footer, BorderLayout.SOUTH);

        add(sidebar, BorderLayout.WEST);
        add(mainBg, BorderLayout.CENTER);
    }
}
