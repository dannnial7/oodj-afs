package afs.ui;

import java.awt.*;

public class PromptPasswordField extends StrokePasswordField {
    private final String prompt;

    public PromptPasswordField(int columns, String prompt) {
        super(columns);
        this.prompt = prompt;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (getPassword().length == 0 && !isFocusOwner()) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setColor(new Color(160, 160, 175));
            g2.setFont(getFont());
            Insets in = getInsets();
            g2.drawString(prompt, in.left, getHeight() / 2 + getFont().getSize() / 2 - 4);
            g2.dispose();
        }
    }
}
