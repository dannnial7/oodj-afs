package afs.ui;

import afs.model.LeaderAssignment;
import afs.model.User;
import afs.repo.UserRepository;

import javax.swing.*;
import java.awt.*;

public class LeaderAssignDialog extends JDialog {
    private LeaderAssignment result;

    private final JComboBox<String> leaderBox = new JComboBox<>();
    private final JComboBox<String> lecturerBox = new JComboBox<>();

    public LeaderAssignDialog(Window owner, String title, LeaderAssignment existing) {
        super(owner, title, ModalityType.APPLICATION_MODAL);
        setSize(520, 240);
        setLocationRelativeTo(owner);
        setLayout(new BorderLayout(12, 12));

        JPanel form = new JPanel(new GridLayout(2, 2, 10, 10));
        form.setBorder(UiTheme.pad(16, 16));
        form.add(label("Academic Leader"));
        form.add(fieldWrap(leaderBox));
        form.add(label("Lecturer"));
        form.add(fieldWrap(lecturerBox));

        for (User u : new UserRepository().load()) {
            if ("Academic Leader".equalsIgnoreCase(u.getRole())) {
                leaderBox.addItem(u.getUserId());
            } else if ("Lecturer".equalsIgnoreCase(u.getRole())) {
                lecturerBox.addItem(u.getUserId());
            }
        }

        if (existing != null) {
            leaderBox.setSelectedItem(existing.leaderId);
            lecturerBox.setSelectedItem(existing.lecturerId);
        }

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        JButton cancel = new JButton("Cancel");
        PillButton save = new PillButton(
                existing == null ? "Assign" : "Save Changes",
                null,
                new Color(126, 94, 245),
                new Color(88, 58, 206)
        );
        UiTheme.styleSecondaryButton(cancel);
        actions.setBorder(UiTheme.pad(0, 16));
        actions.add(cancel);
        actions.add(save);

        add(form, BorderLayout.CENTER);
        add(actions, BorderLayout.SOUTH);

        cancel.addActionListener(e -> { result = null; dispose(); });
        save.addActionListener(e -> {
            String leaderId = leaderBox.getSelectedItem() == null ? "" : leaderBox.getSelectedItem().toString();
            String lecturerId = lecturerBox.getSelectedItem() == null ? "" : lecturerBox.getSelectedItem().toString();
            if (Validation.isBlank(leaderId) || Validation.isBlank(lecturerId)) {
                JOptionPane.showMessageDialog(this, "Select both leader and lecturer.");
                return;
            }
            result = new LeaderAssignment(leaderId, lecturerId);
            dispose();
        });
    }

    public LeaderAssignment getResult() { return result; }

    private JLabel label(String text) {
        JLabel l = new JLabel(text);
        l.setForeground(UiTheme.MUTED);
        l.setFont(UiTheme.SMALL);
        return l;
    }

    private JComponent fieldWrap(JComponent c) {
        c.setFont(UiTheme.BODY);
        c.setBackground(Color.WHITE);
        c.setBorder(UiTheme.pad(8, 10));
        return c;
    }
}
