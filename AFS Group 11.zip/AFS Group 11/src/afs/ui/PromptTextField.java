package afs.ui;

import java.awt.*;

public class PromptTextField extends StrokeTextField {
    private final String prompt;
    private Color promptColor = new Color(160, 160, 175);

    public PromptTextField(int columns, String prompt) {
        super(columns);
        this.prompt = prompt;
    }

    public void setPromptColor(Color promptColor) {
        this.promptColor = promptColor;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (getText().isEmpty() && !isFocusOwner()) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setColor(promptColor);
            g2.setFont(getFont());
            Insets in = getInsets();
            g2.drawString(prompt, in.left, getHeight() / 2 + getFont().getSize() / 2 - 4);
            g2.dispose();
        }
    }
}
