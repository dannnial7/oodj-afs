package afs.gui;

import afs.model.Lecturer;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.*;
import afs.utils.ActivityLogger;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class ViewStudentCommentsFrame extends JFrame {
    private Lecturer lecturer;
    private JTextField txtStudentId, txtModuleId;
    private JComboBox<String> cmbStudent;
    private JTable commentsTable;
    private DefaultTableModel tableModel;
    
    public ViewStudentCommentsFrame(Lecturer lecturer) {
        this.lecturer = lecturer;
        
        setTitle("View Student Comments");
        setSize(900, 700);
        setLocationRelativeTo(null);
        
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        
        // Title Panel
        JPanel titlePanel = new JPanel();
        titlePanel.setBackground(new Color(0, 102, 204));
        JLabel titleLabel = new JLabel("VIEW STUDENT COMMENTS");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setForeground(Color.WHITE);
        titlePanel.add(titleLabel);
        mainPanel.add(titlePanel, BorderLayout.NORTH);
        
        // Search Panel
        JPanel searchPanel = new JPanel(new GridBagLayout());
        searchPanel.setBorder(BorderFactory.createTitledBorder("Search Filters"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        // ===== STUDENT SELECTION =====
        gbc.gridx = 0; gbc.gridy = 0;
        searchPanel.add(new JLabel("Select Student:"), gbc);
        
        gbc.gridx = 1;
        cmbStudent = new JComboBox<>();
        cmbStudent.addItem("-- All Students --");
        loadStudents();
        searchPanel.add(cmbStudent, gbc);
        
        // Or Student ID
        gbc.gridx = 0; gbc.gridy = 1;
        searchPanel.add(new JLabel("OR Enter Student ID:"), gbc);
        
        gbc.gridx = 1;
        txtStudentId = new JTextField(20);
        searchPanel.add(txtStudentId, gbc);
        
        // ===== MODULE FILTER =====
        gbc.gridx = 0; gbc.gridy = 2;
        searchPanel.add(new JLabel("Module ID (Optional):"), gbc);
        
        gbc.gridx = 1;
        txtModuleId = new JTextField(20);
        searchPanel.add(txtModuleId, gbc);
        
        // ===== SEARCH BUTTONS =====
        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.NONE;
        JPanel buttonPanelTop = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
        
        JButton btnSearch = createStyledButton("Search Comments", new Color(0, 102, 204));
        btnSearch.addActionListener(e -> searchComments());
        
        JButton btnViewAll = createStyledButton("View All Comments", new Color(102, 0, 204));
        btnViewAll.addActionListener(e -> viewAllComments());
        
        JButton btnRefresh = createStyledButton("Refresh Students", new Color(0, 153, 76));
        btnRefresh.addActionListener(e -> refreshStudents());
        
        buttonPanelTop.add(btnSearch);
        buttonPanelTop.add(btnViewAll);
        buttonPanelTop.add(btnRefresh);
        
        searchPanel.add(buttonPanelTop, gbc);
        
        mainPanel.add(searchPanel, BorderLayout.NORTH);
        
        // ===== COMMENTS TABLE =====
        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.setBorder(BorderFactory.createTitledBorder("Student Comments"));
        
        // Create table model with columns
        String[] columns = {"No.", "Student ID", "Student Name", "Module ID", "Comment", "Date/Time", "Lecturer ID"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Make table read-only
            }
            
            @Override
            public Class<?> getColumnClass(int columnIndex) {
                return String.class; // All columns are strings
            }
        };
        
        commentsTable = new JTable(tableModel);
        commentsTable.setRowHeight(25);
        commentsTable.setFont(new Font("Arial", Font.PLAIN, 12));
        commentsTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 13));
        commentsTable.getTableHeader().setBackground(new Color(220, 230, 255));
        commentsTable.getTableHeader().setReorderingAllowed(false);
        
        // Set column widths
        commentsTable.getColumnModel().getColumn(0).setPreferredWidth(40);  // No.
        commentsTable.getColumnModel().getColumn(1).setPreferredWidth(80);  // Student ID
        commentsTable.getColumnModel().getColumn(2).setPreferredWidth(120); // Student Name
        commentsTable.getColumnModel().getColumn(3).setPreferredWidth(80);  // Module ID
        commentsTable.getColumnModel().getColumn(4).setPreferredWidth(250); // Comment
        commentsTable.getColumnModel().getColumn(5).setPreferredWidth(120); // Date/Time
        commentsTable.getColumnModel().getColumn(6).setPreferredWidth(80);  // Lecturer ID
        
        // Enable text wrapping for comment column
        commentsTable.getColumnModel().getColumn(4).setCellRenderer(new TextAreaRenderer());
        
        JScrollPane tableScroll = new JScrollPane(commentsTable);
        tableScroll.setPreferredSize(new Dimension(850, 400));
        
        // Add row selection listener
        commentsTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && commentsTable.getSelectedRow() != -1) {
                showSelectedCommentDetails();
            }
        });
        
        tablePanel.add(tableScroll, BorderLayout.CENTER);
        
        // ===== INFO PANEL =====
        JPanel infoPanel = new JPanel();
        infoPanel.setBackground(new Color(240, 248, 255));
        infoPanel.setBorder(BorderFactory.createTitledBorder("Table Information"));
        JLabel infoLabel = new JLabel("<html><div style='width: 850px;'>" +
            "<b>Table Controls:</b><br>" +
            "• <b>Click on any row</b> to view full comment details<br>" +
            "• <b>Sort columns</b> by clicking on column headers<br>" +
            "• <b>Resize columns</b> by dragging column borders<br>" +
            "• <b>Scroll horizontally</b> to see all columns<br>" +
            "• <b>Export table</b> to save comments to a file" +
            "</div></html>");
        infoPanel.add(infoLabel);
        tablePanel.add(infoPanel, BorderLayout.SOUTH);
        
        mainPanel.add(tablePanel, BorderLayout.CENTER);
        
        // ===== STATUS PANEL =====
        JPanel statusPanel = new JPanel(new BorderLayout());
        statusPanel.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        statusPanel.setBackground(new Color(245, 245, 245));
        
        JLabel statusLabel = new JLabel("Ready. Select filters and click 'Search Comments' or 'View All Comments'.");
        statusLabel.setFont(new Font("Arial", Font.PLAIN, 12));
        statusPanel.add(statusLabel, BorderLayout.WEST);
        
        JLabel countLabel = new JLabel("Total Comments: 0");
        countLabel.setFont(new Font("Arial", Font.BOLD, 12));
        countLabel.setName("countLabel");
        statusPanel.add(countLabel, BorderLayout.EAST);
        
        mainPanel.add(statusPanel, BorderLayout.SOUTH);
        
        // ===== BUTTON PANEL =====
        JPanel buttonPanelBottom = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        
        JButton btnExport = createStyledButton("Export Table to CSV", new Color(255, 153, 0));
        btnExport.addActionListener(e -> exportTableToCSV());
        
        JButton btnClearTable = createStyledButton("Clear Table", new Color(153, 153, 153));
        btnClearTable.addActionListener(e -> clearTable());
        
        JButton btnClose = createStyledButton("Close", new Color(204, 0, 0));
        btnClose.addActionListener(e -> dispose());
        
        buttonPanelBottom.add(btnExport);
        buttonPanelBottom.add(btnClearTable);
        buttonPanelBottom.add(btnClose);
        
        // Create a container panel for the button panel
        JPanel buttonContainer = new JPanel(new BorderLayout());
        buttonContainer.add(buttonPanelBottom, BorderLayout.CENTER);
        mainPanel.add(buttonContainer, BorderLayout.SOUTH);
        
        add(mainPanel);
        
        // Load all comments initially
        viewAllComments();
    }
    
    // ===== HELPER METHODS =====
    
    private JButton createStyledButton(String text, Color color) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(color.brighter());
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(color);
            }
        });
        
        return button;
    }
    
    // Load students from users.txt file
    private void loadStudents() {
        File file = new File("data_files/users.txt");
        if (!file.exists()) {
            cmbStudent.addItem("Error: users.txt not found");
            return;
        }
        
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            boolean isFirstLine = true;
            while ((line = br.readLine()) != null) {
                // Skip header if exists
                if (isFirstLine && (line.startsWith("UserID") || line.startsWith("UserID"))) {
                    isFirstLine = false;
                    continue;
                }
                isFirstLine = false;
                
                String[] parts = line.split(",");
                if (parts.length >= 6 && parts[5].equals("Student")) {
                    String studentId = parts[0];
                    String studentName = parts[2];
                    cmbStudent.addItem(studentId + " - " + studentName);
                }
            }
            
            if (cmbStudent.getItemCount() == 1) { // Only has "-- All Students --"
                cmbStudent.addItem("No students found in file");
            }
            
        } catch (IOException e) {
            cmbStudent.addItem("Error loading students");
            System.err.println("Error loading students: " + e.getMessage());
        }
    }
    
    // Refresh students list
    private void refreshStudents() {
        cmbStudent.removeAllItems();
        cmbStudent.addItem("-- All Students --");
        loadStudents();
        
        JOptionPane.showMessageDialog(this, 
            "Student list refreshed! Found " + (cmbStudent.getItemCount() - 1) + " students.",
            "Refresh Complete", JOptionPane.INFORMATION_MESSAGE);
    }
    
    // Search comments based on filters
    private void searchComments() {
        String studentId = txtStudentId.getText().trim();
        String moduleId = txtModuleId.getText().trim().toUpperCase();
        
        // Get student from dropdown if selected
        if (cmbStudent.getSelectedIndex() > 0 && studentId.isEmpty()) {
            String selected = (String) cmbStudent.getSelectedItem();
            if (!selected.equals("-- All Students --") && selected.contains(" - ")) {
                studentId = selected.split(" - ")[0].trim();
            }
        }
        
        // If studentId is empty but dropdown shows "-- All Students --", then show all
        boolean showAllStudents = studentId.isEmpty() && cmbStudent.getSelectedIndex() == 0;
        
        loadCommentsToTable(studentId, moduleId, showAllStudents);
    }
    
    // View all comments
    private void viewAllComments() {
        txtStudentId.setText("");
        txtModuleId.setText("");
        cmbStudent.setSelectedIndex(0);
        loadCommentsToTable("", "", true);
    }
    
    // Load comments into table
    private void loadCommentsToTable(String studentId, String moduleId, boolean showAllStudents) {
        // Clear existing table data
        tableModel.setRowCount(0);
        
        File commentsFile = new File("data_files/comments.txt");
        
        if (!commentsFile.exists()) {
            JOptionPane.showMessageDialog(this, 
                "No comments file found at: data_files/comments.txt\n" +
                "The file should contain: StudentID,LecturerID,ModuleID,Comment,date and time",
                "File Not Found", JOptionPane.WARNING_MESSAGE);
            updateStatusLabel(0);
            return;
        }
        
        try (BufferedReader reader = new BufferedReader(new FileReader(commentsFile))) {
            String line;
            int count = 0;
            boolean isFirstLine = true;
            
            // Get current lecturer's ID for filtering
            String currentLecturerId = lecturer.getUserId();
            
            // Get student names for display
            List<String[]> studentInfo = getStudentInfo();
            
            while ((line = reader.readLine()) != null) {
                // Skip header if exists
                if (isFirstLine && (line.startsWith("StudentID") || line.startsWith("StudentID,"))) {
                    isFirstLine = false;
                    continue;
                }
                isFirstLine = false;
                
                // Format: StudentID,LecturerID,ModuleID,Comment,date and time
                String[] parts = line.split(",", 5); // Split into max 5 parts to preserve date/time
                
                if (parts.length >= 5) {
                    String entryStudentId = parts[0].trim();
                    String entryLecturerId = parts[1].trim();
                    String entryModuleId = parts[2].trim();
                    String comment = parts[3].trim();
                    String dateTime = parts[4].trim();
                    
                    // Apply filters
                    boolean studentMatches = showAllStudents || 
                                           entryStudentId.equalsIgnoreCase(studentId);
                    boolean moduleMatches = moduleId.isEmpty() || 
                                           entryModuleId.equalsIgnoreCase(moduleId);
                    
                    // Only show comments from current lecturer
                    boolean lecturerMatches = entryLecturerId.equals(currentLecturerId);
                    
                    if (studentMatches && moduleMatches && lecturerMatches) {
                        count++;
                        
                        // Get student name if available
                        String studentName = "Unknown";
                        for (String[] info : studentInfo) {
                            if (info[0].equals(entryStudentId)) {
                                studentName = info[1];
                                break;
                            }
                        }
                        
                        // Truncate long comments for table display
                        String displayComment = comment;
                        if (displayComment.length() > 100) {
                            displayComment = displayComment.substring(0, 97) + "...";
                        }
                        
                        // Add row to table
                        tableModel.addRow(new Object[]{
                            String.valueOf(count),
                            entryStudentId,
                            studentName,
                            entryModuleId,
                            displayComment,
                            dateTime,
                            entryLecturerId
                        });
                    }
                }
            }
            
            if (count == 0) {
                String message = "No comments found";
                if (!showAllStudents && !studentId.isEmpty()) {
                    message += " for Student ID: " + studentId;
                }
                if (!moduleId.isEmpty()) {
                    message += " in Module: " + moduleId;
                }
                JOptionPane.showMessageDialog(this, message, "No Data", JOptionPane.INFORMATION_MESSAGE);
            }
            
            updateStatusLabel(count);
            
            // Log activity
            ActivityLogger.logActivity(lecturer, 
                "Viewed " + count + " student comments in table view" + 
                (studentId.isEmpty() ? "" : " for student " + studentId));
            
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, 
                "Error reading comments file: " + e.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // Get student ID and name mapping from users.txt
    private List<String[]> getStudentInfo() {
        List<String[]> studentInfo = new ArrayList<>();
        File file = new File("data_files/users.txt");
        
        if (!file.exists()) return studentInfo;
        
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            boolean isFirstLine = true;
            
            while ((line = br.readLine()) != null) {
                // Skip header
                if (isFirstLine && (line.startsWith("UserID") || line.startsWith("UserID"))) {
                    isFirstLine = false;
                    continue;
                }
                isFirstLine = false;
                
                String[] parts = line.split(",");
                if (parts.length >= 6 && parts[5].equals("Student")) {
                    studentInfo.add(new String[]{parts[0].trim(), parts[2].trim()});
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading student info: " + e.getMessage());
        }
        
        return studentInfo;
    }
    
    // Show full comment details for selected row
    private void showSelectedCommentDetails() {
        int selectedRow = commentsTable.getSelectedRow();
        if (selectedRow >= 0) {
            String studentId = (String) tableModel.getValueAt(selectedRow, 1);
            String studentName = (String) tableModel.getValueAt(selectedRow, 2);
            String moduleId = (String) tableModel.getValueAt(selectedRow, 3);
            String dateTime = (String) tableModel.getValueAt(selectedRow, 5);
            
            // Get full comment from file
            String fullComment = getFullComment(studentId, moduleId, dateTime);
            
            JTextArea textArea = new JTextArea(fullComment);
            textArea.setEditable(false);
            textArea.setFont(new Font("Arial", Font.PLAIN, 14));
            textArea.setLineWrap(true);
            textArea.setWrapStyleWord(true);
            textArea.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
            
            JScrollPane scrollPane = new JScrollPane(textArea);
            scrollPane.setPreferredSize(new Dimension(500, 200));
            
            JOptionPane.showMessageDialog(this, scrollPane, 
                "Full Comment for " + studentName + " (" + studentId + ")", 
                JOptionPane.INFORMATION_MESSAGE);
        }
    }
    
    // Get full comment from file
    private String getFullComment(String studentId, String moduleId, String dateTime) {
        File commentsFile = new File("data_files/comments.txt");
        if (!commentsFile.exists()) return "Comment not found.";
        
        try (BufferedReader reader = new BufferedReader(new FileReader(commentsFile))) {
            String line;
            boolean isFirstLine = true;
            
            while ((line = reader.readLine()) != null) {
                // Skip header
                if (isFirstLine && (line.startsWith("StudentID") || line.startsWith("StudentID,"))) {
                    isFirstLine = false;
                    continue;
                }
                isFirstLine = false;
                
                String[] parts = line.split(",", 5);
                if (parts.length >= 5) {
                    if (parts[0].trim().equals(studentId) && 
                        parts[2].trim().equals(moduleId) && 
                        parts[4].trim().equals(dateTime)) {
                        
                        return "Student: " + studentId + "\n" +
                               "Module: " + moduleId + "\n" +
                               "Date/Time: " + dateTime + "\n" +
                               "Lecturer: " + parts[1].trim() + "\n\n" +
                               "Comment:\n" + parts[3].trim();
                    }
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading comment: " + e.getMessage());
        }
        
        return "Comment details not found.";
    }
    
    // Export table to CSV file
    private void exportTableToCSV() {
        if (tableModel.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, 
                "No comments to export. Please load comments first.", 
                "No Data", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Export Comments Table");
        fileChooser.setSelectedFile(new File("student_comments_" + 
            LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss")) + ".csv"));
        
        int userSelection = fileChooser.showSaveDialog(this);
        
        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToSave = fileChooser.getSelectedFile();
            
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileToSave))) {
                // Write header
                for (int i = 0; i < tableModel.getColumnCount(); i++) {
                    writer.write(tableModel.getColumnName(i));
                    if (i < tableModel.getColumnCount() - 1) {
                        writer.write(",");
                    }
                }
                writer.newLine();
                
                // Write data
                for (int row = 0; row < tableModel.getRowCount(); row++) {
                    for (int col = 0; col < tableModel.getColumnCount(); col++) {
                        String value = tableModel.getValueAt(row, col).toString();
                        // Escape commas and quotes in CSV
                        if (value.contains(",") || value.contains("\"")) {
                            value = "\"" + value.replace("\"", "\"\"") + "\"";
                        }
                        writer.write(value);
                        if (col < tableModel.getColumnCount() - 1) {
                            writer.write(",");
                        }
                    }
                    writer.newLine();
                }
                
                // Add footer
                writer.newLine();
                writer.write("Exported by:," + lecturer.getUserId());
                writer.newLine();
                writer.write("Export date:," + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
                writer.newLine();
                writer.write("Total comments:," + tableModel.getRowCount());
                
                JOptionPane.showMessageDialog(this, 
                    "Table successfully exported to:\n" + fileToSave.getAbsolutePath(),
                    "Export Successful", JOptionPane.INFORMATION_MESSAGE);
                
                ActivityLogger.logActivity(lecturer, 
                    "Exported " + tableModel.getRowCount() + " comments to CSV: " + fileToSave.getName());
                
            } catch (IOException e) {
                JOptionPane.showMessageDialog(this, 
                    "Error exporting table: " + e.getMessage(),
                    "Export Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    // Clear table
    private void clearTable() {
        tableModel.setRowCount(0);
        updateStatusLabel(0);
        JOptionPane.showMessageDialog(this, 
            "Table cleared.", "Clear", JOptionPane.INFORMATION_MESSAGE);
    }
    
    // Update status label with count
    private void updateStatusLabel(int count) {
        for (Component comp : getContentPane().getComponents()) {
            if (comp instanceof JPanel) {
                for (Component child : ((JPanel) comp).getComponents()) {
                    if (child instanceof JLabel && "countLabel".equals(child.getName())) {
                        ((JLabel) child).setText("Total Comments: " + count);
                        return;
                    }
                }
            }
        }
    }
    
    // Custom renderer for comment column to handle text wrapping
    class TextAreaRenderer extends JTextArea implements javax.swing.table.TableCellRenderer {
        public TextAreaRenderer() {
            setLineWrap(true);
            setWrapStyleWord(true);
            setOpaque(true);
            setFont(new Font("Arial", Font.PLAIN, 12));
        }
        
        public Component getTableCellRendererComponent(JTable table, Object value,
                boolean isSelected, boolean hasFocus, int row, int column) {
            
            setText((value == null) ? "" : value.toString());
            
            if (isSelected) {
                setBackground(table.getSelectionBackground());
                setForeground(table.getSelectionForeground());
            } else {
                setBackground(table.getBackground());
                setForeground(table.getForeground());
            }
            
            // Adjust row height based on content
            int lineCount = getLineCount();
            int preferredHeight = lineCount * getRowHeight();
            
            if (preferredHeight != table.getRowHeight(row)) {
                table.setRowHeight(row, Math.max(preferredHeight, table.getRowHeight()));
            }
            
            return this;
        }
    }
}