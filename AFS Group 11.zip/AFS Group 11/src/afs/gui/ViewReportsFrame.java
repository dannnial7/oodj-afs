package afs.gui;

import afs.model.Lecturer;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class ViewReportsFrame extends JFrame {
    private Lecturer lecturer;
    private JTable reportsTable;
    private DefaultTableModel tableModel;
    private JComboBox<String> cmbReportType;
    private JLabel lblStatus;
    
    public ViewReportsFrame(Lecturer lecturer) {
        this.lecturer = lecturer;
        
        setTitle("View Reports - " + lecturer.getName());
        setSize(900, 700);
        setLocationRelativeTo(null);
        
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        // Title Panel
        JPanel titlePanel = new JPanel(new BorderLayout());
        titlePanel.setBackground(new Color(0, 102, 204));
        
        JLabel titleLabel = new JLabel("LECTURER REPORTS DASHBOARD");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        titlePanel.add(titleLabel, BorderLayout.CENTER);
        
        // Lecturer info label
        JLabel lecturerLabel = new JLabel("Lecturer: " + lecturer.getName() + " (" + lecturer.getUserId() + ")");
        lecturerLabel.setFont(new Font("Arial", Font.PLAIN, 12));
        lecturerLabel.setForeground(Color.WHITE);
        titlePanel.add(lecturerLabel, BorderLayout.SOUTH);
        
        mainPanel.add(titlePanel, BorderLayout.NORTH);
        
        // ===== CONTROL PANEL =====
        JPanel controlPanel = new JPanel(new GridBagLayout());
        controlPanel.setBorder(BorderFactory.createTitledBorder("Report Controls"));
        controlPanel.setBackground(new Color(240, 248, 255));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 10, 5, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        // Report Type Selection
        gbc.gridx = 0; gbc.gridy = 0;
        controlPanel.add(new JLabel("Report Type:"), gbc);
        
        gbc.gridx = 1;
        cmbReportType = new JComboBox<>(new String[]{
            "All Reports", 
            "Modules Report", 
            "Assessments Report", 
            "Marks Summary", 
            "Student Performance"
        });
        controlPanel.add(cmbReportType, gbc);
        
        // Generate Button
        gbc.gridx = 2;
        JButton btnGenerate = createStyledButton("Generate Report", new Color(0, 153, 76));
        btnGenerate.addActionListener(e -> generateReport());
        controlPanel.add(btnGenerate, gbc);
        
        // Refresh Button
        gbc.gridx = 3;
        JButton btnRefresh = createStyledButton("Refresh Data", new Color(0, 102, 204));
        btnRefresh.addActionListener(e -> refreshReport());
        controlPanel.add(btnRefresh, gbc);
        
        // Export Button
        gbc.gridx = 4;
        JButton btnExport = createStyledButton("Export to CSV", new Color(255, 153, 0));
        btnExport.addActionListener(e -> exportReport());
        controlPanel.add(btnExport, gbc);
        
        mainPanel.add(controlPanel, BorderLayout.NORTH);
        
        // ===== REPORTS TABLE =====
        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.setBorder(BorderFactory.createTitledBorder("Report Data"));
        
        // Create table model with dynamic columns
        String[] columns = {"Report Type", "Data Point", "Value", "Details", "Status"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Make table read-only
            }
            
            @Override
            public Class<?> getColumnClass(int columnIndex) {
                if (columnIndex == 4) { // Status column
                    return String.class;
                }
                return String.class;
            }
        };
        
        reportsTable = new JTable(tableModel);
        reportsTable.setRowHeight(30);
        reportsTable.setFont(new Font("Arial", Font.PLAIN, 12));
        reportsTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 13));
        reportsTable.getTableHeader().setBackground(new Color(220, 230, 255));
        reportsTable.getTableHeader().setReorderingAllowed(false);
        
        // Set column widths
        reportsTable.getColumnModel().getColumn(0).setPreferredWidth(120); // Report Type
        reportsTable.getColumnModel().getColumn(1).setPreferredWidth(150); // Data Point
        reportsTable.getColumnModel().getColumn(2).setPreferredWidth(100); // Value
        reportsTable.getColumnModel().getColumn(3).setPreferredWidth(300); // Details
        reportsTable.getColumnModel().getColumn(4).setPreferredWidth(80);  // Status
        
        // Add row sorter for sorting
        TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(tableModel);
        reportsTable.setRowSorter(sorter);
        
        JScrollPane tableScroll = new JScrollPane(reportsTable);
        tableScroll.setPreferredSize(new Dimension(850, 400));
        
        tablePanel.add(tableScroll, BorderLayout.CENTER);
        
        // ===== TABLE INFO PANEL =====
        JPanel tableInfoPanel = new JPanel(new BorderLayout());
        tableInfoPanel.setBackground(new Color(245, 245, 245));
        tableInfoPanel.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        
        lblStatus = new JLabel("Ready to generate reports. Select report type and click 'Generate Report'.");
        lblStatus.setFont(new Font("Arial", Font.PLAIN, 12));
        
        JLabel tableInfo = new JLabel("Sort: Click column headers | Filter: Right-click column headers");
        tableInfo.setFont(new Font("Arial", Font.ITALIC, 11));
        tableInfo.setForeground(Color.DARK_GRAY);
        
        tableInfoPanel.add(lblStatus, BorderLayout.WEST);
        tableInfoPanel.add(tableInfo, BorderLayout.EAST);
        
        tablePanel.add(tableInfoPanel, BorderLayout.SOUTH);
        
        mainPanel.add(tablePanel, BorderLayout.CENTER);
        
        // ===== SUMMARY PANEL =====
        JPanel summaryPanel = new JPanel(new GridLayout(1, 4, 10, 0));
        summaryPanel.setBorder(BorderFactory.createTitledBorder("Quick Summary"));
        summaryPanel.setBackground(Color.WHITE);
        
        // Summary cards
        JPanel cardModules = createSummaryCard("Modules", "0", new Color(0, 102, 204));
        JPanel cardAssessments = createSummaryCard("Assessments", "0", new Color(0, 153, 76));
        JPanel cardStudents = createSummaryCard("Students", "0", new Color(255, 153, 0));
        JPanel cardMarks = createSummaryCard("Avg Marks", "-", new Color(102, 0, 204));
        
        summaryPanel.add(cardModules);
        summaryPanel.add(cardAssessments);
        summaryPanel.add(cardStudents);
        summaryPanel.add(cardMarks);
        
        mainPanel.add(summaryPanel, BorderLayout.SOUTH);
        
        add(mainPanel);
        
        // Generate default report on startup
        SwingUtilities.invokeLater(() -> {
            generateReport();
            updateSummaryCards();
        });
    }
    
    // ===== HELPER METHODS =====
    
    private JButton createStyledButton(String text, Color color) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(color.brighter());
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(color);
            }
        });
        
        return button;
    }
    
    // Create summary card panel
    private JPanel createSummaryCard(String title, String value, Color color) {
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(color);
        card.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        
        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 14));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        JLabel valueLabel = new JLabel(value);
        valueLabel.setFont(new Font("Arial", Font.BOLD, 24));
        valueLabel.setForeground(Color.WHITE);
        valueLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        card.add(titleLabel);
        card.add(Box.createRigidArea(new Dimension(0, 5)));
        card.add(valueLabel);
        
        return card;
    }
    
    private void generateReport() {
        try {
            if (lecturer == null) {
                JOptionPane.showMessageDialog(this, "ERROR: Lecturer object is null!", 
                    "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            // Clear existing data
            tableModel.setRowCount(0);
            
            String reportType = (String) cmbReportType.getSelectedItem();
            String lecturerId = lecturer.getUserId();
            
            switch (reportType) {
                case "All Reports":
                    generateAllReports(lecturerId);
                    break;
                case "Modules Report":
                    generateModulesReport(lecturerId);
                    break;
                case "Assessments Report":
                    generateAssessmentsReport(lecturerId);
                    break;
                case "Marks Summary":
                    generateMarksSummary(lecturerId);
                    break;
                case "Student Performance":
                    generateStudentPerformanceReport(lecturerId);
                    break;
            }
            
            // Update status
            lblStatus.setText("Report generated: " + reportType + " | " + 
                tableModel.getRowCount() + " records found | " + 
                LocalDateTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")));
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, 
                "ERROR generating report: " + e.getMessage(), 
                "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }
    
    private void generateAllReports(String lecturerId) {
        generateModulesReport(lecturerId);
        generateAssessmentsReport(lecturerId);
        generateMarksSummary(lecturerId);
        generateStudentPerformanceReport(lecturerId);
    }
    
    private void generateModulesReport(String lecturerId) {
        File modulesFile = new File("data_files/modules.txt");
        if (!modulesFile.exists()) {
            addTableRow("Modules Report", "File Error", "0", 
                "modules.txt not found in data_files folder", "ERROR");
            return;
        }
        
        try (BufferedReader br = new BufferedReader(new FileReader(modulesFile))) {
            String line;
            int moduleCount = 0;
            boolean isFirstLine = true;
            
            while ((line = br.readLine()) != null) {
                if (isFirstLine && line.startsWith("ModuleID")) {
                    isFirstLine = false;
                    continue;
                }
                isFirstLine = false;
                
                String[] parts = line.split(",");
                if (parts.length >= 4) {
                    String moduleId = parts[0];
                    String moduleName = parts[1];
                    String assignedLecturer = parts[3];
                    
                    if (assignedLecturer.equals(lecturerId)) {
                        moduleCount++;
                        addTableRow("Modules Report", "Module", moduleId, 
                            moduleName, "ACTIVE");
                    }
                }
            }
            
            if (moduleCount == 0) {
                addTableRow("Modules Report", "No Modules", "0", 
                    "No modules assigned to lecturer " + lecturerId, "INFO");
            } else {
                addTableRow("Modules Report", "Total Modules", String.valueOf(moduleCount), 
                    "Summary: " + moduleCount + " modules assigned", "SUMMARY");
            }
            
        } catch (IOException e) {
            addTableRow("Modules Report", "Read Error", "0", 
                "Error reading modules.txt: " + e.getMessage(), "ERROR");
        }
    }
    
    private void generateAssessmentsReport(String lecturerId) {
        File assessmentsFile = new File("data_files/assessments.txt");
        if (!assessmentsFile.exists()) {
            addTableRow("Assessments Report", "File Error", "0", 
                "assessments.txt not found in data_files folder", "ERROR");
            return;
        }
        
        try (BufferedReader br = new BufferedReader(new FileReader(assessmentsFile))) {
            String line;
            int assessmentCount = 0;
            boolean isFirstLine = true;
            
            while ((line = br.readLine()) != null) {
                if (isFirstLine && line.startsWith("AssessmentID")) {
                    isFirstLine = false;
                    continue;
                }
                isFirstLine = false;
                
                String[] parts = line.split(",");
                if (parts.length >= 6) {
                    String assessmentId = parts[0];
                    String description = parts[2];
                    String creatorId = parts[5];
                    
                    if (creatorId.equals(lecturerId)) {
                        assessmentCount++;
                        String moduleId = parts.length > 1 ? parts[1] : "N/A";
                        addTableRow("Assessments Report", "Assessment", assessmentId, 
                            description + " (Module: " + moduleId + ")", "CREATED");
                    }
                }
            }
            
            if (assessmentCount == 0) {
                addTableRow("Assessments Report", "No Assessments", "0", 
                    "No assessments created by lecturer " + lecturerId, "INFO");
            } else {
                addTableRow("Assessments Report", "Total Assessments", String.valueOf(assessmentCount), 
                    "Summary: " + assessmentCount + " assessments created", "SUMMARY");
            }
            
        } catch (IOException e) {
            addTableRow("Assessments Report", "Read Error", "0", 
                "Error reading assessments.txt: " + e.getMessage(), "ERROR");
        }
    }
    
    private void generateMarksSummary(String lecturerId) {
        File marksFile = new File("data_files/results.txt");
        if (!marksFile.exists()) {
            addTableRow("Marks Summary", "File Error", "0", 
                "results.txt not found in data_files folder", "ERROR");
            return;
        }
        
        try (BufferedReader br = new BufferedReader(new FileReader(marksFile))) {
            String line;
            int marksCount = 0;
            int totalMarks = 0;
            boolean isFirstLine = true;
            
            while ((line = br.readLine()) != null) {
                if (isFirstLine && line.startsWith("StudentID")) {
                    isFirstLine = false;
                    continue;
                }
                isFirstLine = false;
                
                String[] parts = line.split(",");
                if (parts.length >= 7) {
                    String entryLecturerId = parts[6];
                    
                    if (entryLecturerId.equals(lecturerId)) {
                        marksCount++;
                        if (parts.length >= 4) {
                            try {
                                int marks = Integer.parseInt(parts[3]);
                                totalMarks += marks;
                            } catch (NumberFormatException e) {
                                // Ignore invalid marks
                            }
                        }
                    }
                }
            }
            
            if (marksCount == 0) {
                addTableRow("Marks Summary", "No Marks", "0", 
                    "No marks entered by lecturer " + lecturerId, "INFO");
            } else {
                double averageMarks = marksCount > 0 ? (double) totalMarks / marksCount : 0;
                
                addTableRow("Marks Summary", "Total Entries", String.valueOf(marksCount), 
                    "Number of marks entries", "INFO");
                addTableRow("Marks Summary", "Total Marks", String.valueOf(totalMarks), 
                    "Sum of all marks", "INFO");
                addTableRow("Marks Summary", "Average Marks", String.format("%.2f", averageMarks), 
                    "Average marks per entry", "SUMMARY");
            }
            
        } catch (IOException e) {
            addTableRow("Marks Summary", "Read Error", "0", 
                "Error reading results.txt: " + e.getMessage(), "ERROR");
        }
    }
    
    private void generateStudentPerformanceReport(String lecturerId) {
        File marksFile = new File("data_files/results.txt");
        if (!marksFile.exists()) {
            addTableRow("Student Performance", "File Error", "0", 
                "results.txt not found in data_files folder", "ERROR");
            return;
        }
        
        try (BufferedReader br = new BufferedReader(new FileReader(marksFile))) {
            String line;
            boolean isFirstLine = true;
            
            // Track student performance
            List<String[]> studentMarks = new ArrayList<>();
            
            while ((line = br.readLine()) != null) {
                if (isFirstLine && line.startsWith("StudentID")) {
                    isFirstLine = false;
                    continue;
                }
                isFirstLine = false;
                
                String[] parts = line.split(",");
                if (parts.length >= 7) {
                    String entryLecturerId = parts[6];
                    
                    if (entryLecturerId.equals(lecturerId)) {
                        String studentId = parts[0];
                        String assessmentId = parts[1];
                        String marksStr = parts[3];
                        String grade = parts.length > 4 ? parts[4] : "N/A";
                        
                        try {
                            int marks = Integer.parseInt(marksStr);
                            studentMarks.add(new String[]{studentId, assessmentId, marksStr, grade});
                            
                            addTableRow("Student Performance", studentId, marksStr, 
                                "Assessment: " + assessmentId + " | Grade: " + grade, 
                                marks >= 40 ? "PASS" : "FAIL");
                        } catch (NumberFormatException e) {
                            // Skip invalid marks
                        }
                    }
                }
            }
            
            if (studentMarks.isEmpty()) {
                addTableRow("Student Performance", "No Data", "0", 
                    "No student performance data found", "INFO");
            } else {
                addTableRow("Student Performance", "Students Assessed", 
                    String.valueOf(getUniqueStudents(studentMarks)), 
                    "Number of unique students assessed", "SUMMARY");
            }
            
        } catch (IOException e) {
            addTableRow("Student Performance", "Read Error", "0", 
                "Error reading results.txt: " + e.getMessage(), "ERROR");
        }
    }
    
    private int getUniqueStudents(List<String[]> studentMarks) {
        List<String> uniqueStudents = new ArrayList<>();
        for (String[] record : studentMarks) {
            if (!uniqueStudents.contains(record[0])) {
                uniqueStudents.add(record[0]);
            }
        }
        return uniqueStudents.size();
    }
    
    private void addTableRow(String reportType, String dataPoint, String value, 
                           String details, String status) {
        tableModel.addRow(new Object[]{reportType, dataPoint, value, details, status});
    }
    
    private void refreshReport() {
        generateReport();
        updateSummaryCards();
        JOptionPane.showMessageDialog(this, "Report data refreshed!", 
            "Refresh", JOptionPane.INFORMATION_MESSAGE);
    }
    
    private void updateSummaryCards() {
        try {
            String lecturerId = lecturer.getUserId();
            
            // Count modules
            int moduleCount = 0;
            File modulesFile = new File("data_files/modules.txt");
            if (modulesFile.exists()) {
                try (BufferedReader br = new BufferedReader(new FileReader(modulesFile))) {
                    String line;
                    boolean isFirstLine = true;
                    while ((line = br.readLine()) != null) {
                        if (isFirstLine && line.startsWith("ModuleID")) {
                            isFirstLine = false;
                            continue;
                        }
                        isFirstLine = false;
                        
                        String[] parts = line.split(",");
                        if (parts.length >= 4 && parts[3].equals(lecturerId)) {
                            moduleCount++;
                        }
                    }
                }
            }
            
            // Count assessments
            int assessmentCount = 0;
            File assessmentsFile = new File("data_files/assessments.txt");
            if (assessmentsFile.exists()) {
                try (BufferedReader br = new BufferedReader(new FileReader(assessmentsFile))) {
                    String line;
                    boolean isFirstLine = true;
                    while ((line = br.readLine()) != null) {
                        if (isFirstLine && line.startsWith("AssessmentID")) {
                            isFirstLine = false;
                            continue;
                        }
                        isFirstLine = false;
                        
                        String[] parts = line.split(",");
                        if (parts.length >= 6 && parts[5].equals(lecturerId)) {
                            assessmentCount++;
                        }
                    }
                }
            }
            
            // Count students
            int studentCount = getStudentCount();
            
            // Calculate average marks
            String avgMarks = calculateAverageMarks(lecturerId);
            
            // Update summary cards
            updateSummaryCard(0, moduleCount); // Modules card
            updateSummaryCard(1, assessmentCount); // Assessments card
            updateSummaryCard(2, studentCount); // Students card
            updateSummaryCard(3, avgMarks); // Avg Marks card
            
        } catch (Exception e) {
            System.err.println("Error updating summary cards: " + e.getMessage());
        }
    }
    
    private int getStudentCount() {
        File usersFile = new File("data_files/users.txt");
        int studentCount = 0;
        
        if (usersFile.exists()) {
            try (BufferedReader br = new BufferedReader(new FileReader(usersFile))) {
                String line;
                boolean isFirstLine = true;
                while ((line = br.readLine()) != null) {
                    if (isFirstLine && line.startsWith("UserID")) {
                        isFirstLine = false;
                        continue;
                    }
                    isFirstLine = false;
                    
                    String[] parts = line.split(",");
                    if (parts.length >= 6 && parts[5].equals("Student")) {
                        studentCount++;
                    }
                }
            } catch (IOException e) {
                System.err.println("Error counting students: " + e.getMessage());
            }
        }
        return studentCount;
    }
    
    private String calculateAverageMarks(String lecturerId) {
        File marksFile = new File("data_files/results.txt");
        int marksCount = 0;
        int totalMarks = 0;
        
        if (marksFile.exists()) {
            try (BufferedReader br = new BufferedReader(new FileReader(marksFile))) {
                String line;
                boolean isFirstLine = true;
                while ((line = br.readLine()) != null) {
                    if (isFirstLine && line.startsWith("StudentID")) {
                        isFirstLine = false;
                        continue;
                    }
                    isFirstLine = false;
                    
                    String[] parts = line.split(",");
                    if (parts.length >= 7 && parts[6].equals(lecturerId)) {
                        if (parts.length >= 4) {
                            try {
                                int marks = Integer.parseInt(parts[3]);
                                marksCount++;
                                totalMarks += marks;
                            } catch (NumberFormatException e) {
                                // Skip invalid marks
                            }
                        }
                    }
                }
            } catch (IOException e) {
                System.err.println("Error calculating average marks: " + e.getMessage());
            }
        }
        
        if (marksCount > 0) {
            return String.format("%.1f", (double) totalMarks / marksCount);
        }
        return "-";
    }
    
    private void updateSummaryCard(int cardIndex, Object value) {
        Container mainContainer = getContentPane();
        if (mainContainer instanceof JPanel) {
            for (Component comp : ((JPanel) mainContainer).getComponents()) {
                if (comp instanceof JPanel && "Quick Summary".equals(((JPanel) comp).getBorder().toString())) {
                    JPanel summaryPanel = (JPanel) comp;
                    if (summaryPanel.getComponentCount() > cardIndex) {
                        JPanel card = (JPanel) summaryPanel.getComponent(cardIndex);
                        if (card.getComponentCount() >= 2) {
                            JLabel valueLabel = (JLabel) card.getComponent(1);
                            valueLabel.setText(value.toString());
                        }
                    }
                }
            }
        }
    }
    
    private void exportReport() {
        if (tableModel.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, 
                "No report data to export. Please generate a report first.", 
                "No Data", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Export Report Table");
        fileChooser.setSelectedFile(new File("lecturer_report_" + 
            LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss")) + ".csv"));
        
        int userSelection = fileChooser.showSaveDialog(this);
        
        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToSave = fileChooser.getSelectedFile();
            
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileToSave))) {
                // Write header
                for (int i = 0; i < tableModel.getColumnCount(); i++) {
                    writer.write(tableModel.getColumnName(i));
                    if (i < tableModel.getColumnCount() - 1) {
                        writer.write(",");
                    }
                }
                writer.newLine();
                
                // Write data
                for (int row = 0; row < tableModel.getRowCount(); row++) {
                    for (int col = 0; col < tableModel.getColumnCount(); col++) {
                        Object value = tableModel.getValueAt(row, col);
                        String valueStr = (value != null) ? value.toString() : "";
                        
                        // Escape commas and quotes in CSV
                        if (valueStr.contains(",") || valueStr.contains("\"")) {
                            valueStr = "\"" + valueStr.replace("\"", "\"\"") + "\"";
                        }
                        writer.write(valueStr);
                        
                        if (col < tableModel.getColumnCount() - 1) {
                            writer.write(",");
                        }
                    }
                    writer.newLine();
                }
                
                // Add footer with metadata
                writer.newLine();
                writer.write("Report generated by:," + lecturer.getName() + " (" + lecturer.getUserId() + ")");
                writer.newLine();
                writer.write("Report type:," + cmbReportType.getSelectedItem());
                writer.newLine();
                writer.write("Export date:," + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
                writer.newLine();
                writer.write("Total records:," + tableModel.getRowCount());
                
                JOptionPane.showMessageDialog(this, 
                    "Report successfully exported to:\n" + fileToSave.getAbsolutePath(),
                    "Export Successful", JOptionPane.INFORMATION_MESSAGE);
                
            } catch (IOException e) {
                JOptionPane.showMessageDialog(this, 
                    "Error exporting report: " + e.getMessage(),
                    "Export Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}