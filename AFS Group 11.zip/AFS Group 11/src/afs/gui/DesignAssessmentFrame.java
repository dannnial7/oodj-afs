package afs.gui;

import afs.model.Lecturer;
import afs.model.Assessment;
import afs.data.FileHandler;
import javax.swing.*;
import java.awt.*;
import java.util.List;
import afs.utils.ActivityLogger;

public class DesignAssessmentFrame extends JFrame {
    private Lecturer lecturer;
    private JComboBox<String> cmbModule;
    private JTextField txtDescription, txtMaxMarks, txtDueDate;
    
    public DesignAssessmentFrame(Lecturer lecturer) {
        this.lecturer = lecturer;
        
        setTitle("Design Assessment");
        setSize(600, 550);
        setLocationRelativeTo(null);
        
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        
        // Title Panel
        JPanel titlePanel = new JPanel();
        titlePanel.setBackground(new Color(0, 102, 204));
        JLabel titleLabel = new JLabel("DESIGN NEW ASSESSMENT");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setForeground(Color.WHITE);
        titlePanel.add(titleLabel);
        mainPanel.add(titlePanel, BorderLayout.NORTH);
        
        // Form Panel
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createTitledBorder("Assessment Details"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        // Module Selection
        gbc.gridx = 0; gbc.gridy = 0;
        JLabel lblModule = new JLabel("Select Module:");
        lblModule.setFont(new Font("Arial", Font.BOLD, 14));
        formPanel.add(lblModule, gbc);
        
        gbc.gridx = 1;
        cmbModule = new JComboBox<>();
        cmbModule.setFont(new Font("Arial", Font.PLAIN, 14));
        loadModules();
        formPanel.add(cmbModule, gbc);
        
        // Description
        gbc.gridx = 0; gbc.gridy = 1;
        JLabel lblDesc = new JLabel("Description:");
        lblDesc.setFont(new Font("Arial", Font.BOLD, 14));
        formPanel.add(lblDesc, gbc);
        
        gbc.gridx = 1;
        txtDescription = new JTextField(20);
        txtDescription.setFont(new Font("Arial", Font.PLAIN, 14));
        formPanel.add(txtDescription, gbc);
        
        // Max Marks
        gbc.gridx = 0; gbc.gridy = 2;
        JLabel lblMarks = new JLabel("Maximum Marks:");
        lblMarks.setFont(new Font("Arial", Font.BOLD, 14));
        formPanel.add(lblMarks, gbc);
        
        gbc.gridx = 1;
        txtMaxMarks = new JTextField(10);
        txtMaxMarks.setFont(new Font("Arial", Font.PLAIN, 14));
        formPanel.add(txtMaxMarks, gbc);
        
        // Due Date
        gbc.gridx = 0; gbc.gridy = 3;
        JLabel lblDueDate = new JLabel("Due Date (YYYY-MM-DD):");
        lblDueDate.setFont(new Font("Arial", Font.BOLD, 14));
        formPanel.add(lblDueDate, gbc);
        
        gbc.gridx = 1;
        txtDueDate = new JTextField(10);
        txtDueDate.setFont(new Font("Arial", Font.PLAIN, 14));
        formPanel.add(txtDueDate, gbc);
        
        // Info Panel
        gbc.gridx = 0; gbc.gridy = 4; gbc.gridwidth = 2;
        JPanel infoPanel = new JPanel();
        infoPanel.setBackground(new Color(240, 248, 255));
        infoPanel.setBorder(BorderFactory.createTitledBorder("Instructions"));
        JLabel infoLabel = new JLabel("<html><div style='width: 450px;'>" +
            "<b>Steps to Design Assessment:</b><br>" +
            "1. Select the module for this assessment<br>" +
            "2. Enter a clear description of the assessment<br>" +
            "3. Set the maximum marks available (e.g., 100)<br>" +
            "4. Specify the due date in YYYY-MM-DD format<br>" +
            "5. Click 'Design Assessment' to create it<br><br>" +
            "<b>Note:</b> Assessment will be saved to assessments.txt" +
            "</div></html>");
        infoLabel.setFont(new Font("Arial", Font.PLAIN, 12));
        infoPanel.add(infoLabel);
        formPanel.add(infoPanel, gbc);
        
        mainPanel.add(formPanel, BorderLayout.CENTER);
        
        // Button Panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        
        JButton btnDesign = createStyledButton("Design Assessment", new Color(0, 153, 76));
        btnDesign.addActionListener(e -> designAssessment());
        
        JButton btnClear = createStyledButton("Clear Form", new Color(255, 153, 0));
        btnClear.addActionListener(e -> clearForm());
        
        JButton btnCancel = createStyledButton("Cancel", new Color(204, 0, 0));
        btnCancel.addActionListener(e -> dispose());
        
        JButton btnViewAssessments = createStyledButton("View All Assessments", new Color(102, 0, 204));
        btnViewAssessments.addActionListener(e -> viewAllAssessments());
        
        JButton btnRefresh = createStyledButton("Refresh Modules", new Color(0, 102, 204));
        btnRefresh.addActionListener(e -> refreshModules());
        
        buttonPanel.add(btnDesign);
        buttonPanel.add(btnClear);
        buttonPanel.add(btnRefresh);
        buttonPanel.add(btnViewAssessments);
        buttonPanel.add(btnCancel);
        
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);
        
        add(mainPanel);
    }
    
    // ===== HELPER METHODS =====
    
    private JButton createStyledButton(String text, Color color) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(color.brighter());
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(color);
            }
        });
        
        return button;
    }
    
    private void loadModules() {
        cmbModule.removeAllItems();
        cmbModule.addItem("-- Select Module --");
        
        List<afs.model.Module> modules = FileHandler.loadLecturerModules(lecturer.getUserId());
        for (afs.model.Module module : modules) {
            cmbModule.addItem(module.getModuleId() + " - " + module.getModuleName());
        }
        
        if (cmbModule.getItemCount() == 1) { // Only has "-- Select Module --"
            cmbModule.addItem("No modules assigned - Contact Academic Leader");
        }
    }
    
    private void refreshModules() {
        loadModules();
        JOptionPane.showMessageDialog(this, 
            "Module list refreshed!", 
            "Refresh Complete", JOptionPane.INFORMATION_MESSAGE);
    }
    
    private void clearForm() {
        txtDescription.setText("");
        txtMaxMarks.setText("");
        txtDueDate.setText("");
        cmbModule.setSelectedIndex(0);
    }
    
    private void designAssessment() {
        if (cmbModule.getSelectedIndex() == 0) {
            JOptionPane.showMessageDialog(this, 
                "Please select a module!", 
                "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        try {
            String selected = (String) cmbModule.getSelectedItem();
            String moduleId = selected.split(" - ")[0];
            String description = txtDescription.getText().trim();
            String maxMarksStr = txtMaxMarks.getText().trim();
            String dueDate = txtDueDate.getText().trim();
            
            // Validation
            if (description.isEmpty()) {
                JOptionPane.showMessageDialog(this, 
                    "Please enter assessment description!", 
                    "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            if (maxMarksStr.isEmpty()) {
                JOptionPane.showMessageDialog(this, 
                    "Please enter maximum marks!", 
                    "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            if (dueDate.isEmpty()) {
                JOptionPane.showMessageDialog(this, 
                    "Please enter due date!", 
                    "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            int maxMarks = Integer.parseInt(maxMarksStr);
            if (maxMarks <= 0 || maxMarks > 1000) {
                JOptionPane.showMessageDialog(this, 
                    "Maximum marks should be between 1 and 1000!", 
                    "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            // Date validation (basic)
            if (!dueDate.matches("\\d{4}-\\d{2}-\\d{2}")) {
                JOptionPane.showMessageDialog(this, 
                    "Please enter date in YYYY-MM-DD format!", 
                    "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            // Confirm before creating
            int confirm = JOptionPane.showConfirmDialog(this,
                "<html><b>Confirm Assessment Creation:</b><br>" +
                "Module: " + moduleId + "<br>" +
                "Description: " + description + "<br>" +
                "Max Marks: " + maxMarks + "<br>" +
                "Due Date: " + dueDate +
                "</html>",
                "Confirm Assessment", JOptionPane.YES_NO_OPTION);
            
            if (confirm != JOptionPane.YES_OPTION) {
                return;
            }
            
            // Create assessment using lecturer's method
            String assessmentData = lecturer.designAssessment(moduleId, description, maxMarks, dueDate);
            String[] parts = assessmentData.split(",");
            
            // Create Assessment object
            Assessment assessment = new Assessment(
                parts[0], // assessmentId
                parts[1], // moduleId
                parts[2], // description
                Integer.parseInt(parts[3]), // maxMarks
                parts[4], // dueDate
                parts[5]  // createdBy (lecturerId)
            );
            
            // Save to file
            FileHandler.saveAssessment(assessment);
            
            ActivityLogger.logActivity(lecturer, "Designed assessment: " + description + " (ID: " + assessment.getAssessmentId() + ")");
            
            JOptionPane.showMessageDialog(this, 
                "<html><div style='text-align: center;'>" +
                "<h3 style='color: green;'>✓ Assessment Designed Successfully!</h3>" +
                "<b>Assessment ID:</b> " + parts[0] + "<br>" +
                "<b>Module:</b> " + moduleId + "<br>" +
                "<b>Description:</b> " + description + "<br>" +
                "<b>Max Marks:</b> " + maxMarks + "<br>" +
                "<b>Due Date:</b> " + dueDate +
                "</div></html>", 
                "Success", JOptionPane.INFORMATION_MESSAGE);
            
            clearForm();
            
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, 
                "Please enter valid marks (numbers only)!", 
                "Error", JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, 
                "Error: " + e.getMessage(), 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void viewAllAssessments() {
    java.io.File assessmentFile = new java.io.File("data_files/assessments.txt");
    if (!assessmentFile.exists()) {
        JOptionPane.showMessageDialog(this, 
            "<html><div style='text-align: center;'>" +
            "<h3>No Assessments Yet</h3>" +
            "No assessments have been created.<br>" +
            "Design assessments to create the assessments.txt file." +
            "</div></html>", 
            "No Data", JOptionPane.INFORMATION_MESSAGE);
        return;
    }
    
    try (java.io.BufferedReader reader = new java.io.BufferedReader(new java.io.FileReader(assessmentFile))) {
        StringBuilder allAssessments = new StringBuilder();
        allAssessments.append("═══════════════════════════════════════\n");
        allAssessments.append("        MY ASSESSMENTS CREATED\n");
        allAssessments.append("═══════════════════════════════════════\n\n");
        
        String line;
        int count = 0;
        boolean isFirstLine = true;
        
        while ((line = reader.readLine()) != null) {
            // Skip header if exists
            if (isFirstLine && (line.startsWith("AssessmentID") || line.startsWith("assessmentId"))) {
                isFirstLine = false;
                continue;
            }
            isFirstLine = false;
            
            String[] parts = line.split(",");
            if (parts.length >= 6) {
                // Only show assessments created by the current lecturer
                String createdBy = parts[5];
                if (createdBy.equals(lecturer.getUserId())) {
                    count++;
                    allAssessments.append("Assessment #").append(count).append(":\n");
                    allAssessments.append("  ID: ").append(parts[0]).append("\n");
                    allAssessments.append("  Module: ").append(parts[1]).append("\n");
                    allAssessments.append("  Description: ").append(parts[2]).append("\n");
                    allAssessments.append("  Max Marks: ").append(parts[3]).append("\n");
                    allAssessments.append("  Due Date: ").append(parts[4]).append("\n");
                    allAssessments.append("  Created By: ").append(parts[5]).append("\n");
                    allAssessments.append("─────────────────────────────────────\n");
                }
            }
        }
        
        if (count == 0) {
            allAssessments.append("No assessments found for your account.\n");
            allAssessments.append("Click 'Design Assessment' to create your first assessment.\n");
        }
        
        allAssessments.append("\n═══════════════════════════════════════\n");
        allAssessments.append("Total assessments: ").append(count).append("\n");
        allAssessments.append("═══════════════════════════════════════\n");
        
        // Display in a dialog
        JTextArea textArea = new JTextArea(allAssessments.toString());
        textArea.setEditable(false);
        textArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(600, 400));
        
        JOptionPane.showMessageDialog(this, scrollPane, "My Assessments", JOptionPane.INFORMATION_MESSAGE);
        
    } catch (java.io.IOException e) {
        JOptionPane.showMessageDialog(this, 
            "Error reading assessments file: " + e.getMessage(), 
            "Error", JOptionPane.ERROR_MESSAGE);
    }
}
}