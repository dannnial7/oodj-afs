package afs.gui;

import afs.model.Lecturer;
import afs.data.FileHandler;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;
import java.util.ArrayList;
import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class LecturerDashboard extends JFrame {
    private Lecturer lecturer;
    private JLabel notificationBadge;
    private List<String> recentActivities;
    private JTable infoTable, modulesTable;
    private JTextArea activitiesArea;
    private Timer refreshTimer;
    
    public LecturerDashboard(Lecturer lecturer) {
        this.lecturer = lecturer;
        this.recentActivities = new ArrayList<>();
        loadRecentActivities(); // Load existing activities
        
        setTitle("AFS - Lecturer Dashboard");
        setSize(1000, 750);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        
        // Main Panel with BorderLayout
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(Color.WHITE);
        
        // ===== TOP PANEL: Header + Logo + Notification =====
        JPanel topPanel = new JPanel(new BorderLayout(10, 0));
        topPanel.setBackground(new Color(0, 102, 204));
        topPanel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));

        // Left side: Logo + Welcome
        JPanel leftHeaderPanel = new JPanel(new BorderLayout(10, 0));
        leftHeaderPanel.setBackground(new Color(0, 102, 204));

        // ========== FIXED LOGO LOADING ==========
        // Logo with resizing
        JLabel logoLabel;
        try {
            // Load image from classpath (same package as this class)
            java.net.URL imageURL = LecturerDashboard.class.getResource("university-logo.png");
            
            if (imageURL != null) {
                ImageIcon originalIcon = new ImageIcon(imageURL);
                // Scale logo to fit nicely
                Image scaledImage = originalIcon.getImage().getScaledInstance(200, 80, Image.SCALE_SMOOTH);
                logoLabel = new JLabel(new ImageIcon(scaledImage));
                logoLabel.setToolTipText("University Logo");
            } else {
                // If not found as resource, try absolute path
                File logoFile = new File("university-logo.png");
                if (logoFile.exists()) {
                    ImageIcon originalIcon = new ImageIcon(logoFile.getAbsolutePath());
                    Image scaledImage = originalIcon.getImage().getScaledInstance(200, 80, Image.SCALE_SMOOTH);
                    logoLabel = new JLabel(new ImageIcon(scaledImage));
                    logoLabel.setToolTipText("University Logo");
                } else {
                    throw new Exception("Logo file not found");
                }
            }
        } catch (Exception e) {
            // Fallback if logo not found
            logoLabel = new JLabel("🏛️");
            logoLabel.setFont(new Font("Arial", Font.PLAIN, 36));
            logoLabel.setForeground(Color.WHITE);
            logoLabel.setToolTipText("University Logo (Fallback)");
        }
        logoLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 10));
        // ========== END FIXED LOGO LOADING ==========

        // Welcome text with dashboard summary
        JPanel welcomeTextPanel = new JPanel();
        welcomeTextPanel.setLayout(new BoxLayout(welcomeTextPanel, BoxLayout.Y_AXIS));
        welcomeTextPanel.setBackground(new Color(0, 102, 204));

        JLabel welcomeLabel = new JLabel("Welcome, " + lecturer.getName() + "!");
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 28));
        welcomeLabel.setForeground(Color.WHITE);
        welcomeLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel dashboardLabel = new JLabel("Dashboard Summary");
        dashboardLabel.setFont(new Font("Arial", Font.BOLD, 16));
        dashboardLabel.setForeground(new Color(200, 220, 255));
        dashboardLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        welcomeTextPanel.add(welcomeLabel);
        welcomeTextPanel.add(Box.createRigidArea(new Dimension(0, 5)));
        welcomeTextPanel.add(dashboardLabel);

        // Add logo and welcome text to left panel
        leftHeaderPanel.add(logoLabel, BorderLayout.WEST);
        leftHeaderPanel.add(welcomeTextPanel, BorderLayout.CENTER);

        // Right side: Notification button
        JPanel rightHeaderPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        rightHeaderPanel.setBackground(new Color(0, 102, 204));

        // Notification Button with Badge
        JButton btnNotifications = new JButton("🔔 Notifications");
        btnNotifications.setFont(new Font("Arial", Font.BOLD, 14));
        btnNotifications.setBackground(new Color(255, 204, 0));
        btnNotifications.setForeground(Color.BLACK);
        btnNotifications.setFocusPainted(false);
        btnNotifications.setBorder(BorderFactory.createEmptyBorder(8, 15, 8, 15));
        btnNotifications.addActionListener(e -> showNotifications());

        // Notification badge
        notificationBadge = new JLabel("0");
        notificationBadge.setFont(new Font("Arial", Font.BOLD, 10));
        notificationBadge.setForeground(Color.WHITE);
        notificationBadge.setBackground(Color.RED);
        notificationBadge.setOpaque(true);
        notificationBadge.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Color.WHITE, 1),
            BorderFactory.createEmptyBorder(2, 6, 2, 6)
        ));
        notificationBadge.setVisible(false);

        // Create layered panel for badge overlay
        JLayeredPane layeredPane = new JLayeredPane();
        layeredPane.setPreferredSize(new Dimension(150, 50));
        layeredPane.setBackground(new Color(0, 102, 204));

        btnNotifications.setBounds(0, 0, 140, 40);
        notificationBadge.setBounds(120, 5, 25, 20);

        layeredPane.add(btnNotifications, JLayeredPane.DEFAULT_LAYER);
        layeredPane.add(notificationBadge, JLayeredPane.PALETTE_LAYER);

        rightHeaderPanel.add(layeredPane);

        // Add both panels to topPanel
        topPanel.add(leftHeaderPanel, BorderLayout.WEST);
        topPanel.add(rightHeaderPanel, BorderLayout.EAST);

        // ===== CENTER PANEL: Dashboard Content =====
        JPanel centerPanel = new JPanel(new GridLayout(1, 2, 20, 0));
        centerPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        centerPanel.setBackground(Color.WHITE);
        
        // ===== LEFT PANEL: Tables =====
        JPanel leftPanel = new JPanel();
        leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.Y_AXIS));
        leftPanel.setBorder(BorderFactory.createTitledBorder("Lecturer Information"));

        // Lecturer Information Table
        JPanel infoTablePanel = new JPanel(new BorderLayout());
        infoTablePanel.setBorder(BorderFactory.createTitledBorder("Personal Details"));

        String[] infoColumns = {"Field", "Details"};

        // Get academic leader information
        String academicLeaderName = getAcademicLeaderName(lecturer.getUserId());

        Object[][] infoData = {
            {"ID", lecturer.getUserId()},
            {"Name", lecturer.getName()},
            {"Email", lecturer.getEmail()},
            {"Contact", lecturer.getContactNum()},
            {"Role", lecturer.getRole()},
            {"Academic Leader", academicLeaderName}  // Added this row
        };

DefaultTableModel infoModel = new DefaultTableModel(infoData, infoColumns) {
    @Override
    public boolean isCellEditable(int row, int column) {
        return false; // Make table non-editable
    }
};
        
        infoTable = new JTable(infoModel);
        infoTable.setRowHeight(35);
        infoTable.setFont(new Font("Arial", Font.PLAIN, 14));
        infoTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 14));
        infoTable.getTableHeader().setBackground(new Color(220, 230, 255));
        
        JScrollPane infoScroll = new JScrollPane(infoTable);
        infoScroll.setPreferredSize(new Dimension(400, 230));
        infoTablePanel.add(infoScroll, BorderLayout.CENTER);
        
        // Teaching Modules Table
        JPanel modulesTablePanel = new JPanel(new BorderLayout());
        modulesTablePanel.setBorder(BorderFactory.createTitledBorder("Teaching Modules"));
        
        String[] moduleColumns = {"Module ID", "Module Name", "Actions"};
        DefaultTableModel modulesModel = new DefaultTableModel(moduleColumns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 2; // Only Actions column is editable (for buttons)
            }
        };
        
        // Load modules into table
        List<afs.model.Module> modules = FileHandler.loadLecturerModules(lecturer.getUserId());
        for (afs.model.Module module : modules) {
            modulesModel.addRow(new Object[]{
                module.getModuleId(),
                module.getModuleName(),
                "View Details"
            });
        }
        
        modulesTable = new JTable(modulesModel);
        modulesTable.setRowHeight(30);
        modulesTable.setFont(new Font("Arial", Font.PLAIN, 14));
        modulesTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 14));
        modulesTable.getTableHeader().setBackground(new Color(220, 230, 255));
        
        // Add button renderer for Actions column
        modulesTable.getColumnModel().getColumn(2).setCellRenderer(new ButtonRenderer());
        modulesTable.getColumnModel().getColumn(2).setCellEditor(new ButtonEditor(new JCheckBox()));
        
        JScrollPane modulesScroll = new JScrollPane(modulesTable);
        modulesScroll.setPreferredSize(new Dimension(400, 200));
        modulesTablePanel.add(modulesScroll, BorderLayout.CENTER);
        
        leftPanel.add(infoTablePanel);
        leftPanel.add(Box.createRigidArea(new Dimension(0, 15)));
        leftPanel.add(modulesTablePanel);
        
        // ===== RIGHT PANEL: Recent Activities =====
        JPanel rightPanel = new JPanel(new BorderLayout());
        rightPanel.setBorder(BorderFactory.createTitledBorder("Live Activities"));
        
        // Activities Header with Refresh button
        JPanel activitiesHeader = new JPanel(new BorderLayout());
        activitiesHeader.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));
        
        JLabel activitiesTitle = new JLabel("Recent Activities");
        activitiesTitle.setFont(new Font("Arial", Font.BOLD, 16));
        
        JButton btnRefreshActivities = new JButton("🔄 Refresh");
        btnRefreshActivities.setFont(new Font("Arial", Font.PLAIN, 12));
        btnRefreshActivities.addActionListener(e -> refreshActivities());
        
        activitiesHeader.add(activitiesTitle, BorderLayout.WEST);
        activitiesHeader.add(btnRefreshActivities, BorderLayout.EAST);
        
        // Activities Text Area
        activitiesArea = new JTextArea();
        activitiesArea.setEditable(false);
        activitiesArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        activitiesArea.setBackground(new Color(245, 245, 245));
        updateActivitiesDisplay();
        
        JScrollPane activitiesScroll = new JScrollPane(activitiesArea);
        activitiesScroll.setPreferredSize(new Dimension(400, 400));
        
        // Add New Activity Button
        JButton btnAddActivity = new JButton("➕ Add New Activity");
        btnAddActivity.setFont(new Font("Arial", Font.BOLD, 14));
        btnAddActivity.setBackground(new Color(0, 153, 76));
        btnAddActivity.setForeground(Color.WHITE);
        btnAddActivity.addActionListener(e -> addNewActivity());
        
        rightPanel.add(activitiesHeader, BorderLayout.NORTH);
        rightPanel.add(activitiesScroll, BorderLayout.CENTER);
        rightPanel.add(btnAddActivity, BorderLayout.SOUTH);
        
        centerPanel.add(leftPanel);
        centerPanel.add(rightPanel);
        
        // ===== BOTTOM PANEL: Quick Actions =====
        JPanel bottomPanel = new JPanel(new GridLayout(2, 3, 15, 15));
        bottomPanel.setBorder(BorderFactory.createEmptyBorder(20, 50, 20, 50));
        bottomPanel.setBackground(Color.WHITE);

        JButton btnEditProfile = createDashboardButton("Edit Profile", new Color(0, 102, 204));
        JButton btnDesignAssessment = createDashboardButton("Design Assessment", new Color(0, 153, 76));
        JButton btnEnterMarks = createDashboardButton("Enter Marks", new Color(255, 153, 0));
        JButton btnViewStudentComments = createDashboardButton("View Student Comments", new Color(204, 0, 0)); // FIXED
        JButton btnViewReports = createDashboardButton("View Reports", new Color(102, 0, 204));
        JButton btnLogout = createDashboardButton("Logout", new Color(128, 128, 128));

        // Button Actions
        btnEditProfile.addActionListener(e -> editProfile());
        btnDesignAssessment.addActionListener(e -> new DesignAssessmentFrame(lecturer).setVisible(true));
        btnEnterMarks.addActionListener(e -> new EnterMarksFrame(lecturer).setVisible(true));
        btnViewStudentComments.addActionListener(e -> new ViewStudentCommentsFrame(lecturer).setVisible(true)); // FIXED
        btnViewReports.addActionListener(e -> {
            String report = lecturer.viewReports();
            JTextArea textArea = new JTextArea(report);
            textArea.setEditable(false);
            textArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
            JScrollPane scrollPane = new JScrollPane(textArea);
            scrollPane.setPreferredSize(new Dimension(500, 400));
            JOptionPane.showMessageDialog(this, scrollPane, "Lecturer Report", JOptionPane.INFORMATION_MESSAGE);
        });
        btnLogout.addActionListener(e -> logout());

        bottomPanel.add(btnEditProfile);
        bottomPanel.add(btnDesignAssessment);
        bottomPanel.add(btnEnterMarks);
        bottomPanel.add(btnViewStudentComments); // FIXED
        bottomPanel.add(btnViewReports);
        bottomPanel.add(btnLogout);
        
        // ===== ASSEMBLE MAIN PANEL =====
        mainPanel.add(topPanel, BorderLayout.NORTH);
        mainPanel.add(centerPanel, BorderLayout.CENTER);
        mainPanel.add(bottomPanel, BorderLayout.SOUTH);
        
        add(mainPanel);
        
        // Initial notification update
        updateNotificationBadge();
    }
    
    // ===== HELPER METHODS =====
    
    // Helper method to get academic leader name
    private String getAcademicLeaderName(String lecturerId) {
        String academicLeaderName = "Not Assigned";

        try {
            // First: Find academic leader ID from leader_assignments.txt
            File leaderFile = new File("data_files/leader_assignments.txt");
            if (!leaderFile.exists()) {
                return "Leader file not found";
            }

            String academicLeaderId = null;
            try (BufferedReader br = new BufferedReader(new FileReader(leaderFile))) {
                String line;
                boolean isFirstLine = true;
                while ((line = br.readLine()) != null) {
                    // Skip header if exists
                    if (isFirstLine && line.startsWith("AcademicLeaderID")) {
                        isFirstLine = false;
                        continue;
                    }
                    isFirstLine = false;

                    String[] parts = line.split(",");
                    if (parts.length >= 2 && parts[1].equals(lecturerId)) {
                        academicLeaderId = parts[0].trim();
                        break;
                    }
                }
            }

            // If no academic leader found
            if (academicLeaderId == null) {
                return "Not Assigned";
            }

            // Second: Get academic leader name from users.txt
            File usersFile = new File("data_files/users.txt");
            if (!usersFile.exists()) {
                return "Users file not found";
            }

            try (BufferedReader br = new BufferedReader(new FileReader(usersFile))) {
                String line;
                boolean isFirstLine = true;
                while ((line = br.readLine()) != null) {
                    // Skip header if exists
                    if (isFirstLine && (line.startsWith("UserID") || line.startsWith("UserID,"))) {
                        isFirstLine = false;
                        continue;
                    }
                    isFirstLine = false;

                    String[] parts = line.split(",");
                    if (parts.length >= 6 && parts[0].equals(academicLeaderId)) {
                        // Found the academic leader - get their name
                        if (parts.length >= 3) {
                            academicLeaderName = parts[2].trim() + " (" + academicLeaderId + ")";
                        } else {
                            academicLeaderName = academicLeaderId;
                        }
                        break;
                    }
                }
            }

        } catch (IOException e) {
            System.err.println("Error reading academic leader data: " + e.getMessage());
            academicLeaderName = "Error: " + e.getMessage();
        }

        return academicLeaderName;
    }
    
    private JButton createDashboardButton(String text, Color color) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(12, 20, 12, 20));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(color.brighter());
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(color);
            }
        });
        
        return button;
    }
    
    // Load recent activities from file
    private void loadRecentActivities() {
        recentActivities.clear();
        
        // Load from activities file if exists
        File activitiesFile = new File("data_files/activities_" + lecturer.getUserId() + ".txt");
        if (activitiesFile.exists()) {
            try (BufferedReader reader = new BufferedReader(new FileReader(activitiesFile))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    recentActivities.add(0, line); // Add at beginning (newest first)
                }
            } catch (IOException e) {
                System.err.println("Error loading activities: " + e.getMessage());
            }
        }
        
        // Add some default activities if empty
        if (recentActivities.isEmpty()) {
            recentActivities.add(getCurrentTime() + " - Dashboard accessed");
            recentActivities.add(getCurrentTime() + " - Welcome to AFS System");
        }
    }
    
    private String getCurrentTime() {
        return LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
    }
    
    private void updateActivitiesDisplay() {
        StringBuilder sb = new StringBuilder();
        int count = 0;
        for (String activity : recentActivities) {
            sb.append("• ").append(activity).append("\n");
            if (++count >= 10) break; // Show only last 10 activities
        }
        activitiesArea.setText(sb.toString());
    }
    
    private void refreshActivities() {
        loadRecentActivities();
        updateActivitiesDisplay();
        JOptionPane.showMessageDialog(this, "Activities refreshed!", "Refresh", 
            JOptionPane.INFORMATION_MESSAGE);
    }
    
    private void addNewActivity() {
        String newActivity = JOptionPane.showInputDialog(this, 
            "Enter new activity:", "Add Activity", JOptionPane.PLAIN_MESSAGE);
        
        if (newActivity != null && !newActivity.trim().isEmpty()) {
            String activityWithTime = getCurrentTime() + " - " + newActivity.trim();
            recentActivities.add(0, activityWithTime); // Add at beginning
            
            // Save to file
            saveActivitiesToFile();
            
            updateActivitiesDisplay();
            updateNotificationBadge();
            JOptionPane.showMessageDialog(this, "Activity added!");
        }
    }
    
    private void saveActivitiesToFile() {
        File activitiesFile = new File("data_files/activities_" + lecturer.getUserId() + ".txt");
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(activitiesFile))) {
            for (String activity : recentActivities) {
                writer.write(activity);
                writer.newLine();
            }
        } catch (IOException e) {
            System.err.println("Error saving activities: " + e.getMessage());
        }
    }
    
    private void updateNotificationBadge() {
        int newActivities = Math.min(recentActivities.size(), 99);
        notificationBadge.setText(String.valueOf(newActivities));
        notificationBadge.setVisible(newActivities > 0);
    }
    
    private void showNotifications() {
        StringBuilder notifications = new StringBuilder();
        notifications.append("═══════════════════════════════════════\n");
        notifications.append("            RECENT ACTIVITIES\n");
        notifications.append("═══════════════════════════════════════\n\n");
        
        int count = 0;
        for (String activity : recentActivities) {
            notifications.append("📌 ").append(activity).append("\n\n");
            if (++count >= 15) break; // Show only last 15
        }
        
        notifications.append("═══════════════════════════════════════\n");
        notifications.append("Total activities: ").append(recentActivities.size()).append("\n");
        
        JTextArea textArea = new JTextArea(notifications.toString());
        textArea.setEditable(false);
        textArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(500, 400));
        
        JOptionPane.showMessageDialog(this, scrollPane, "Recent Activities", 
            JOptionPane.INFORMATION_MESSAGE);
        
        // Clear notification badge after viewing
        notificationBadge.setVisible(false);
    }
    
    // Custom cell renderer for buttons in table
    class ButtonRenderer extends JButton implements javax.swing.table.TableCellRenderer {
        public ButtonRenderer() {
            setOpaque(true);
        }
        
        public Component getTableCellRendererComponent(JTable table, Object value,
                boolean isSelected, boolean hasFocus, int row, int column) {
            setText((value == null) ? "" : value.toString());
            return this;
        }
    }
    
    // Custom cell editor for buttons in table
    class ButtonEditor extends DefaultCellEditor {
        private JButton button;
        private String label;
        private boolean isPushed;
        
        public ButtonEditor(JCheckBox checkBox) {
            super(checkBox);
            button = new JButton();
            button.setOpaque(true);
            button.addActionListener(e -> fireEditingStopped());
        }
        
        public Component getTableCellEditorComponent(JTable table, Object value,
                boolean isSelected, int row, int column) {
            label = (value == null) ? "" : value.toString();
            button.setText(label);
            isPushed = true;
            return button;
        }
        
        public Object getCellEditorValue() {
            if (isPushed) {
                // Handle button click
                int row = modulesTable.getSelectedRow();
                if (row != -1) {
                    String moduleId = (String) modulesTable.getValueAt(row, 0);
                    String moduleName = (String) modulesTable.getValueAt(row, 1);
                    
                    // Add activity
                    String activity = getCurrentTime() + " - Viewed details for " + moduleId;
                    recentActivities.add(0, activity);
                    saveActivitiesToFile();
                    updateActivitiesDisplay();
                    
                    // Show module details
                    JOptionPane.showMessageDialog(LecturerDashboard.this,
                        "Module Details:\n\n" +
                        "ID: " + moduleId + "\n" +
                        "Name: " + moduleName + "\n" +
                        "Lecturer: " + lecturer.getName(),
                        "Module Information", JOptionPane.INFORMATION_MESSAGE);
                }
            }
            isPushed = false;
            return label;
        }
        
        public boolean stopCellEditing() {
            isPushed = false;
            return super.stopCellEditing();
        }
    }
    
    private void editProfile() {
        JTextField txtName = new JTextField(lecturer.getName(), 20);
        JTextField txtEmail = new JTextField(lecturer.getEmail(), 20);
        JTextField txtContact = new JTextField(lecturer.getContactNum(), 20);
        JPasswordField txtPassword = new JPasswordField(20);
        
        JPanel panel = new JPanel(new GridLayout(4, 2, 10, 10));
        panel.add(new JLabel("Name:"));
        panel.add(txtName);
        panel.add(new JLabel("Email:"));
        panel.add(txtEmail);
        panel.add(new JLabel("Contact:"));
        panel.add(txtContact);
        panel.add(new JLabel("New Password (leave blank to keep):"));
        panel.add(txtPassword);
        
        int result = JOptionPane.showConfirmDialog(this, panel, 
            "Edit Profile", JOptionPane.OK_CANCEL_OPTION);
        
        if (result == JOptionPane.OK_OPTION) {
            String newPassword = new String(txtPassword.getPassword());
            if (newPassword.isEmpty()) {
                newPassword = null;
            }
            
            lecturer.editProfile(txtName.getText(), txtEmail.getText(), 
                txtContact.getText(), newPassword);
            
            // Add activity
            String activity = getCurrentTime() + " - Updated profile information";
            recentActivities.add(0, activity);
            saveActivitiesToFile();
            updateActivitiesDisplay();
            
            JOptionPane.showMessageDialog(this, "Profile updated successfully!");
            
            // Refresh tables
            DefaultTableModel model = (DefaultTableModel) infoTable.getModel();
            model.setValueAt(txtName.getText(), 1, 1); // Name row
            model.setValueAt(txtEmail.getText(), 2, 1); // Email row
            model.setValueAt(txtContact.getText(), 3, 1); // Contact row
        }
    }
    
    private void logout() {
        // Stop refresh timer
        if (refreshTimer != null) {
            refreshTimer.stop();
        }
        
        int confirm = JOptionPane.showConfirmDialog(this, 
            "Are you sure you want to logout?", "Logout", 
            JOptionPane.YES_NO_OPTION);
        
        if (confirm == JOptionPane.YES_OPTION) {
            this.dispose();
            new afs.ui.LoginFrame().setVisible(true);
        }
    }
}
