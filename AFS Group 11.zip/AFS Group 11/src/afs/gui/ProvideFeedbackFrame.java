package afs.gui;

import afs.model.Lecturer;
import afs.model.StudentComment;
import afs.data.FileHandler;
import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.io.*;
import afs.utils.ActivityLogger;

public class ProvideFeedbackFrame extends JFrame {
    private Lecturer lecturer;
    private JTextField txtAssessmentId, txtStudentId, txtComment;
    private JComboBox<String> cmbRating, cmbAssessment, cmbStudent;
    
    public ProvideFeedbackFrame(Lecturer lecturer) {
        this.lecturer = lecturer;
        
        setTitle("Provide Feedback");
        setSize(600, 500);
        setLocationRelativeTo(null);
        
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        
        // Title Panel
        JPanel titlePanel = new JPanel();
        titlePanel.setBackground(new Color(0, 102, 204));
        JLabel titleLabel = new JLabel("PROVIDE FEEDBACK TO STUDENT");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setForeground(Color.WHITE);
        titlePanel.add(titleLabel);
        mainPanel.add(titlePanel, BorderLayout.NORTH);
        
        // Form Panel
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createTitledBorder("Feedback Form"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        // ===== ASSESSMENT SELECTION =====
        gbc.gridx = 0; gbc.gridy = 0;
        formPanel.add(new JLabel("Select Assessment:"), gbc);
        
        gbc.gridx = 1;
        cmbAssessment = new JComboBox<>();
        cmbAssessment.addItem("-- Select Assessment --");
        loadAssessments();
        formPanel.add(cmbAssessment, gbc);
        
        // Or Assessment ID
        gbc.gridx = 0; gbc.gridy = 1;
        formPanel.add(new JLabel("OR Enter Assessment ID:"), gbc);
        
        gbc.gridx = 1;
        txtAssessmentId = new JTextField(20);
        formPanel.add(txtAssessmentId, gbc);
        
        // ===== STUDENT SELECTION =====
        gbc.gridx = 0; gbc.gridy = 2;
        formPanel.add(new JLabel("Select Student:"), gbc);
        
        gbc.gridx = 1;
        cmbStudent = new JComboBox<>();
        cmbStudent.addItem("-- Select Student --");
        loadStudents();
        formPanel.add(cmbStudent, gbc);
        
        // Or Student ID
        gbc.gridx = 0; gbc.gridy = 3;
        formPanel.add(new JLabel("OR Enter Student ID:"), gbc);
        
        gbc.gridx = 1;
        txtStudentId = new JTextField(20);
        formPanel.add(txtStudentId, gbc);
        
        // ===== COMMENT =====
        gbc.gridx = 0; gbc.gridy = 4;
        gbc.anchor = GridBagConstraints.NORTH;
        formPanel.add(new JLabel("Comment:"), gbc);
        
        gbc.gridx = 1;
        txtComment = new JTextField(20);
        formPanel.add(txtComment, gbc);
        
        // ===== RATING =====
        gbc.gridx = 0; gbc.gridy = 5;
        formPanel.add(new JLabel("Rating:"), gbc);
        
        gbc.gridx = 1;
        cmbRating = new JComboBox<>(new String[]{"Excellent", "Good", "Average", "Poor"});
        formPanel.add(cmbRating, gbc);
        
        // ===== INFO PANEL =====
        gbc.gridx = 0; gbc.gridy = 6; gbc.gridwidth = 2;
        JPanel infoPanel = new JPanel();
        infoPanel.setBackground(new Color(240, 248, 255));
        infoPanel.setBorder(BorderFactory.createTitledBorder("Quick Guide"));
        JLabel infoLabel = new JLabel("<html><div style='width: 400px;'>" +
            "<b>Instructions:</b><br>" +
            "1. Select assessment from dropdown OR enter Assessment ID<br>" +
            "2. Select student from dropdown OR enter Student ID<br>" +
            "3. Enter your feedback comment<br>" +
            "4. Select a rating<br>" +
            "5. Click 'Submit Feedback'" +
            "</div></html>");
        infoPanel.add(infoLabel);
        formPanel.add(infoPanel, gbc);
        
        mainPanel.add(formPanel, BorderLayout.CENTER);
        
        // ===== BUTTON PANEL =====
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        
        JButton btnSubmit = createStyledButton("Submit Feedback", new Color(0, 153, 76));
        btnSubmit.addActionListener(e -> submitFeedback());
        
        JButton btnClear = createStyledButton("Clear Form", new Color(255, 153, 0));
        btnClear.addActionListener(e -> clearForm());
        
        JButton btnCancel = createStyledButton("Cancel", new Color(204, 0, 0));
        btnCancel.addActionListener(e -> dispose());
        
        JButton btnViewAll = createStyledButton("View All Feedback", new Color(102, 0, 204));
        btnViewAll.addActionListener(e -> viewAllFeedback());
        
        JButton btnRefresh = createStyledButton("Refresh Lists", new Color(0, 102, 204));
        btnRefresh.addActionListener(e -> refreshLists());
        
        buttonPanel.add(btnSubmit);
        buttonPanel.add(btnClear);
        buttonPanel.add(btnRefresh);
        buttonPanel.add(btnViewAll);
        buttonPanel.add(btnCancel);
        
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);
        
        add(mainPanel);
    }
    
    // ===== HELPER METHODS =====
    
    private JButton createStyledButton(String text, Color color) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(color.brighter());
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(color);
            }
        });
        
        return button;
    }
    
    
    // Load assessments from assessments.txt file - ONLY assessments created by this lecturer
    private void loadAssessments() {
        File file = new File("data_files/assessments.txt");
        if (!file.exists()) {
            cmbAssessment.addItem("No assessments found - Create one first");
            return;
        }

        String lecturerId = lecturer.getUserId(); // Get current lecturer's ID

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            boolean isFirstLine = true;
            int count = 0;

            while ((line = br.readLine()) != null) {
                // Skip header if exists
                if (isFirstLine && line.startsWith("AssessmentID")) {
                    isFirstLine = false;
                    continue;
                }
                isFirstLine = false;

                String[] parts = line.split(",");
                // Check if assessment was created by this lecturer
                // Format: AssessmentID,ModuleID,Description,MaxMarks,DueDate,CreatorID
                if (parts.length >= 6) {
                    String assessmentId = parts[0];
                    String description = parts[2];
                    String creatorId = parts[5]; // Last field is the creator's ID

                    // Only show assessments created by this lecturer
                    if (creatorId.equals(lecturerId)) {
                        String displayText = assessmentId + " - " + description;
                        if (description.length() > 30) {
                            displayText = assessmentId + " - " + description.substring(0, 27) + "...";
                        }
                        cmbAssessment.addItem(displayText);
                        count++;
                    }
                }
            }

            if (count == 0) {
                cmbAssessment.addItem("No assessments created by you - Please create assessments first");
            }

            System.out.println("✓ Loaded " + count + " assessments for lecturer " + lecturerId);

        } catch (IOException e) {
            cmbAssessment.addItem("Error loading assessments");
            System.err.println("Error loading assessments: " + e.getMessage());
        }
    }
    
    // Load students from users.txt file
    private void loadStudents() {
        File file = new File("data_files/users.txt");
        if (!file.exists()) {
            cmbStudent.addItem("No students found - Check users.txt");
            return;
        }
        
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            boolean isFirstLine = true;
            while ((line = br.readLine()) != null) {
                // Skip header if exists
                if (isFirstLine && (line.startsWith("UserID") || line.startsWith("UserID"))) {
                    isFirstLine = false;
                    continue;
                }
                isFirstLine = false;
                
                String[] parts = line.split(",");
                if (parts.length >= 6 && parts[5].equals("Student")) {
                    String studentId = parts[0];
                    String studentName = parts[2];
                    cmbStudent.addItem(studentId + " - " + studentName);
                }
            }
            
            if (cmbStudent.getItemCount() == 1) { // Only has "-- Select Student --"
                cmbStudent.addItem("No students found in file");
            }
            
        } catch (IOException e) {
            cmbStudent.addItem("Error loading students");
            System.err.println("Error loading students: " + e.getMessage());
        }
    }
    
    // Refresh both dropdown lists
    // Refresh both dropdown lists
    private void refreshLists() {
        cmbAssessment.removeAllItems();
        cmbAssessment.addItem("-- Select Assessment --");
        loadAssessments();

        cmbStudent.removeAllItems();
        cmbStudent.addItem("-- Select Student --");
        loadStudents();

        // Show how many assessments loaded
        int assessmentCount = cmbAssessment.getItemCount() - 1; // Subtract the "-- Select --" item
        if (assessmentCount > 0) {
            JOptionPane.showMessageDialog(this, 
                "Refreshed! Found " + assessmentCount + " assessments created by you.\n" +
                "Found " + (cmbStudent.getItemCount() - 1) + " students.",
                "Refresh Complete", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, 
                "No assessments found that were created by you.\n" +
                "Please create assessments first in Design Assessment.",
                "No Assessments Found", JOptionPane.WARNING_MESSAGE);
        }
    }
    
    private void submitFeedback() {
        String assessmentId = txtAssessmentId.getText().trim();
        String studentId = txtStudentId.getText().trim();
        String comment = txtComment.getText();
        String rating = (String) cmbRating.getSelectedItem();
        
        // Get assessment from dropdown if selected
        if (cmbAssessment.getSelectedIndex() > 0 && assessmentId.isEmpty()) {
            String selected = (String) cmbAssessment.getSelectedItem();
            assessmentId = selected.split(" - ")[0].trim();
        }
        
        // Get student from dropdown if selected
        if (cmbStudent.getSelectedIndex() > 0 && studentId.isEmpty()) {
            String selected = (String) cmbStudent.getSelectedItem();
            studentId = selected.split(" - ")[0].trim();
        }
        
        // Validation
        if (assessmentId.isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "Please select or enter Assessment ID!", 
                "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        if (studentId.isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "Please select or enter Student ID!", 
                "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        if (comment.isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "Please enter a comment!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Confirm before submitting
        int confirm = JOptionPane.showConfirmDialog(this,
            "<html><b>Confirm Feedback Submission:</b><br>" +
            "Assessment: " + assessmentId + "<br>" +
            "Student: " + studentId + "<br>" +
            "Rating: " + rating + "<br>" +
            "Comment: " + (comment.length() > 50 ? comment.substring(0, 47) + "..." : comment) +
            "</html>",
            "Confirm Submission", JOptionPane.YES_NO_OPTION);
        
        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }
        
        try {
            // Create feedback using lecturer's method
            String feedbackData = lecturer.provideFeedback(assessmentId, studentId, comment, rating);
            
            // Parse the feedback data (format: feedbackId,assessmentId,studentId,lecturerId,comment,rating,date)
            String[] parts = feedbackData.split(",");

            String moduleId = findModuleIdForAssessment(assessmentId);
            String combinedComment = comment + " [Rating: " + rating + "]";
            StudentComment studentComment = new StudentComment(
                studentId,
                lecturer.getUserId(),
                moduleId,
                combinedComment
            );

            // Save to comments file via FileHandler
            FileHandler.saveFeedback(studentComment);
            
            ActivityLogger.logActivity(lecturer, "Provided feedback to " + studentId + " for " + assessmentId + " (Rating: " + rating + ")");
            
            JOptionPane.showMessageDialog(this, 
                "<html><div style='text-align: center;'>" +
                "<h3 style='color: green;'>✓ Feedback Provided Successfully!</h3>" +
                "<b>Feedback ID:</b> " + parts[0] + "<br>" +
                "<b>To Student:</b> " + studentId + "<br>" +
                "<b>Assessment:</b> " + assessmentId + "<br>" +
                "<b>Rating:</b> " + rating +
                "</div></html>");
            
            clearForm();
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, 
                "Error: " + e.getMessage(), 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void clearForm() {
        txtAssessmentId.setText("");
        txtStudentId.setText("");
        txtComment.setText("");
        cmbAssessment.setSelectedIndex(0);
        cmbStudent.setSelectedIndex(0);
        cmbRating.setSelectedIndex(0);
    }
    
    private void viewAllFeedback() {
    File feedbackFile = new File("data_files/comments.txt");
    if (!feedbackFile.exists()) {
        JOptionPane.showMessageDialog(this, 
            "<html><div style='text-align: center;'>" +
            "<h3>No Comment Data Yet</h3>" +
            "No comments have been provided.<br>" +
            "Submit feedback to create the comments.txt file." +
            "</div></html>", 
            "No Data", JOptionPane.INFORMATION_MESSAGE);
        return;
    }
    
    String lecturerId = lecturer.getUserId(); // Get current lecturer's ID
    
    try (BufferedReader reader = new BufferedReader(new FileReader(feedbackFile))) {
        StringBuilder allFeedback = new StringBuilder();
        allFeedback.append("═══════════════════════════════════════\n");
        allFeedback.append("     FEEDBACK PROVIDED BY YOU (" + lecturerId + ")\n");
        allFeedback.append("═══════════════════════════════════════\n\n");
        
        String line;
        int count = 0;
        boolean isFirstLine = true;
        
        while ((line = reader.readLine()) != null) {
            // Skip header if exists
            if (isFirstLine && line.startsWith("StudentID")) {
                isFirstLine = false;
                continue;
            }
            isFirstLine = false;
            
            // Format: StudentID,LecturerID,ModuleID,Comment,Date/Time
            String[] parts = line.split(",", 5);
            if (parts.length >= 5) {
                String entryLecturerId = parts[1]; // 2nd field is LecturerID
                
                // Only show feedback provided by this lecturer
                if (entryLecturerId.equals(lecturerId)) {
                    count++;
                    allFeedback.append("Entry #").append(count).append(":\n");
                    allFeedback.append("  Student: ").append(parts[0]).append("\n");
                    allFeedback.append("  Lecturer: ").append(parts[1]).append("\n");
                    allFeedback.append("  Module: ").append(parts[2]).append("\n");
                    allFeedback.append("  Date: ").append(parts[4]).append("\n");
                    allFeedback.append("  Comment: ");
                    if (parts[3].length() > 50) {
                        allFeedback.append(parts[3].substring(0, 47)).append("...\n");
                    } else {
                        allFeedback.append(parts[3]).append("\n");
                    }
                    allFeedback.append("─────────────────────────────────────\n");
                }
            }
        }
        
        if (count == 0) {
            allFeedback.append("You haven't provided any feedback yet.\n");
            allFeedback.append("Use this form to provide feedback to students.\n");
        }
        
        allFeedback.append("\n═══════════════════════════════════════\n");
        allFeedback.append("Total feedback provided by " + lecturerId + ": ").append(count).append("\n");
        allFeedback.append("═══════════════════════════════════════\n");
        
        // Display in a dialog
        JTextArea textArea = new JTextArea(allFeedback.toString());
        textArea.setEditable(false);
        textArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(600, 400));
        
        JOptionPane.showMessageDialog(this, scrollPane, "Feedback Provided By " + lecturerId, JOptionPane.INFORMATION_MESSAGE);
        
    } catch (IOException e) {
        JOptionPane.showMessageDialog(this, 
            "Error reading feedback file: " + e.getMessage(), 
            "Error", JOptionPane.ERROR_MESSAGE);
    }
}

    private String findModuleIdForAssessment(String assessmentId) {
        File file = new File("data_files/assessments.txt");
        if (!file.exists()) return assessmentId;

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            boolean isFirstLine = true;
            while ((line = br.readLine()) != null) {
                if (isFirstLine && line.startsWith("AssessmentID")) {
                    isFirstLine = false;
                    continue;
                }
                isFirstLine = false;
                String[] parts = line.split(",");
                if (parts.length >= 2 && parts[0].trim().equals(assessmentId)) {
                    return parts[1].trim();
                }
            }
        } catch (IOException e) {
            // keep fallback
        }
        return assessmentId;
    }
}
