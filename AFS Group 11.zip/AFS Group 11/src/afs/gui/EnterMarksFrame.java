package afs.gui;

import afs.model.Lecturer;
import afs.data.FileHandler;
import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.util.ArrayList;
import java.io.*;
import afs.utils.ActivityLogger;

public class EnterMarksFrame extends JFrame {
    private Lecturer lecturer;
    private JTextField txtAssessmentId, txtStudentId, txtMarks;
    private JTextArea txtFeedback;
    private JComboBox<String> cmbAssessment, cmbStudent;
    private JLabel lblGrade; // Added for displaying calculated grade
    
    public EnterMarksFrame(Lecturer lecturer) {
        this.lecturer = lecturer;
        
        setTitle("Enter Assessment Marks");
        setSize(700, 600); // Slightly larger to accommodate grade field
        setLocationRelativeTo(null);
        
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        
        // Title Panel
        JPanel titlePanel = new JPanel();
        titlePanel.setBackground(new Color(0, 102, 204));
        JLabel titleLabel = new JLabel("ENTER ASSESSMENT MARKS");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setForeground(Color.WHITE);
        titlePanel.add(titleLabel);
        mainPanel.add(titlePanel, BorderLayout.NORTH);
        
        // Form Panel
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createTitledBorder("Marks Entry Form"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        // ===== ASSESSMENT SELECTION =====
        gbc.gridx = 0; gbc.gridy = 0;
        formPanel.add(new JLabel("Select Assessment:"), gbc);
        
        gbc.gridx = 1;
        cmbAssessment = new JComboBox<>();
        cmbAssessment.addItem("-- Select Assessment --");
        cmbAssessment.addActionListener(e -> updateAssessmentDescription());
        loadAssessments(); // Load from file
        formPanel.add(cmbAssessment, gbc);
        
        // Or Assessment ID
        gbc.gridx = 0; gbc.gridy = 1;
        formPanel.add(new JLabel("OR Enter Assessment ID:"), gbc);
        
        gbc.gridx = 1;
        txtAssessmentId = new JTextField(20);
        txtAssessmentId.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            public void changedUpdate(javax.swing.event.DocumentEvent e) { updateAssessmentDescription(); }
            public void removeUpdate(javax.swing.event.DocumentEvent e) { updateAssessmentDescription(); }
            public void insertUpdate(javax.swing.event.DocumentEvent e) { updateAssessmentDescription(); }
        });
        formPanel.add(txtAssessmentId, gbc);
        
        // Assessment Description Display
        gbc.gridx = 0; gbc.gridy = 2;
        formPanel.add(new JLabel("Assessment Description:"), gbc);
        
        gbc.gridx = 1;
        JLabel lblAssessmentDesc = new JLabel("None selected");
        lblAssessmentDesc.setForeground(Color.DARK_GRAY);
        lblAssessmentDesc.setName("lblAssessmentDesc"); // Set name for reference
        formPanel.add(lblAssessmentDesc, gbc);
        
        // ===== STUDENT SELECTION =====
        gbc.gridx = 0; gbc.gridy = 3;
        formPanel.add(new JLabel("Select Student:"), gbc);
        
        gbc.gridx = 1;
        cmbStudent = new JComboBox<>();
        cmbStudent.addItem("-- Select Student --");
        loadStudents(); // Load from file
        formPanel.add(cmbStudent, gbc);
        
        // Or Student ID
        gbc.gridx = 0; gbc.gridy = 4;
        formPanel.add(new JLabel("OR Enter Student ID:"), gbc);
        
        gbc.gridx = 1;
        txtStudentId = new JTextField(20);
        formPanel.add(txtStudentId, gbc);
        
        // ===== MARKS INPUT =====
        gbc.gridx = 0; gbc.gridy = 5;
        formPanel.add(new JLabel("Marks (0-100):"), gbc);
        
        gbc.gridx = 1;
        JPanel marksPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        txtMarks = new JTextField(10);
        txtMarks.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            public void changedUpdate(javax.swing.event.DocumentEvent e) { calculateGradeFromFile(); }
            public void removeUpdate(javax.swing.event.DocumentEvent e) { calculateGradeFromFile(); }
            public void insertUpdate(javax.swing.event.DocumentEvent e) { calculateGradeFromFile(); }
        });
        marksPanel.add(txtMarks);
        marksPanel.add(new JLabel("  →  Grade:"));
        lblGrade = new JLabel("---");
        lblGrade.setFont(new Font("Arial", Font.BOLD, 14));
        lblGrade.setForeground(new Color(0, 102, 0));
        lblGrade.setPreferredSize(new Dimension(60, 20));
        marksPanel.add(lblGrade);
        formPanel.add(marksPanel, gbc);
        
        // ===== FEEDBACK =====
        gbc.gridx = 0; gbc.gridy = 6;
        gbc.anchor = GridBagConstraints.NORTH;
        formPanel.add(new JLabel("Feedback to Student:"), gbc); // Changed from "Feedback (Optional):"
        
        gbc.gridx = 1;
        txtFeedback = new JTextArea(4, 30);
        txtFeedback.setLineWrap(true);
        txtFeedback.setWrapStyleWord(true);
        txtFeedback.setBackground(new Color(255, 255, 240)); // Light yellow background to indicate required
        JScrollPane feedbackScroll = new JScrollPane(txtFeedback);
        formPanel.add(feedbackScroll, gbc);
        
        // ===== INFO PANEL =====
        gbc.gridx = 0; gbc.gridy = 7; gbc.gridwidth = 2;
        JPanel infoPanel = new JPanel();
        infoPanel.setBackground(new Color(240, 248, 255));
        infoPanel.setBorder(BorderFactory.createTitledBorder("Quick Guide"));
        JLabel infoLabel = new JLabel("<html><div style='width: 400px;'>" +
            "<b>Instructions:</b><br>" +
            "1. Select assessment from dropdown OR enter Assessment ID<br>" +
            "2. Select student from dropdown OR enter Student ID<br>" +
            "3. Enter marks (0-100) - Grade will auto-calculate from grading.txt<br>" +
            "4. <b>Provide feedback to student (Required)</b><br>" + // Changed to Required
            "5. Click 'Submit Marks'<br>" +
            "<br><b>Note:</b> Grading scale is loaded from data_files/grading.txt" +
            "</div></html>");
        infoPanel.add(infoLabel);
        formPanel.add(infoPanel, gbc);
        
        mainPanel.add(formPanel, BorderLayout.CENTER);
        
        // ===== BUTTON PANEL =====
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        
        JButton btnSubmit = createStyledButton("Submit Marks", new Color(0, 153, 76));
        btnSubmit.addActionListener(e -> submitMarks());
        
        JButton btnClear = createStyledButton("Clear Form", new Color(255, 153, 0));
        btnClear.addActionListener(e -> clearForm());
        
        JButton btnCancel = createStyledButton("Cancel", new Color(204, 0, 0));
        btnCancel.addActionListener(e -> dispose());
        
        JButton btnViewAll = createStyledButton("View All Marks", new Color(102, 0, 204));
        btnViewAll.addActionListener(e -> viewAllMarks());
        
        JButton btnRefresh = createStyledButton("Refresh Lists", new Color(0, 102, 204));
        btnRefresh.addActionListener(e -> refreshLists());
        
        buttonPanel.add(btnSubmit);
        buttonPanel.add(btnClear);
        buttonPanel.add(btnRefresh);
        buttonPanel.add(btnViewAll);
        buttonPanel.add(btnCancel);
        
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);
        
        add(mainPanel);
    }
    
    // ===== HELPER METHODS =====
    
    private JButton createStyledButton(String text, Color color) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(color.brighter());
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(color);
            }
        });
        
        return button;
    }
    
    // Calculate grade based on marks from grading.txt file
    private String calculateGradeFromFile(int marks) {
        File gradingFile = new File("data_files/grading.txt");
        
        if (!gradingFile.exists()) {
            JOptionPane.showMessageDialog(this, 
                "Grading file not found: data_files/grading.txt\nUsing default grading scale.",
                "Warning", JOptionPane.WARNING_MESSAGE);
            return calculateDefaultGrade(marks);
        }
        
        try (BufferedReader br = new BufferedReader(new FileReader(gradingFile))) {
            String line;
            boolean isFirstLine = true;
            
            while ((line = br.readLine()) != null) {
                // Skip header if exists
                if (isFirstLine && (line.startsWith("Grade") || line.startsWith("Min") || line.startsWith("MinMark"))) {
                    isFirstLine = false;
                    continue;
                }
                isFirstLine = false;
                
                // Try different possible formats
                String[] parts = line.split(",");
                if (parts.length >= 2) {
                    try {
                        // Format 1: Grade,MinMark,MaxMark (or similar)
                        String grade = parts[0].trim();
                        int minMark = Integer.parseInt(parts[1].trim());
                        
                        if (parts.length >= 3) {
                            // Has max mark
                            int maxMark = Integer.parseInt(parts[2].trim());
                            if (marks >= minMark && marks <= maxMark) {
                                return grade;
                            }
                        } else {
                            // Only has min mark (assume it's the lower bound)
                            // Check next line or use default ranges
                            if (marks >= minMark) {
                                // This is simplified - would need to check ranges properly
                                // For now, return grade if marks >= minMark
                                return grade;
                            }
                        }
                    } catch (NumberFormatException e) {
                        // Try alternative format
                        continue;
                    }
                }
                
                // Alternative format: A,85,100 or similar
                if (parts.length >= 3) {
                    try {
                        String grade = parts[0].trim();
                        int minMark = Integer.parseInt(parts[1].trim());
                        int maxMark = Integer.parseInt(parts[2].trim());
                        
                        if (marks >= minMark && marks <= maxMark) {
                            return grade;
                        }
                    } catch (NumberFormatException e) {
                        continue;
                    }
                }
            }
            
            // If no match found in file, use default
            return calculateDefaultGrade(marks);
            
        } catch (IOException e) {
            System.err.println("Error reading grading file: " + e.getMessage());
            return calculateDefaultGrade(marks);
        }
    }
    
    // Default grade calculation if grading.txt is not found
    private String calculateDefaultGrade(int marks) {
        if (marks >= 85) return "A";
        else if (marks >= 70) return "B";
        else if (marks >= 55) return "C";
        else if (marks >= 40) return "D";
        else return "F";
    }
    
    // Update grade label when marks change
    private void calculateGradeFromFile() {
        String marksStr = txtMarks.getText().trim();
        if (marksStr.isEmpty()) {
            lblGrade.setText("---");
            return;
        }
        
        try {
            int marks = Integer.parseInt(marksStr);
            if (marks < 0 || marks > 100) {
                lblGrade.setText("Invalid");
                lblGrade.setForeground(Color.RED);
            } else {
                String grade = calculateGradeFromFile(marks);
                lblGrade.setText(grade);
                // Set color based on grade
                setGradeColor(grade);
            }
        } catch (NumberFormatException e) {
            lblGrade.setText("Invalid");
            lblGrade.setForeground(Color.RED);
        }
    }
    
    // Set color based on grade
    private void setGradeColor(String grade) {
        switch (grade.toUpperCase()) {
            case "A": lblGrade.setForeground(new Color(0, 153, 0)); break; // Green
            case "B": lblGrade.setForeground(new Color(0, 102, 204)); break; // Blue
            case "C": lblGrade.setForeground(new Color(255, 153, 0)); break; // Orange
            case "D": lblGrade.setForeground(new Color(255, 102, 0)); break; // Dark Orange
            case "F": lblGrade.setForeground(Color.RED); break;
            case "PASS": lblGrade.setForeground(new Color(0, 153, 0)); break; // Green
            case "FAIL": lblGrade.setForeground(Color.RED); break;
            default: lblGrade.setForeground(Color.BLACK);
        }
    }
    
    // Update assessment description when assessment is selected
    private void updateAssessmentDescription() {
        String assessmentDesc = "None selected";
        
        // Try to get from dropdown first
        if (cmbAssessment.getSelectedIndex() > 0) {
            String selected = (String) cmbAssessment.getSelectedItem();
            if (selected != null && selected.contains(" - ")) {
                assessmentDesc = selected.split(" - ", 2)[1];
            }
        } 
        // If manual entry, try to find in file
        else if (!txtAssessmentId.getText().trim().isEmpty()) {
            String assessmentId = txtAssessmentId.getText().trim();
            assessmentDesc = getAssessmentDescription(assessmentId);
        }
        
        // Find and update the label
        for (Component comp : getContentPane().getComponents()) {
            if (comp instanceof JPanel) {
                for (Component child : ((JPanel) comp).getComponents()) {
                    if (child instanceof JPanel) {
                        for (Component grandchild : ((JPanel) child).getComponents()) {
                            if (grandchild instanceof JLabel && 
                                "lblAssessmentDesc".equals(grandchild.getName())) {
                                ((JLabel) grandchild).setText(assessmentDesc);
                                return;
                            }
                        }
                    }
                }
            }
        }
    }
    
    // Get assessment description from file
    private String getAssessmentDescription(String assessmentId) {
        File file = new File("data_files/assessments.txt");
        if (!file.exists()) return "Not found";
        
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            boolean isFirstLine = true;
            
            while ((line = br.readLine()) != null) {
                // Skip header
                if (isFirstLine && line.startsWith("AssessmentID")) {
                    isFirstLine = false;
                    continue;
                }
                isFirstLine = false;
                
                String[] parts = line.split(",");
                if (parts.length >= 3 && parts[0].equals(assessmentId)) {
                    return parts[2]; // Description is at index 2
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading assessments: " + e.getMessage());
        }
        
        return "Not found";
    }
    
    // Load assessments from assessments.txt file - ONLY assessments created by this lecturer
    private void loadAssessments() {
        File file = new File("data_files/assessments.txt");
        if (!file.exists()) {
            cmbAssessment.addItem("No assessments found - Create one first");
            return;
        }

        String lecturerId = lecturer.getUserId(); // Get current lecturer's ID

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            boolean isFirstLine = true;
            int count = 0;

            while ((line = br.readLine()) != null) {
                // Skip header if exists
                if (isFirstLine && line.startsWith("AssessmentID")) {
                    isFirstLine = false;
                    continue;
                }
                isFirstLine = false;

                String[] parts = line.split(",");
                // Check if assessment was created by this lecturer
                // Format: AssessmentID,ModuleID,Description,MaxMarks,DueDate,CreatorID
                if (parts.length >= 6) {
                    String assessmentId = parts[0];
                    String description = parts[2];
                    String creatorId = parts[5]; // Last field is the creator's ID

                    // Only show assessments created by this lecturer
                    if (creatorId.equals(lecturerId)) {
                        String displayText = assessmentId + " - " + description;
                        if (description.length() > 30) {
                            displayText = assessmentId + " - " + description.substring(0, 27) + "...";
                        }
                        cmbAssessment.addItem(displayText);
                        count++;
                    }
                }
            }

            if (count == 0) {
                cmbAssessment.addItem("No assessments created by you - Please create assessments first");
            }

            System.out.println("Loaded " + count + " assessments for lecturer " + lecturerId);

        } catch (IOException e) {
            cmbAssessment.addItem("Error loading assessments");
            System.err.println("Error loading assessments: " + e.getMessage());
        }
    }
    
    // Load students from users.txt file
    private void loadStudents() {
        File file = new File("data_files/users.txt");
        if (!file.exists()) {
            cmbStudent.addItem("No students found - Check users.txt");
            return;
        }
        
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            boolean isFirstLine = true;
            while ((line = br.readLine()) != null) {
                // Skip header if exists
                if (isFirstLine && (line.startsWith("UserID") || line.startsWith("UserID"))) {
                    isFirstLine = false;
                    continue;
                }
                isFirstLine = false;
                
                String[] parts = line.split(",");
                if (parts.length >= 6 && parts[5].equals("Student")) {
                    String studentId = parts[0];
                    String studentName = parts[2];
                    cmbStudent.addItem(studentId + " - " + studentName);
                }
            }
            
            if (cmbStudent.getItemCount() == 1) { // Only has "-- Select Student --"
                cmbStudent.addItem("No students found in file");
            }
            
        } catch (IOException e) {
            cmbStudent.addItem("Error loading students");
            System.err.println("Error loading students: " + e.getMessage());
        }
    }
    
    // Refresh both dropdown lists
    private void refreshLists() {
        cmbAssessment.removeAllItems();
        cmbAssessment.addItem("-- Select Assessment --");
        loadAssessments();

        cmbStudent.removeAllItems();
        cmbStudent.addItem("-- Select Student --");
        loadStudents();

        // Show how many assessments loaded
        int assessmentCount = cmbAssessment.getItemCount() - 1; // Subtract the "-- Select --" item
        if (assessmentCount > 0) {
            JOptionPane.showMessageDialog(this, 
                "Refreshed! Found " + assessmentCount + " assessments created by you.\n" +
                "Found " + (cmbStudent.getItemCount() - 1) + " students.",
                "Refresh Complete", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, 
                "No assessments found that were created by you.\n" +
                "Please create assessments first in Design Assessment.",
                "No Assessments Found", JOptionPane.WARNING_MESSAGE);
        }
        
        // Reset grade display
        lblGrade.setText("---");
        lblGrade.setForeground(new Color(0, 102, 0));
    }
    
    private void submitMarks() {
        String assessmentId = txtAssessmentId.getText().trim();
        String studentId = txtStudentId.getText().trim();
        String marksStr = txtMarks.getText().trim();
        String feedback = txtFeedback.getText().trim();
        String assessmentDescription = "";
        
        // Get assessment from dropdown if selected
        if (cmbAssessment.getSelectedIndex() > 0 && assessmentId.isEmpty()) {
            String selected = (String) cmbAssessment.getSelectedItem();
            String[] parts = selected.split(" - ", 2);
            assessmentId = parts[0].trim();
            if (parts.length > 1) {
                assessmentDescription = parts[1].trim();
            }
        } else if (!assessmentId.isEmpty()) {
            // Get description for manually entered assessment ID
            assessmentDescription = getAssessmentDescription(assessmentId);
        }
        
        // Get student from dropdown if selected
        if (cmbStudent.getSelectedIndex() > 0 && studentId.isEmpty()) {
            String selected = (String) cmbStudent.getSelectedItem();
            studentId = selected.split(" - ")[0].trim();
        }
        
        // Validation
        if (assessmentId.isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "Please select or enter Assessment ID!", 
                "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        if (studentId.isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "Please select or enter Student ID!", 
                "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        if (marksStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "Please enter marks!", 
                "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // FEEDBACK IS NOW REQUIRED
        if (feedback.isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "<html><b>Feedback is required!</b><br>" +
                "Please provide feedback to the student.<br>" +
                "This helps students understand their performance.</html>", 
                "Feedback Required", JOptionPane.WARNING_MESSAGE);
            txtFeedback.requestFocus();
            return;
        }
        
        try {
            int marks = Integer.parseInt(marksStr);
            
            if (marks < 0 || marks > 100) {
                JOptionPane.showMessageDialog(this, 
                    "Marks must be between 0 and 100!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            // Calculate grade from grading.txt file
            String grade = calculateGradeFromFile(marks);
            
            // Confirm before submitting
            int confirm = JOptionPane.showConfirmDialog(this,
                "<html><b>Confirm Marks Entry:</b><br>" +
                "Assessment: " + assessmentId + "<br>" +
                "Description: " + (assessmentDescription.isEmpty() ? "Not specified" : assessmentDescription) + "<br>" +
                "Student: " + studentId + "<br>" +
                "Marks: " + marks + "/100<br>" +
                "Grade: " + grade + "<br>" +
                "<b>Feedback:</b> " + (feedback.length() > 50 ? feedback.substring(0, 47) + "..." : feedback) +
                "</html>",
                "Confirm Submission", JOptionPane.YES_NO_OPTION);
            
            if (confirm != JOptionPane.YES_OPTION) {
                return;
            }
            
            // Save to file in new format: StudentID,AssessmentID,Description,Marks,Grade,Feedback,LecturerID
            saveMarksToFile(assessmentId, studentId, assessmentDescription, marks, grade, feedback);
            
            ActivityLogger.logActivity(lecturer, 
                "Entered marks for " + studentId + " in " + assessmentId + ": " + marks + "/100, Grade: " + grade + " (with feedback)");
            
            JOptionPane.showMessageDialog(this, 
                "<html><div style='text-align: center;'>" +
                "<h3 style='color: green;'>✓ Marks Entered Successfully!</h3>" +
                "<b>Assessment:</b> " + assessmentId + "<br>" +
                "<b>Description:</b> " + (assessmentDescription.isEmpty() ? "Not specified" : assessmentDescription) + "<br>" +
                "<b>Student:</b> " + studentId + "<br>" +
                "<b>Marks:</b> " + marks + "/100<br>" +
                "<b>Grade:</b> " + grade + "<br>" +
                "<b>Feedback:</b> Provided ✓<br>" +
                "<i>Feedback helps students improve!</i>" +
                "</div></html>", 
                "Success", JOptionPane.INFORMATION_MESSAGE);
            
            clearForm();
            
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, 
                "Please enter valid marks (numbers only)!", 
                "Error", JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, 
                "Error: " + e.getMessage(), 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void saveMarksToFile(String assessmentId, String studentId, String description, 
                                int marks, String grade, String feedback) {
        File file = new File("data_files/results.txt");
        boolean fileExists = file.exists();
        
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file, true))) {
            // Write header if file is new
            if (!fileExists) {
                writer.write("StudentID,AssessmentID,Description,Marks,Grade,Feedback,LecturerID");
                writer.newLine();
            }
            
            // Format: StudentID,AssessmentID,Description,Marks,Grade,Feedback,LecturerID
            String line = String.format("%s,%s,%s,%d,%s,%s,%s",
                studentId,
                assessmentId,
                description.isEmpty() ? "No description" : description.replace(",", ";"),
                marks,
                grade,
                feedback.replace(",", ";"), // Feedback is now always present
                lecturer.getUserId()
            );
            
            writer.write(line);
            writer.newLine();
            System.out.println("✓ Marks saved to results.txt: " + line);
            
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, 
                "Error saving marks: " + e.getMessage(), 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void clearForm() {
        txtAssessmentId.setText("");
        txtStudentId.setText("");
        txtMarks.setText("");
        txtFeedback.setText("");
        txtFeedback.setBackground(new Color(255, 255, 240)); // Reset background color
        cmbAssessment.setSelectedIndex(0);
        cmbStudent.setSelectedIndex(0);
        lblGrade.setText("---");
        lblGrade.setForeground(new Color(0, 102, 0));
        
        // Clear assessment description label
        for (Component comp : getContentPane().getComponents()) {
            if (comp instanceof JPanel) {
                for (Component child : ((JPanel) comp).getComponents()) {
                    if (child instanceof JPanel) {
                        for (Component grandchild : ((JPanel) child).getComponents()) {
                            if (grandchild instanceof JLabel && 
                                "lblAssessmentDesc".equals(grandchild.getName())) {
                                ((JLabel) grandchild).setText("None selected");
                                return;
                            }
                        }
                    }
                }
            }
        }
    }
    
    private void viewAllMarks() {
    File marksFile = new File("data_files/results.txt");
    if (!marksFile.exists()) {
        JOptionPane.showMessageDialog(this, 
            "<html><div style='text-align: center;'>" +
            "<h3>No Marks Data Yet</h3>" +
            "No marks have been entered.<br>" +
            "Submit marks to create the results.txt file." +
            "</div></html>", 
            "No Data", JOptionPane.INFORMATION_MESSAGE);
        return;
    }
    
    String lecturerId = lecturer.getUserId(); // Get current lecturer's ID
    
    try (BufferedReader reader = new BufferedReader(new FileReader(marksFile))) {
        StringBuilder allMarks = new StringBuilder();
        allMarks.append("══════════════════════════════════════════════════════════════════\n");
        allMarks.append("                 MARKS ENTERED BY YOU (" + lecturerId + ")\n");
        allMarks.append("══════════════════════════════════════════════════════════════════\n\n");
        
        String line;
        int count = 0;
        boolean isFirstLine = true;
        
        while ((line = reader.readLine()) != null) {
            // Skip header
            if (isFirstLine && line.startsWith("StudentID")) {
                isFirstLine = false;
                continue;
            }
            isFirstLine = false;
            
            // Check if this marks entry was created by this lecturer
            // Format: StudentID,AssessmentID,Description,Marks,Grade,Feedback,LecturerID
            if (line.contains(",")) {
                String[] parts = line.split(",");
                if (parts.length >= 7) {
                    String entryLecturerId = parts[6]; // 7th field is LecturerID
                    
                    // Only show entries created by this lecturer
                    if (entryLecturerId.equals(lecturerId)) {
                        count++;
                        allMarks.append("Entry #").append(count).append(":\n");
                        allMarks.append("  Student ID:    ").append(parts[0]).append("\n");
                        allMarks.append("  Assessment ID: ").append(parts[1]).append("\n");
                        allMarks.append("  Description:   ").append(parts[2].replace(";", ",")).append("\n");
                        allMarks.append("  Marks:         ").append(parts[3]).append("/100\n");
                        allMarks.append("  Grade:         ").append(parts[4]).append("\n");
                        allMarks.append("  Feedback:      ").append(parts[5].replace(";", ",")).append("\n");
                        allMarks.append("  Lecturer ID:   ").append(parts[6]).append("\n");
                        allMarks.append("────────────────────────────────────────────────────────────\n");
                    }
                }
            }
        }
        
        if (count == 0) {
            allMarks.append("You haven't entered any marks yet.\n");
            allMarks.append("Use this form to enter marks for your assessments.\n");
        }
        
        allMarks.append("\n══════════════════════════════════════════════════════════════════\n");
        allMarks.append("Total entries by " + lecturerId + ": ").append(count).append("\n");
        allMarks.append("══════════════════════════════════════════════════════════════════\n");
        
        // Display in a dialog
        JTextArea textArea = new JTextArea(allMarks.toString());
        textArea.setEditable(false);
        textArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(600, 450));
        
        JOptionPane.showMessageDialog(this, scrollPane, "Marks Entered By " + lecturerId, JOptionPane.INFORMATION_MESSAGE);
        
    } catch (IOException e) {
        JOptionPane.showMessageDialog(this, 
            "Error reading marks file: " + e.getMessage(), 
            "Error", JOptionPane.ERROR_MESSAGE);
    }
}
}