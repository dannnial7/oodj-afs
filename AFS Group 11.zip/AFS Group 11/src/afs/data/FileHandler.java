package afs.data;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import afs.model.Lecturer;
import afs.model.Assessment;
import afs.model.StudentComment;
// DO NOT import afs.model.Module - use fully qualified name instead

public class FileHandler {

    // Load modules taught by a specific lecturer
    public static List<afs.model.Module> loadLecturerModules(String lecturerId) {
        List<afs.model.Module> modules = new ArrayList<>();
        List<String[]> records = readFile("modules.txt");

        if (records == null || records.isEmpty()) {
            return modules;
        }

        int startIndex = records.get(0)[0].equals("ModuleID") ? 1 : 0;

        for (int i = startIndex; i < records.size(); i++) {
            String[] data = records.get(i);
            if (data != null && data.length >= 3 && data[2].equals(lecturerId)) {
                modules.add(new afs.model.Module(data[0], data[1], data[2]));
            }
        }

        return modules;
    }

    // Load all lecturers
    public static List<Lecturer> loadLecturers() {
        List<Lecturer> lecturers = new ArrayList<>();
        List<String[]> records = readFile("users.txt");

        if (records == null || records.isEmpty()) {
            return lecturers;
        }

        int startIndex = records.get(0)[0].equals("UserID") ? 1 : 0;

        for (int i = startIndex; i < records.size(); i++) {
            String[] data = records.get(i);
            if (data != null && data.length >= 6 && data[5].equals("Lecturer")) {
                lecturers.add(new Lecturer(data[0], data[1], data[2], data[3], data[4]));
            }
        }

        return lecturers;
    }

    // Save assessment to file
    public static void saveAssessment(Assessment assessment) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("data_files/assessments.txt", true))) {
            writer.write(assessment.toFileString());
            writer.newLine();
        } catch (IOException e) {
            System.err.println("Error saving assessment: " + e.getMessage());
        }
    }

    // Save lecturer comment to file
    public static void saveFeedback(StudentComment comment) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("data_files/comments.txt", true))) {
            writer.write(comment.toFileString());
            writer.newLine();
        } catch (IOException e) {
            System.err.println("Error saving student comment: " + e.getMessage());
        }
    }


    // Helper method to read file
    private static List<String[]> readFile(String filename) {
        List<String[]> records = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader("data_files/" + filename))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] data = line.trim().split(",");
                records.add(data);
            }
        } catch (IOException e) {
            System.err.println("Error reading file: " + filename);
            e.printStackTrace();
            return null;
        }
        return records;
    }
    
    public static boolean updateUserProfile(String userId, String newName, 
                                           String newEmail, String newContact, 
                                           String newPassword) {
        List<String> lines = new ArrayList<>();
        boolean updated = false;
        
        try (BufferedReader br = new BufferedReader(new FileReader("data_files/users.txt"))) {
            String line;
            boolean isFirstLine = true;
            
            while ((line = br.readLine()) != null) {
                if (isFirstLine) {
                    if (line.startsWith("UserID")) {
                        lines.add(line); // It's a header, keep it
                        isFirstLine = false;
                        continue;
                    } else {
                        // First line is NOT a header - process it as data
                        isFirstLine = false;
                        // DON'T continue - process this line
                    }
                }
                
                String[] parts = line.split(",");
                if (parts.length >= 6 && parts[0].equals(userId)) {
                    // Update this user's record
                    String password = (newPassword != null && !newPassword.isEmpty()) 
                        ? newPassword : parts[1];
                    String name = (newName != null && !newName.isEmpty()) 
                        ? newName : parts[2];
                    String email = (newEmail != null && !newEmail.isEmpty()) 
                        ? newEmail : parts[3];
                    String contact = (newContact != null && !newContact.isEmpty()) 
                        ? newContact : parts[4];
                    
                    String updatedLine = parts[0] + "," + password + "," + name + "," + 
                                       email + "," + contact + "," + parts[5];
                    lines.add(updatedLine);
                    updated = true;
                } else {
                    lines.add(line);
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading users.txt: " + e.getMessage());
            return false;
        }
        
        // Write back to file
        if (updated) {
            try (BufferedWriter writer = new BufferedWriter(new FileWriter("data_files/users.txt"))) {
                for (String line : lines) {
                    writer.write(line);
                    writer.newLine();
                }
                return true;
            } catch (IOException e) {
                System.err.println("Error writing users.txt: " + e.getMessage());
                return false;
            }
        }
        
        return false;
    }
}
