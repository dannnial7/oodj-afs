package afs.repo;

import afs.model.EnrollmentRecord;
import afs.storage.AppPaths;
import afs.storage.TextFile;

import java.util.ArrayList;
import java.util.List;

public class EnrollmentRepository {
    public List<EnrollmentRecord> load() {
        List<EnrollmentRecord> list = new ArrayList<>();
        List<String[]> rows = TextFile.readAll(AppPaths.dataDir().resolve("enrollments.txt"), 3);
        for (String[] r : rows) {
            if ("StudentID".equalsIgnoreCase(r[0])) {
                continue;
            }
            list.add(new EnrollmentRecord(r[0], r[1], r[2]));
        }
        return list;
    }
}
