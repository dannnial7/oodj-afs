package afs.repo;

import afs.model.Module;
import afs.storage.AppPaths;
import afs.storage.TextFile;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ModuleRepository {
    public List<Module> load() {
        List<Module> modules = new ArrayList<>();
        List<String[]> rows = TextFile.readAll(AppPaths.modulesFile(), 3);
        for (String[] r : rows) {
            if ("ModuleID".equalsIgnoreCase(r[0])) {
                continue;
            }
            modules.add(new Module(r[0], r[1], r[2]));
        }
        return modules;
    }

    public void save(List<Module> modules) throws IOException {
        List<String[]> rows = new ArrayList<>();
        for (Module m : modules) {
            rows.add(new String[]{m.getModuleId(), m.getModuleName(), m.getLecturerId()});
        }
        TextFile.writeAll(AppPaths.modulesFile(), rows);
    }
}
