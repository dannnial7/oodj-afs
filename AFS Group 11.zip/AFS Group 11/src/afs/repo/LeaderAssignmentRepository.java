package afs.repo;

import afs.model.LeaderAssignment;
import afs.storage.AppPaths;
import afs.storage.TextFile;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class LeaderAssignmentRepository {
    public List<LeaderAssignment> load() {
        List<LeaderAssignment> items = new ArrayList<>();
        List<String[]> rows = TextFile.readAll(AppPaths.leaderAssignmentsFile(), 2);
        for (String[] r : rows) {
            if ("LeaderID".equalsIgnoreCase(r[0]) || "AcademicLeaderID".equalsIgnoreCase(r[0])) {
                continue;
            }
            items.add(new LeaderAssignment(r[0], r[1]));
        }
        return items;
    }

    public void save(List<LeaderAssignment> items) throws IOException {
        List<String[]> rows = new ArrayList<>();
        for (LeaderAssignment la : items) {
            rows.add(new String[]{la.leaderId, la.lecturerId});
        }
        TextFile.writeAll(AppPaths.leaderAssignmentsFile(), rows);
    }
}
