package afs.repo;

import afs.model.ClassEnrollment;
import afs.storage.AppPaths;
import afs.storage.TextFile;

import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class ClassEnrollmentRepository {
    private Path file() {
        return AppPaths.dataDir().resolve("class_enrollments.txt");
    }

    public List<ClassEnrollment> load() {
        List<ClassEnrollment> list = new ArrayList<>();
        List<String[]> rows = TextFile.readAll(file(), 3);
        for (String[] r : rows) {
            if ("ClassID".equalsIgnoreCase(r[0])) {
                continue;
            }
            list.add(new ClassEnrollment(r[0], r[1], r[2]));
        }
        return list;
    }

    public void save(List<ClassEnrollment> list) throws IOException {
        List<String[]> rows = new ArrayList<>();
        for (ClassEnrollment c : list) {
            rows.add(new String[]{c.getClassId(), c.getStudentId(), c.getEnrollmentDate()});
        }
        TextFile.writeAll(file(), rows);
    }
}
