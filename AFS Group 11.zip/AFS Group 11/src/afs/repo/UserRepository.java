package afs.repo;

import afs.model.GeneralUser;
import afs.model.Lecturer;
import afs.model.Student;
import afs.model.User;
import afs.storage.AppPaths;
import afs.storage.TextFile;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class UserRepository {
    public List<User> load() {
        List<User> users = new ArrayList<>();
        List<String[]> rows = TextFile.readAll(AppPaths.usersFile(), 6);
        for (String[] r : rows) {
            if ("UserID".equalsIgnoreCase(r[0])) {
                continue;
            }
            String userId = r[0];
            String password = r[1];
            String name = r[2];
            String email = r[3];
            String contact = r[4];
            String role = r[5];

            if ("Lecturer".equalsIgnoreCase(role)) {
                users.add(new Lecturer(userId, password, name, email, contact));
            } else if ("Student".equalsIgnoreCase(role)) {
                users.add(new Student(userId, password, name, email, contact));
            } else {
                users.add(new GeneralUser(userId, password, name, email, contact, role));
            }
        }
        return users;
    }

    public void save(List<User> users) throws IOException {
        List<String[]> rows = new ArrayList<>();
        for (User u : users) {
            rows.add(new String[]{
                    u.getUserId(),
                    u.getPassword(),
                    u.getName(),
                    u.getEmail(),
                    u.getContactNum(),
                    u.getRole()
            });
        }
        TextFile.writeAll(AppPaths.usersFile(), rows);
    }
}
