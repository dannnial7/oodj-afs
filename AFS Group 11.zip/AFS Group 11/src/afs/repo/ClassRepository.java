package afs.repo;

import afs.model.ClassRecord;
import afs.storage.AppPaths;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class ClassRepository {
    private Path file() {
        return AppPaths.dataDir().resolve("classes.txt");
    }

    public List<ClassRecord> load() {
        List<ClassRecord> list = new ArrayList<>();
        Path p = file();
        if (!Files.exists(p)) {
            return list;
        }
        try {
            List<String> lines = Files.readAllLines(p, StandardCharsets.UTF_8);
            for (String line : lines) {
                if (line == null) continue;
                line = line.trim();
                if (line.isEmpty()) continue;
                String[] r = line.split(",", -1);
                if ("ClassID".equalsIgnoreCase(r[0])) continue;

                if (r.length >= 6) {
                    // Backward-compatible read for old format:
                    // ClassID,ModuleID,ClassName,Schedule,Room,Intake
                    list.add(new ClassRecord(r[0], r[1], r[2], r[5]));
                } else if (r.length == 4) {
                    // New format: ClassID,ModuleID,ClassName,Intake
                    list.add(new ClassRecord(r[0], r[1], r[2], r[3]));
                }
            }
        } catch (IOException ignored) {
        }
        return list;
    }

    public void save(List<ClassRecord> list) throws IOException {
        List<String[]> rows = new ArrayList<>();
        for (ClassRecord c : list) {
            rows.add(new String[]{c.getClassId(), c.getModuleId(), c.getClassName(), c.getIntake()});
        }
        afs.storage.TextFile.writeAll(file(), rows);
    }
}
