package afs.repo;

import afs.model.GradeBand;
import afs.storage.AppPaths;
import afs.storage.TextFile;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class GradingRepository {
    public List<GradeBand> load() {
        List<GradeBand> items = new ArrayList<>();
        List<String[]> rows = TextFile.readAll(AppPaths.gradingFile(), 3);
        for (String[] r : rows) {
            if ("Grade".equalsIgnoreCase(r[0])) {
                continue;
            }
            try {
                int min = Integer.parseInt(r[1]);
                int max = Integer.parseInt(r[2]);
                items.add(new GradeBand(r[0], min, max));
            } catch (NumberFormatException ignored) {
            }
        }
        return items;
    }

    public void save(List<GradeBand> items) throws IOException {
        List<String[]> rows = new ArrayList<>();
        for (GradeBand g : items) {
            rows.add(new String[]{g.grade, String.valueOf(g.min), String.valueOf(g.max)});
        }
        TextFile.writeAll(AppPaths.gradingFile(), rows);
    }
}
