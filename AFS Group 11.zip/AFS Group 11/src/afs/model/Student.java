package afs.model;

import java.util.ArrayList;
import java.util.List;
import afs.data.FileHandler;

public class Student extends User {
    private List<String> enrolledModules;
    private List<String> gradesReceived;
    private List<String> feedbackReceived;

    public Student(String userId, String password, String name, 
                  String email, String contactNum) {
        super(userId, password, name, email, contactNum, "Student");
        this.enrolledModules = new ArrayList<>();
        this.gradesReceived = new ArrayList<>();
        this.feedbackReceived = new ArrayList<>();
    }

    // Register for class (Use Case: Register for Classes)
    public void registerForModule(String moduleId) {
        if (!enrolledModules.contains(moduleId)) {
            enrolledModules.add(moduleId);
            System.out.println("✓ Registered for module: " + moduleId);
        }
    }

    // Check individual results (Use Case: Check Individual Results)
    public String checkResults() {
        StringBuilder results = new StringBuilder();
        results.append("=== YOUR RESULTS ===\n");
        results.append("Student: ").append(getName()).append(" (").append(getUserId()).append(")\n");
        results.append("Enrolled Modules: ").append(enrolledModules.size()).append("\n");
        results.append("Grades Received: ").append(gradesReceived.size()).append("\n");
        results.append("Feedback Received: ").append(feedbackReceived.size()).append("\n");
        
        if (!gradesReceived.isEmpty()) {
            results.append("\nGrades:\n");
            for (String grade : gradesReceived) {
                results.append("  - ").append(grade).append("\n");
            }
        }
        
        if (!feedbackReceived.isEmpty()) {
            results.append("\nFeedback:\n");
            for (String feedback : feedbackReceived) {
                results.append("  - ").append(feedback).append("\n");
            }
        }
        
        System.out.println(results.toString());
        return results.toString();
    }

    // Provide comments for lecturers (Use Case: Provide Comments for Lecturers)
    public void provideComment(String lecturerId, String comment) {
        String commentData = "Comment to " + lecturerId + ": " + comment + " (" + java.time.LocalDate.now() + ")";
        System.out.println("✓ Comment provided: " + commentData);
    }

    // Edit profile (Use Case: Edit Profile)
    public boolean editProfile(String newName, String newEmail, 
                              String newContact, String newPassword) {
        boolean fileUpdated = FileHandler.updateUserProfile(
            getUserId(), newName, newEmail, newContact, newPassword);
        
        if (fileUpdated) {
            // Update the object in memory too
            if (newName != null && !newName.isEmpty()) setName(newName);
            if (newEmail != null && !newEmail.isEmpty()) setEmail(newEmail);
            if (newContact != null && !newContact.isEmpty()) setContactNum(newContact);
            if (newPassword != null && !newPassword.isEmpty()) setPassword(newPassword);
            
            System.out.println("✓ Profile updated for student: " + getUserId());
            return true;
        } else {
            System.out.println("✗ Failed to update profile in file for: " + getUserId());
            return false;
        }
    }

    // Add grade
    public void addGrade(String gradeInfo) {
        gradesReceived.add(gradeInfo);
    }

    // Add feedback
    public void addFeedback(String feedbackInfo) {
        feedbackReceived.add(feedbackInfo);
    }

    // Getters
    public List<String> getEnrolledModules() { return new ArrayList<>(enrolledModules); }
    public List<String> getGradesReceived() { return new ArrayList<>(gradesReceived); }
    public List<String> getFeedbackReceived() { return new ArrayList<>(feedbackReceived); }
}