package afs.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import afs.data.FileHandler;
import java.io.*;

public class Lecturer extends User {
    private List<String> modulesTeaching;
    private List<String> assessmentsCreated;

    public Lecturer(String userId, String password, String name, 
                   String email, String contactNum) {
        super(userId, password, name, email, contactNum, "Lecturer");
        this.modulesTeaching = new ArrayList<>();
        this.assessmentsCreated = new ArrayList<>();
    }

    // Design assessment (Use Case: Design Assessment Types) - FIXED
    public String designAssessment(String moduleId, String description, 
                                  int maxMarks, String dueDate) {
        // Generate a simple ID
        String assessmentId = "ASS" + (System.currentTimeMillis() % 10000);
        
        // Store in list
        assessmentsCreated.add(assessmentId);
        
        System.out.println("✓ Assessment designed: " + description + " (ID: " + assessmentId + ")");
        
        // Return the data that would be saved to file
        return assessmentId + "," + moduleId + "," + description + "," +
               maxMarks + "," + dueDate + "," + getUserId();
    }

    // Enter marks (Use Case: Enter Assessment Marks) - FIXED
    public String enterMarks(String assessmentId, String studentId, int marks) {
    String marksEntry = assessmentId + "," + studentId + "," + marks + "," +
                       getUserId() + "," + java.time.LocalDate.now();
    System.out.println("✓ Marks entered: " + studentId + " -> " + marks);
    return marksEntry;
}

    // Provide feedback (Use Case: Provide Feedback) - FIXED
    public String provideFeedback(String assessmentId, String studentId, 
                                 String comment, String rating) {
        String feedbackId = "FB" + (System.currentTimeMillis() % 10000);
        System.out.println("✓ Feedback provided to " + studentId + ": " + comment);
        
        // Return data for file storage
        return feedbackId + "," + assessmentId + "," + studentId + "," + 
               getUserId() + "," + comment + "," + rating + "," + java.time.LocalDate.now();
    }

    // ===== UPDATED REPORT METHODS FOR TABLE FORMAT =====
    
    // View reports - returns formatted text (for backward compatibility)
    public String viewReports() {
        return generateFormattedReport();
    }
    
    // New method: Get report data as structured objects for tables
    public Map<String, Object> getReportData() {
        Map<String, Object> reportData = new HashMap<>();
        
        // 1. Basic lecturer info
        reportData.put("lecturerName", getName());
        reportData.put("lecturerId", getUserId());
        
        // 2. Get actual modules from file
        List<Module> actualModules = FileHandler.loadLecturerModules(getUserId());
        reportData.put("modules", actualModules);
        reportData.put("moduleCount", actualModules.size());
        
        // 3. Get assessments from file
        List<Map<String, String>> assessments = getLecturerAssessments();
        reportData.put("assessments", assessments);
        reportData.put("assessmentCount", assessments.size());
        
        // 4. Get marks summary
        Map<String, Object> marksSummary = getMarksSummary();
        reportData.put("marksSummary", marksSummary);
        
        // 5. Get student performance
        List<Map<String, Object>> studentPerformance = getStudentPerformance();
        reportData.put("studentPerformance", studentPerformance);
        
        return reportData;
    }
    
    // Helper: Get lecturer assessments with details
    private List<Map<String, String>> getLecturerAssessments() {
        List<Map<String, String>> assessments = new ArrayList<>();
        
        try {
            File file = new File("data_files/assessments.txt");
            if (!file.exists()) {
                return assessments;
            }
            
            BufferedReader br = new BufferedReader(new FileReader(file));
            String line;
            boolean isFirstLine = true;
            
            while ((line = br.readLine()) != null) {
                if (isFirstLine && line.startsWith("AssessmentID")) {
                    isFirstLine = false;
                    continue;
                }
                isFirstLine = false;
                
                String[] parts = line.split(",");
                if (parts.length >= 6 && parts[5].equals(getUserId())) {
                    Map<String, String> assessment = new HashMap<>();
                    assessment.put("id", parts[0]);
                    assessment.put("moduleId", parts.length > 1 ? parts[1] : "N/A");
                    assessment.put("description", parts.length > 2 ? parts[2] : "N/A");
                    assessment.put("maxMarks", parts.length > 3 ? parts[3] : "0");
                    assessment.put("dueDate", parts.length > 4 ? parts[4] : "N/A");
                    assessment.put("creatorId", parts[5]);
                    
                    assessments.add(assessment);
                }
            }
            br.close();
        } catch (Exception e) {
            System.err.println("Error reading assessments: " + e.getMessage());
        }
        
        return assessments;
    }
    
    // Helper: Get marks summary
    private Map<String, Object> getMarksSummary() {
        Map<String, Object> summary = new HashMap<>();
        int totalEntries = 0;
        int totalMarks = 0;
        int passCount = 0;
        int failCount = 0;
        
        try {
            File file = new File("data_files/results.txt");
            if (!file.exists()) {
                summary.put("totalEntries", 0);
                summary.put("averageMarks", 0.0);
                summary.put("passRate", 0.0);
                return summary;
            }
            
            BufferedReader br = new BufferedReader(new FileReader(file));
            String line;
            boolean isFirstLine = true;
            
            while ((line = br.readLine()) != null) {
                if (isFirstLine && line.startsWith("StudentID")) {
                    isFirstLine = false;
                    continue;
                }
                isFirstLine = false;
                
                String[] parts = line.split(",");
                if (parts.length >= 7 && parts[6].equals(getUserId())) {
                    if (parts.length >= 4) {
                        try {
                            int marks = Integer.parseInt(parts[3]);
                            totalEntries++;
                            totalMarks += marks;
                            
                            if (marks >= 40) {
                                passCount++;
                            } else {
                                failCount++;
                            }
                        } catch (NumberFormatException e) {
                            // Skip invalid marks
                        }
                    }
                }
            }
            br.close();
            
            double averageMarks = totalEntries > 0 ? (double) totalMarks / totalEntries : 0.0;
            double passRate = totalEntries > 0 ? (double) passCount / totalEntries * 100 : 0.0;
            
            summary.put("totalEntries", totalEntries);
            summary.put("totalMarks", totalMarks);
            summary.put("averageMarks", Math.round(averageMarks * 100.0) / 100.0);
            summary.put("passCount", passCount);
            summary.put("failCount", failCount);
            summary.put("passRate", Math.round(passRate * 100.0) / 100.0);
            
        } catch (Exception e) {
            System.err.println("Error reading marks: " + e.getMessage());
            summary.put("totalEntries", 0);
            summary.put("averageMarks", 0.0);
            summary.put("passRate", 0.0);
        }
        
        return summary;
    }
    
    // Helper: Get student performance data
    private List<Map<String, Object>> getStudentPerformance() {
        List<Map<String, Object>> performance = new ArrayList<>();
        
        try {
            File file = new File("data_files/results.txt");
            if (!file.exists()) {
                return performance;
            }
            
            BufferedReader br = new BufferedReader(new FileReader(file));
            String line;
            boolean isFirstLine = true;
            
            // First pass: collect all student data
            Map<String, List<Integer>> studentMarksMap = new HashMap<>();
            Map<String, Integer> studentAssessmentCount = new HashMap<>();
            
            while ((line = br.readLine()) != null) {
                if (isFirstLine && line.startsWith("StudentID")) {
                    isFirstLine = false;
                    continue;
                }
                isFirstLine = false;
                
                String[] parts = line.split(",");
                if (parts.length >= 7 && parts[6].equals(getUserId())) {
                    if (parts.length >= 4) {
                        try {
                            String studentId = parts[0];
                            int marks = Integer.parseInt(parts[3]);
                            
                            // Add marks to student's list
                            if (!studentMarksMap.containsKey(studentId)) {
                                studentMarksMap.put(studentId, new ArrayList<>());
                            }
                            studentMarksMap.get(studentId).add(marks);
                            
                            // Count assessments per student
                            studentAssessmentCount.put(studentId, 
                                studentAssessmentCount.getOrDefault(studentId, 0) + 1);
                        } catch (NumberFormatException e) {
                            // Skip invalid marks
                        }
                    }
                }
            }
            br.close();
            
            // Second pass: calculate statistics for each student
            for (Map.Entry<String, List<Integer>> entry : studentMarksMap.entrySet()) {
                String studentId = entry.getKey();
                List<Integer> marksList = entry.getValue();
                
                if (!marksList.isEmpty()) {
                    Map<String, Object> studentData = new HashMap<>();
                    
                    // Calculate statistics
                    int total = 0;
                    int min = Integer.MAX_VALUE;
                    int max = Integer.MIN_VALUE;
                    int passCount = 0;
                    
                    for (int marks : marksList) {
                        total += marks;
                        if (marks < min) min = marks;
                        if (marks > max) max = marks;
                        if (marks >= 40) passCount++;
                    }
                    
                    double average = (double) total / marksList.size();
                    double passRate = (double) passCount / marksList.size() * 100;
                    
                    // Get student name if available
                    String studentName = getStudentName(studentId);
                    
                    studentData.put("studentId", studentId);
                    studentData.put("studentName", studentName);
                    studentData.put("assessmentCount", studentAssessmentCount.get(studentId));
                    studentData.put("averageMarks", Math.round(average * 100.0) / 100.0);
                    studentData.put("minMarks", min);
                    studentData.put("maxMarks", max);
                    studentData.put("passRate", Math.round(passRate * 100.0) / 100.0);
                    studentData.put("status", average >= 40 ? "PASSING" : "NEEDS HELP");
                    
                    performance.add(studentData);
                }
            }
            
        } catch (Exception e) {
            System.err.println("Error calculating student performance: " + e.getMessage());
        }
        
        return performance;
    }
    
    // Helper: Get student name from users.txt
    private String getStudentName(String studentId) {
        try {
            File file = new File("data_files/users.txt");
            if (!file.exists()) {
                return "Unknown";
            }
            
            BufferedReader br = new BufferedReader(new FileReader(file));
            String line;
            boolean isFirstLine = true;
            
            while ((line = br.readLine()) != null) {
                if (isFirstLine && line.startsWith("UserID")) {
                    isFirstLine = false;
                    continue;
                }
                isFirstLine = false;
                
                String[] parts = line.split(",");
                if (parts.length >= 6 && parts[0].equals(studentId) && parts[5].equals("Student")) {
                    br.close();
                    return parts.length > 2 ? parts[2] : "Unknown";
                }
            }
            br.close();
        } catch (Exception e) {
            System.err.println("Error getting student name: " + e.getMessage());
        }
        
        return "Unknown";
    }
    
    // Original formatted report method (for backward compatibility)
    private String generateFormattedReport() {
        Map<String, Object> data = getReportData();
        
        StringBuilder report = new StringBuilder();
        report.append("=== LECTURER REPORT ===\n");
        report.append("Name: ").append(data.get("lecturerName")).append("\n");
        report.append("ID: ").append(data.get("lecturerId")).append("\n");
        report.append("Modules Teaching: ").append(data.get("moduleCount")).append("\n");
        report.append("Assessments Created: ").append(data.get("assessmentCount")).append("\n");
        
        @SuppressWarnings("unchecked")
        List<Module> modules = (List<Module>) data.get("modules");
        if (!modules.isEmpty()) {
            report.append("\n=== MODULES TEACHING ===\n");
            for (Module module : modules) {
                report.append("  • ").append(module.getModuleId())
                      .append(": ").append(module.getModuleName()).append("\n");
            }
        }
        
        @SuppressWarnings("unchecked")
        List<Map<String, String>> assessments = (List<Map<String, String>>) data.get("assessments");
        if (!assessments.isEmpty()) {
            report.append("\n=== ALL ASSESSMENTS CREATED ===\n");
            for (Map<String, String> assessment : assessments) {
                report.append("  • ").append(assessment.get("id"))
                      .append(": ").append(assessment.get("description"))
                      .append(" (").append(assessment.get("moduleId"))
                      .append(") - Due: ").append(assessment.get("dueDate")).append("\n");
            }
        }
        
        @SuppressWarnings("unchecked")
        Map<String, Object> marksSummary = (Map<String, Object>) data.get("marksSummary");
        report.append("\n=== MARKS SUMMARY ===\n");
        report.append("Total Marks Entered: ").append(marksSummary.get("totalEntries")).append("\n");
        report.append("Average Marks: ").append(marksSummary.get("averageMarks")).append("\n");
        report.append("Pass Rate: ").append(marksSummary.get("passRate")).append("%\n");
        
        report.append("\n=== SUMMARY ===\n");
        report.append("Total Modules: ").append(data.get("moduleCount")).append("\n");
        report.append("Total Assessments: ").append(data.get("assessmentCount")).append("\n");
        report.append("Total Marks Entries: ").append(marksSummary.get("totalEntries")).append("\n");
        
        return report.toString();
    }

    // Edit profile (Use Case: Edit Profile) - FIXED
    public boolean editProfile(String newName, String newEmail, 
                              String newContact, String newPassword) {
        boolean fileUpdated = FileHandler.updateUserProfile(
            getUserId(), newName, newEmail, newContact, newPassword);
        
        if (fileUpdated) {
            // Update the object in memory too
            if (newName != null && !newName.isEmpty()) setName(newName);
            if (newEmail != null && !newEmail.isEmpty()) setEmail(newEmail);
            if (newContact != null && !newContact.isEmpty()) setContactNum(newContact);
            if (newPassword != null && !newPassword.isEmpty()) setPassword(newPassword);
            
            System.out.println("✓ Profile updated for lecturer: " + getUserId());
            return true;
        } else {
            System.out.println("✗ Failed to update profile in file for: " + getUserId());
            return false;
        }
    }

    // Add module to teaching list
    public void addModule(String moduleId) {
        if (!modulesTeaching.contains(moduleId)) {
            modulesTeaching.add(moduleId);
            System.out.println("✓ Module added to teaching: " + moduleId);
        }
    }

    // Getters
    public List<String> getModulesTeaching() { return new ArrayList<>(modulesTeaching); }
    public List<String> getAssessmentsCreated() { return new ArrayList<>(assessmentsCreated); }
    
    // New getters for report data
    public int getModuleCount() {
        return FileHandler.loadLecturerModules(getUserId()).size();
    }
    
    public int getAssessmentCount() {
        return getLecturerAssessments().size();
    }
    
    public int getMarksEntryCount() {
        Map<String, Object> summary = getMarksSummary();
        return (int) summary.get("totalEntries");
    }
    
    public double getAverageMarks() {
        Map<String, Object> summary = getMarksSummary();
        return (double) summary.get("averageMarks");
    }
}