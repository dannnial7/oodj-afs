package afs.model;

public abstract class User {
    private String userId;
    private String password;
    private String name;
    private String email;
    private String contactNum;
    private String role;

    public User(String userId, String password, String name, 
                String email, String contactNum, String role) {
        this.userId = userId;
        this.password = password;
        this.name = name;
        this.email = email;
        this.contactNum = contactNum;
        this.role = role;
    }

    // Getters
    public String getUserId() { return userId; }
    public String getPassword() { return password; }
    public String getName() { return name; }
    public String getEmail() { return email; }
    public String getContactNum() { return contactNum; }
    public String getRole() { return role; }

    // Setters for profile editing
    public void setName(String name) { this.name = name; }
    public void setEmail(String email) { this.email = email; }
    public void setContactNum(String contactNum) { this.contactNum = contactNum; }
    public void setPassword(String password) { this.password = password; }

    // Authentication
    public boolean authenticate(String inputPassword) {
        return this.password.equals(inputPassword);
    }

    // For file storage
    public String toFileString() {
        return userId + "," + password + "," + name + "," + 
               email + "," + contactNum + "," + role;
    }
    
    @Override
    public String toString() {
        return name + " (" + userId + " - " + role + ")";
    }
}