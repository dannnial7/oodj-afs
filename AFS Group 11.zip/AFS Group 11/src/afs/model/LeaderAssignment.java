package afs.model;

public class LeaderAssignment {
    public final String leaderId;
    public final String lecturerId;

    public LeaderAssignment(String leaderId, String lecturerId) {
        this.leaderId = leaderId;
        this.lecturerId = lecturerId;
    }
}
