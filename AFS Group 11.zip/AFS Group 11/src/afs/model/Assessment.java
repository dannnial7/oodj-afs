package afs.model;

public class Assessment {
    private String assessmentId;
    private String moduleId;
    private String description;
    private int maxMarks;
    private String dueDate;
    private String createdBy; // Lecturer ID

    public Assessment(String assessmentId, String moduleId, String description, 
                     int maxMarks, String dueDate, String createdBy) {
        this.assessmentId = assessmentId;
        this.moduleId = moduleId;
        this.description = description;
        this.maxMarks = maxMarks;
        this.dueDate = dueDate;
        this.createdBy = createdBy;
    }

    // Getters
    public String getAssessmentId() { return assessmentId; }
    public String getModuleId() { return moduleId; }
    public String getDescription() { return description; }
    public int getMaxMarks() { return maxMarks; }
    public String getDueDate() { return dueDate; }
    public String getCreatedBy() { return createdBy; }

    // For file storage
    public String toFileString() {
        return assessmentId + "," + moduleId + "," + description + "," + 
               maxMarks + "," + dueDate + "," + createdBy;
    }

    @Override
    public String toString() {
        return assessmentId + ": " + description + " (" + moduleId + ")";
    }
}