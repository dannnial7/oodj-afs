package afs.model;

public class Module {
    private String moduleId;
    private String moduleName;
    private String lecturerId;

    public Module(String moduleId, String moduleName, String lecturerId) {
        this.moduleId = moduleId;
        this.moduleName = moduleName;
        this.lecturerId = lecturerId;
    }

    // Getters
    public String getModuleId() { return moduleId; }
    public String getModuleName() { return moduleName; }
    public String getLecturerId() { return lecturerId; }

    @Override
    public String toString() {
        return moduleId + " - " + moduleName + " (Lecturer: " + lecturerId + ")";
    }

}