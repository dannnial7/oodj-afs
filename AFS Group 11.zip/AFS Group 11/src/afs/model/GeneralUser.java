package afs.model;

public class GeneralUser extends User {
    public GeneralUser(String userId, String password, String name,
                       String email, String contactNum, String role) {
        super(userId, password, name, email, contactNum, role);
    }
}
