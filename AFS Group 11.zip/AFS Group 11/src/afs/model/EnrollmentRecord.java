package afs.model;

public class EnrollmentRecord {
    private final String studentId;
    private final String moduleId;
    private final String enrollmentDate;

    public EnrollmentRecord(String studentId, String moduleId, String enrollmentDate) {
        this.studentId = studentId;
        this.moduleId = moduleId;
        this.enrollmentDate = enrollmentDate;
    }

    public String getStudentId() { return studentId; }
    public String getModuleId() { return moduleId; }
    public String getEnrollmentDate() { return enrollmentDate; }
}
