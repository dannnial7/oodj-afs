package afs.model;

public class ClassRecord {
    private final String classId;
    private final String moduleId;
    private final String className;
    private final String intake;

    public ClassRecord(String classId, String moduleId, String className, String intake) {
        this.classId = classId;
        this.moduleId = moduleId;
        this.className = className;
        this.intake = intake;
    }

    public String getClassId() { return classId; }
    public String getModuleId() { return moduleId; }
    public String getClassName() { return className; }
    public String getIntake() { return intake; }
}
