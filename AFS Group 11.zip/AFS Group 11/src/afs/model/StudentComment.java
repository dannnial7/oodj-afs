package afs.model;

import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class StudentComment {
    private String studentId;
    private String lecturerId;
    private String moduleId;
    private String comment;
    private String dateTime;

    // Constructor for new comments
    public StudentComment(String studentId, String lecturerId, String moduleId, String comment) {
        this.studentId = studentId;
        this.lecturerId = lecturerId;
        this.moduleId = moduleId;
        this.comment = comment;
        this.dateTime = LocalDateTime.now().format(
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
    }

    // Constructor for reading from file
    public StudentComment(String studentId, String lecturerId, String moduleId,
                         String comment, String dateTime) {
        this.studentId = studentId;
        this.lecturerId = lecturerId;
        this.moduleId = moduleId;
        this.comment = comment;
        this.dateTime = dateTime;
    }

    // Save comment to file
    public boolean save() {
        try (BufferedWriter writer = new BufferedWriter(
                new FileWriter("data_files/comments.txt", true))) {

            File file = new File("data_files/comments.txt");
            if (file.length() == 0) {
                writer.write("StudentID,LecturerID,ModuleID,Comment,Date/Time");
                writer.newLine();
            }

            writer.write(toFileString());
            writer.newLine();
            return true;
        } catch (IOException e) {
            System.err.println("Error saving comment: " + e.getMessage());
            return false;
        }
    }

    // Load all comments for a lecturer
    public static List<StudentComment> loadComments(String lecturerId) {
        List<StudentComment> comments = new ArrayList<>();
        File file = new File("data_files/comments.txt");

        if (!file.exists()) return comments;

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            boolean isFirstLine = true;

            while ((line = br.readLine()) != null) {
                if (isFirstLine && line.startsWith("StudentID")) {
                    isFirstLine = false;
                    continue;
                }
                isFirstLine = false;

                String[] parts = line.split(",", 5);
                if (parts.length >= 5) {
                    String entryLecturerId = parts[1].trim();
                    if (entryLecturerId.equals(lecturerId)) {
                        comments.add(new StudentComment(
                            parts[0].trim(),
                            parts[1].trim(),
                            parts[2].trim(),
                            parts[3].trim(),
                            parts[4].trim()
                        ));
                    }
                }
            }
        } catch (IOException e) {
            System.err.println("Error loading comments: " + e.getMessage());
        }

        return comments;
    }

    // Load comments for a specific student
    public static List<StudentComment> loadCommentsForStudent(String studentId) {
        List<StudentComment> comments = new ArrayList<>();
        File file = new File("data_files/comments.txt");

        if (!file.exists()) return comments;

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            boolean isFirstLine = true;

            while ((line = br.readLine()) != null) {
                if (isFirstLine && line.startsWith("StudentID")) {
                    isFirstLine = false;
                    continue;
                }
                isFirstLine = false;

                String[] parts = line.split(",", 5);
                if (parts.length >= 5 && parts[0].trim().equals(studentId)) {
                    comments.add(new StudentComment(
                        parts[0].trim(),
                        parts[1].trim(),
                        parts[2].trim(),
                        parts[3].trim(),
                        parts[4].trim()
                    ));
                }
            }
        } catch (IOException e) {
            System.err.println("Error loading comments: " + e.getMessage());
        }

        return comments;
    }

    // Find specific comment by unique combination
    public static StudentComment findComment(String studentId, String moduleId, String dateTime) {
        List<StudentComment> comments = loadCommentsForStudent(studentId);
        for (StudentComment comment : comments) {
            if (comment.getModuleId().equals(moduleId) &&
                comment.getDateTime().equals(dateTime)) {
                return comment;
            }
        }
        return null;
    }

    // To file string
    public String toFileString() {
        return studentId + "," + lecturerId + "," + moduleId + "," +
               comment + "," + dateTime;
    }

    // Get truncated comment for display
    public String getShortComment(int maxLength) {
        if (comment.length() <= maxLength) return comment;
        return comment.substring(0, maxLength - 3) + "...";
    }

    // Getters
    public String getStudentId() { return studentId; }
    public String getLecturerId() { return lecturerId; }
    public String getModuleId() { return moduleId; }
    public String getComment() { return comment; }
    public String getDateTime() { return dateTime; }

    @Override
    public String toString() {
        return "StudentComment{" +
               "studentId='" + studentId + '\'' +
               ", lecturerId='" + lecturerId + '\'' +
               ", moduleId='" + moduleId + '\'' +
               ", dateTime='" + dateTime + '\'' +
               '}';
    }
}
