package afs.model;

public class GradeBand {
    public final String grade;
    public final int min;
    public final int max;

    public GradeBand(String grade, int min, int max) {
        this.grade = grade;
        this.min = min;
        this.max = max;
    }
}
