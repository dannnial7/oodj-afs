package afs.model;

public class ClassEnrollment {
    private final String classId;
    private final String studentId;
    private final String enrollmentDate;

    public ClassEnrollment(String classId, String studentId, String enrollmentDate) {
        this.classId = classId;
        this.studentId = studentId;
        this.enrollmentDate = enrollmentDate;
    }

    public String getClassId() { return classId; }
    public String getStudentId() { return studentId; }
    public String getEnrollmentDate() { return enrollmentDate; }
}
