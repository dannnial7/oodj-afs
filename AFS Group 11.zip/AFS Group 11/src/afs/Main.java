package afs;

import afs.storage.AppPaths;
import afs.ui.LoginFrame;

import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        AppPaths.dataDir();
        SwingUtilities.invokeLater(() -> {
            LoginFrame frame = new LoginFrame();
            frame.setVisible(true);
        });
    }
}
