/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Muhammad Aamer Ali
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class EditProfileFrame extends JFrame {
    private Student student;
    private JTextField nameField, emailField;
    private JPasswordField currentPassField, newPassField, confirmPassField;
    
    public EditProfileFrame(Student student) {
        this.student = student;
        
        setTitle("Edit Profile");
        setSize(500, 400);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        
        // Form Panel
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        // Student ID (read-only)
        gbc.gridx = 0; gbc.gridy = 0;
        formPanel.add(new JLabel("Student ID:"), gbc);
        gbc.gridx = 1;
        JTextField idField = new JTextField(student.getUserID());
        idField.setEditable(false);
        idField.setBackground(Color.LIGHT_GRAY);
        formPanel.add(idField, gbc);
        
        // Name
        gbc.gridx = 0; gbc.gridy = 1;
        formPanel.add(new JLabel("Name:"), gbc);
        gbc.gridx = 1;
        nameField = new JTextField(student.getName(), 20);
        formPanel.add(nameField, gbc);
        
        // Email
        gbc.gridx = 0; gbc.gridy = 2;
        formPanel.add(new JLabel("Email:"), gbc);
        gbc.gridx = 1;
        emailField = new JTextField(student.getEmail(), 20);
        formPanel.add(emailField, gbc);
        
        // Password Change Section
        JLabel passSection = new JLabel("Change Password (leave blank to keep current)");
        passSection.setFont(new Font("Arial", Font.BOLD, 12));
        passSection.setForeground(Color.DARK_GRAY);
        
        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2;
        formPanel.add(passSection, gbc);
        
        // Current Password
        gbc.gridwidth = 1; gbc.gridy = 4; gbc.gridx = 0;
        formPanel.add(new JLabel("Current Password:"), gbc);
        gbc.gridx = 1;
        currentPassField = new JPasswordField(20);
        formPanel.add(currentPassField, gbc);
        
        // New Password
        gbc.gridx = 0; gbc.gridy = 5;
        formPanel.add(new JLabel("New Password:"), gbc);
        gbc.gridx = 1;
        newPassField = new JPasswordField(20);
        formPanel.add(newPassField, gbc);
        
        // Confirm Password
        gbc.gridx = 0; gbc.gridy = 6;
        formPanel.add(new JLabel("Confirm Password:"), gbc);
        gbc.gridx = 1;
        confirmPassField = new JPasswordField(20);
        formPanel.add(confirmPassField, gbc);
        
        // Buttons Panel
        JPanel buttonPanel = new JPanel();
        JButton saveButton = new JButton("Save Changes");
        saveButton.setBackground(new Color(76, 175, 80));
        saveButton.setForeground(Color.WHITE);
        
        JButton cancelButton = new JButton("Cancel");
        cancelButton.setBackground(Color.LIGHT_GRAY);
        
        buttonPanel.add(saveButton);
        buttonPanel.add(cancelButton);
        
        // Add to frame
        add(formPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
        
        // Action Listeners
        saveButton.addActionListener(e -> saveProfile());
        cancelButton.addActionListener(e -> this.dispose());
    }
    
    private void saveProfile() {
        String name = nameField.getText().trim();
        String email = emailField.getText().trim();
        String currentPass = new String(currentPassField.getPassword());
        String newPass = new String(newPassField.getPassword());
        String confirmPass = new String(confirmPassField.getPassword());
        
        // Validate inputs
        if (name.isEmpty() || email.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Name and Email cannot be empty", 
                                         "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        if (!email.contains("@")) {
            JOptionPane.showMessageDialog(this, "Please enter a valid email address", 
                                         "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Check if changing password
        if (!newPass.isEmpty()) {
            // Verify current password
            if (!student.getPassword().equals(currentPass)) {
                JOptionPane.showMessageDialog(this, "Current password is incorrect", 
                                             "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            // Check if new passwords match
            if (!newPass.equals(confirmPass)) {
                JOptionPane.showMessageDialog(this, "New passwords do not match", 
                                             "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            // Update password
            student.setPassword(newPass);
        }
        
        // Update other fields
        student.setName(name);
        student.setEmail(email);
        
        // Save to file
        boolean success = FileManager.getInstance().updateStudentProfile(student);
        
        if (success) {
            JOptionPane.showMessageDialog(this, "Profile updated successfully!", 
                                         "Success", JOptionPane.INFORMATION_MESSAGE);
            this.dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Failed to update profile", 
                                         "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}