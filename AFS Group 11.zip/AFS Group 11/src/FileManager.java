/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Muhammad Aamer Ali
 */
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class FileManager {
    private static FileManager instance;
    private static final String DATA_FOLDER = "data_files/";
    
    // File name constants
    private static final String USERS_FILE = DATA_FOLDER + "users.txt";
    private static final String MODULES_FILE = DATA_FOLDER + "modules.txt";
    private static final String ENROLLMENTS_FILE = DATA_FOLDER + "enrollments.txt";
    private static final String RESULTS_FILE = DATA_FOLDER + "results.txt";
    private static final String COMMENTS_FILE = DATA_FOLDER + "comments.txt";
    private static final String NOTIFICATIONS_FILE = DATA_FOLDER + "notifications.txt";
    
    private FileManager() {
        createDataFolder();
        createSampleData();
    }
    
    public static FileManager getInstance() {
        if (instance == null) {
            instance = new FileManager();
        }
        return instance;
    }
    
    private void createDataFolder() {
        File folder = new File(DATA_FOLDER);
        if (!folder.exists()) {
            folder.mkdirs();
        }
    }
    
    private void createSampleData() {
        createFileIfNotExists(USERS_FILE, 
            "EMP001,pass000,Dr. Smith,smith.up@apu.edu.my,012-3456789,Lecturer\n" +
            "EMP002,pass456,Dr. Johnson,johnson.1@apu.edu.my,012-9876543,Lecturer\n" +
            "EMP003,pass789,Dr. Sarah Lim,sarah.lim@apu.edu.my,012-9998888,Lecturer\n" +
            "STU001,stu123,John Doe,john.doe@student.apu.edu.my,011-1111111,Student\n" +
            "STU002,stu456,Jane Tan,jane.tan@student.apu.edu.my,011-2222222,Student");
        
        createFileIfNotExists(MODULES_FILE,
            "CS101,Programming Basics,EMP001\n" +
            "CS102,Data Structures,EMP002\n" +
            "CS103,Object-Oriented Programming,EMP001\n" +
            "CS201,Database Systems,EMP003\n" +
            "CS202,Software Engineering,EMP002\n" +
            "CS301,Artificial Intelligence,EMP003\n" +
            "CS302,Mobile Development,EMP001");
        
        createFileIfNotExists(RESULTS_FILE,
            "ST001,CS221,Assignment 1,85,A,Excellent work! Good understanding of OOP concepts.,LEC001\n" +
            "ST001,CS221,Assignment 2,78,B+,Good attempt. Need to improve on inheritance concepts.,LEC001\n" +
            "ST001,CS222,Midterm Exam,92,A,Outstanding performance!,LEC001\n" +
            "ST002,CS221,Assignment 1,88,A,Well done! Keep it up.,LEC001");

        createFileIfNotExists(NOTIFICATIONS_FILE,
            "ST001,New feedback received for CS221 Assignment 2,false\n" +
            "ST001,Registration for Semester 2025-2 opens next week,false\n" +
            "ST002,Welcome to Assessment Feedback System!,false");
        
        // Create empty files
        createEmptyFileIfNotExists(ENROLLMENTS_FILE);
        createEmptyFileIfNotExists(COMMENTS_FILE);
    }
    
    private void createFileIfNotExists(String fileName, String content) {
        try {
            File file = new File(fileName);
            if (!file.exists()) {
                PrintWriter writer = new PrintWriter(file);
                writer.print(content);
                writer.close();
                System.out.println("Created: " + fileName);
            }
        } catch (IOException e) {
            System.out.println("Error creating " + fileName + ": " + e.getMessage());
        }
    }
    
    private void createEmptyFileIfNotExists(String fileName) {
        try {
            File file = new File(fileName);
            if (!file.exists()) {
                file.createNewFile();
                System.out.println("Created empty: " + fileName);
            }
        } catch (IOException e) {
            System.out.println("Error creating " + fileName + ": " + e.getMessage());
        }
    }
    
    // Student operations
    public Student getStudentByID(String studentID) {
        try (BufferedReader br = new BufferedReader(new FileReader(USERS_FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 6 && parts[0].equals(studentID) && parts[5].equals("Student")) {
                    return new Student(parts[0], parts[2], parts[3], parts[1]);
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading users: " + e.getMessage());
        }
        return null;
    }
    
    public boolean updateStudentProfile(Student student) {
        List<String> lines = new ArrayList<>();
        boolean updated = false;
        
        try (BufferedReader br = new BufferedReader(new FileReader(USERS_FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 6 && parts[0].equals(student.getUserID())) {
                    String contactNumber = parts[4];
                    String role = parts[5];
                    // Format: id,password,name,email,contactnumber,role
                    lines.add(student.getUserID() + "," + student.getPassword() + "," +
                              student.getName() + "," + student.getEmail() + "," +
                              contactNumber + "," + role);
                    updated = true;
                } else {
                    lines.add(line);
                }
            }
        } catch (IOException e) {
            System.out.println("Error updating user: " + e.getMessage());
            return false;
        }
        
        // Write back to file
        try (PrintWriter pw = new PrintWriter(new FileWriter(USERS_FILE))) {
            for (String line : lines) {
                pw.println(line);
            }
        } catch (IOException e) {
            System.out.println("Error writing users: " + e.getMessage());
            return false;
        }
        
        return updated;
    }
    
    // Module operations
    public ArrayList<Course> getAllModules() {
        ArrayList<Course> modules = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(MODULES_FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 3) {
                    modules.add(new Course(parts[0], parts[1], parts[2]));
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading modules: " + e.getMessage());
        }
        return modules;
    }

    // Backward-compatible alias
    public ArrayList<Course> getAllCourses() {
        return getAllModules();
    }
    
    // Enrollment operations
    public void saveEnrollment(Enrollment enrollment) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(ENROLLMENTS_FILE, true))) {
            pw.println(enrollment.toString());
        } catch (IOException e) {
            System.out.println("Error saving enrollment: " + e.getMessage());
        }
    }
    
    public ArrayList<Course> getEnrolledCourses(String studentID) {
        ArrayList<Course> enrolledCourses = new ArrayList<>();
        ArrayList<Course> allCourses = getAllCourses();
        Set<String> enrolledCourseCodes = new HashSet<>();
        
        try (BufferedReader br = new BufferedReader(new FileReader(ENROLLMENTS_FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 2 && parts[0].equals(studentID)) {
                    enrolledCourseCodes.add(parts[1]);
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading enrollments: " + e.getMessage());
        }
        
        // Find the actual course objects
        for (Course course : allCourses) {
            if (enrolledCourseCodes.contains(course.getCourseCode())) {
                enrolledCourses.add(course);
            }
        }
        
        return enrolledCourses;
    }
    
    public boolean isEnrolled(String studentID, String courseCode) {
        try (BufferedReader br = new BufferedReader(new FileReader(ENROLLMENTS_FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 2 && parts[0].equals(studentID) && parts[1].equals(courseCode)) {
                    return true;
                }
            }
        } catch (IOException e) {
            System.out.println("Error checking enrollment: " + e.getMessage());
        }
        return false;
    }
    
    public boolean removeEnrollment(String studentID, String courseCode) {
        try {
            File enrollmentFile = new File(ENROLLMENTS_FILE);
            
            if (!enrollmentFile.exists()) {
                System.out.println("DEBUG: Enrollment file not found");
                return false;
            }
            
            // Read all lines
            List<String> lines = new ArrayList<>();
            try (BufferedReader br = new BufferedReader(new FileReader(enrollmentFile))) {
                String line;
                while ((line = br.readLine()) != null) {
                    lines.add(line);
                }
            }
            
            List<String> updatedLines = new ArrayList<>();
            boolean removed = false;
            
            System.out.println("DEBUG: Removing enrollment - Student: " + studentID + ", Course: " + courseCode);
            
            for (String line : lines) {
                if (!line.trim().isEmpty()) {
                    String[] parts = line.split(",");
                    if (parts.length >= 2) {
                        String fileStudentID = parts[0].trim();
                        String fileCourseCode = parts[1].trim();
                        
                        // Skip if this is the enrollment to remove
                        if (fileStudentID.equals(studentID) && fileCourseCode.equals(courseCode)) {
                            System.out.println("DEBUG: Found and removing: " + line);
                            removed = true;
                            continue;
                        }
                    }
                    updatedLines.add(line);
                }
            }
            
            if (removed) {
                // Write back the updated lines
                try (PrintWriter pw = new PrintWriter(new FileWriter(enrollmentFile))) {
                    for (String line : updatedLines) {
                        pw.println(line);
                    }
                }
                System.out.println("DEBUG: Enrollment successfully removed");
                return true;
            } else {
                System.out.println("DEBUG: Enrollment not found for removal");
                return false;
            }
            
        } catch (IOException e) {
            System.err.println("ERROR removing enrollment: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    // Result operations
    public ArrayList<Result> loadResults(String studentID) {
        ArrayList<Result> results = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(RESULTS_FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length < 7) {
                    continue;
                }
                if ("StudentID".equalsIgnoreCase(parts[0].trim()) || "AssessmentID".equalsIgnoreCase(parts[0].trim())) {
                    continue;
                }
                try {
                    String rowStudentId = parts[0].trim();
                    if (!rowStudentId.equals(studentID)) {
                        continue;
                    }
                    results.add(new Result(
                        rowStudentId,
                        parts[1].trim(),
                        parts[2].trim(),
                        Double.parseDouble(parts[3].trim()),
                        parts[4].trim(),
                        parts[5].trim(),
                        parts[6].trim()
                    ));
                } catch (NumberFormatException e) {
                    System.out.println("Error parsing result row: " + line);
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading results: " + e.getMessage());
        }
        return results;
    }
    
    // Comment operations
    public boolean saveComment(Comment comment) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(COMMENTS_FILE, true))) {
            pw.println(comment.toString());
            return true;
        } catch (IOException e) {
            System.out.println("Error saving comment: " + e.getMessage());
            return false;
        }
    }
    
    public ArrayList<Comment> getCommentsForLecturer(String lecturerID) {
        ArrayList<Comment> comments = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(COMMENTS_FILE))) {
            String line;
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",", 5); // Split into max 5 parts
                if (parts.length >= 5 && parts[1].equals(lecturerID)) {
                    try {
                        comments.add(new Comment(parts[0], parts[1], parts[2], 
                                                parts[3], sdf.parse(parts[4])));
                    } catch (Exception e) {
                        System.out.println("Error parsing comment date: " + parts[4]);
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading comments: " + e.getMessage());
        }
        return comments;
    }
    
    // Notification operations (Extra Feature)
    public ArrayList<String> getNotificationsForStudent(String studentID) {
        ArrayList<String> notifications = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(NOTIFICATIONS_FILE))) {
            String line;
            int index = 0;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",", 3); // Split into 3 parts max
                if (parts.length >= 3 && parts[0].equals(studentID) && parts[2].equals("false")) {
                    notifications.add(parts[1]); // Add the notification message
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading notifications: " + e.getMessage());
        }
        return notifications;
    }
    
    public void markNotificationAsRead(String studentID, int notificationIndex) {
        List<String> lines = new ArrayList<>();
        int currentIndex = 0;
        
        try (BufferedReader br = new BufferedReader(new FileReader(NOTIFICATIONS_FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",", 3);
                if (parts.length >= 3 && parts[0].equals(studentID) && parts[2].equals("false")) {
                    if (currentIndex == notificationIndex) {
                        // Mark as read
                        lines.add(studentID + "," + parts[1] + ",true");
                    } else {
                        lines.add(line);
                    }
                    currentIndex++;
                } else {
                    lines.add(line);
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading notifications for update: " + e.getMessage());
            return;
        }
        
        // Write back to file
        try (PrintWriter pw = new PrintWriter(new FileWriter(NOTIFICATIONS_FILE))) {
            for (String line : lines) {
                pw.println(line);
            }
        } catch (IOException e) {
            System.out.println("Error writing notifications: " + e.getMessage());
        }
    }
    
    public void addNotification(String studentID, String message) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(NOTIFICATIONS_FILE, true))) {
            pw.println(studentID + "," + message + ",false");
        } catch (IOException e) {
            System.out.println("Error adding notification: " + e.getMessage());
        }
    }
    
    public void markAllNotificationsAsRead(String studentID) {
        List<String> lines = new ArrayList<>();
        
        try (BufferedReader br = new BufferedReader(new FileReader(NOTIFICATIONS_FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",", 3);
                if (parts.length >= 3 && parts[0].equals(studentID) && parts[2].equals("false")) {
                    // Mark as read
                    lines.add(studentID + "," + parts[1] + ",true");
                } else {
                    lines.add(line);
                }
            }
        } catch (IOException e) {
            System.out.println("Error marking all notifications as read: " + e.getMessage());
            return;
        }
        
        // Write back to file
        try (PrintWriter pw = new PrintWriter(new FileWriter(NOTIFICATIONS_FILE))) {
            for (String line : lines) {
                pw.println(line);
            }
        } catch (IOException e) {
            System.out.println("Error writing notifications: " + e.getMessage());
        }
    }
    
    // Utility methods
    public List<String> getAllStudentIDs() {
        List<String> studentIDs = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(USERS_FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 6 && parts[5].equals("Student")) {
                    studentIDs.add(parts[0]);
                }
            }
        } catch (IOException e) {
            System.out.println("Error getting student IDs: " + e.getMessage());
        }
        return studentIDs;
    }
    
    public List<String> getAllLecturerIDs() {
        List<String> lecturerIDs = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(USERS_FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 6 && parts[5].equals("Lecturer")) {
                    lecturerIDs.add(parts[0]);
                }
            }
        } catch (IOException e) {
            System.out.println("Error getting lecturer IDs: " + e.getMessage());
        }
        return lecturerIDs;
    }
    
    // Data export method
    public String exportStudentData(String studentID) {
        StringBuilder export = new StringBuilder();
        
        // Student info
        Student student = getStudentByID(studentID);
        if (student != null) {
            export.append("STUDENT PROFILE\n");
            export.append("===============\n");
            export.append("ID: ").append(student.getUserID()).append("\n");
            export.append("Name: ").append(student.getName()).append("\n");
            export.append("Email: ").append(student.getEmail()).append("\n\n");
        }
        
        // Enrolled modules
        ArrayList<Course> enrolledCourses = getEnrolledCourses(studentID);
        export.append("ENROLLED MODULES (").append(enrolledCourses.size()).append(")\n");
        export.append("===================\n");
        for (Course course : enrolledCourses) {
            export.append("• ").append(course.getCourseCode())
                  .append(" - ").append(course.getCourseName()).append("\n");
        }
        export.append("\n");
        
        // Results
        ArrayList<Result> results = loadResults(studentID);
        export.append("ASSESSMENT RESULTS (").append(results.size()).append(")\n");
        export.append("===================\n");
        for (Result result : results) {
            export.append("Module: ").append(result.getCourseCode()).append("\n");
            export.append("Assessment: ").append(result.getAssessmentType()).append("\n");
            export.append("Marks: ").append(result.getMarks()).append("\n");
            export.append("Grade: ").append(result.getGrade()).append("\n");
            export.append("Feedback: ").append(result.getFeedback()).append("\n");
            export.append("Lecturer: ").append(result.getLecturerID()).append("\n");
            export.append("---\n");
        }
        
        // Statistics
        if (!results.isEmpty()) {
            double totalMarks = 0;
            double highest = 0;
            double lowest = 100;
            
            for (Result result : results) {
                double marks = result.getMarks();
                totalMarks += marks;
                if (marks > highest) highest = marks;
                if (marks < lowest) lowest = marks;
            }
            
            export.append("\nPERFORMANCE SUMMARY\n");
            export.append("===================\n");
            export.append("Total Assessments: ").append(results.size()).append("\n");
            export.append("Average Marks: ").append(String.format("%.2f", totalMarks / results.size())).append("\n");
            export.append("Highest Score: ").append(highest).append("\n");
            export.append("Lowest Score: ").append(lowest).append("\n");
        }
        
        return export.toString();
    }
    
    // File status check
    public void checkFileStatus() {
        System.out.println("\n=== File Status Check ===");
        checkFile(USERS_FILE);
        checkFile(MODULES_FILE);
        checkFile(ENROLLMENTS_FILE);
        checkFile(RESULTS_FILE);
        checkFile(COMMENTS_FILE);
        checkFile(NOTIFICATIONS_FILE);
        System.out.println("========================\n");
    }
    
    private void checkFile(String fileName) {
        File file = new File(fileName);
        if (file.exists()) {
            System.out.println("✓ " + fileName + " exists (" + file.length() + " bytes)");
        } else {
            System.out.println("✗ " + fileName + " does not exist");
        }
    }
}
